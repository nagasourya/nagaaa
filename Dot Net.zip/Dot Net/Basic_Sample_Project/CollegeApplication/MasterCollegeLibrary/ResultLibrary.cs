﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MasterDataAccess;

namespace MasterCollegeLibrary
{
   public  class ResultLibrary : IResultLibrary
    {
       ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
       //////
       public StudentModel getIdandYear(int id)
       {
          ApplicationDataAccess2 oapplicationdataacess=new ApplicationDataAccess2();
           Student stud = oapplicationdataacess.getIdandYear(id);
           StudentModel ostudentmodel=new StudentModel();
           ostudentmodel.Departmentname = oapplicationlibrary.GetDept((int)stud.DepartmentId);         //getdept(int.Parse(stud.DepartmentId.ToString()));
           ostudentmodel.Yoj=int.Parse(stud.YearOfJoining.ToString());
           return ostudentmodel;

       }
     
        //////////////////////////////////
        //public string getdept(int id)
        //{
        //    //    string s = id.ToString();
        //    //    string[] words = s.Split(' ');
        //    string dep = "";
        //    //    foreach (string i in words)
        //    //    {
        //    if (id.Equals(101))
        //    {
        //        dep = "EEE";
        //    }
        //    else if (id.Equals(201))
        //    {
        //        dep = "ECE";
        //    }
        //    else if (id.Equals(301))
        //    {
        //        dep = "CSE";
        //    }
        //    else if (id.Equals(101201))
        //    {
        //        dep = "EEE,ECE";

        //    }
        //    else if (id.Equals(101301))
        //    {
        //        dep = "EEE,CSE";
        //    }
        //    else if (id.Equals(201301))
        //    {
        //        dep = "ECE,CSE";

        //    }
        //    else if (id.Equals(101201301))
        //    {
        //        dep = "EEE,ECE,CSE";
        //    }
        //    //}
        //    return dep; ;
        //}
        public void InserOnlineResult(OnlineExamResults onlineResult)
        {
            OnlineExamResult oResult = new OnlineExamResult();
            oResult.StudentId = onlineResult.Studentid1;
            oResult.StudentName = onlineResult.Studentname;
            oResult.TestName = onlineResult.Testname;
            oResult.Marks = onlineResult.Marks;
            ApplicationDataAccess2 oapplication = new ApplicationDataAccess2();
            oapplication.InsertOnlineResult(oResult);

        }
        public List<OnlineExamResults> GetOnlineResult()
        {
            List<OnlineExamResults> resultlist = new List<OnlineExamResults>();
            ApplicationDataAccess2 oapplication=new ApplicationDataAccess2();
            var exam = oapplication.GetOnlineResult();
            foreach (OnlineExamResult online in exam)
            {
                resultlist.Add(new OnlineExamResults { Id = online.OnlineResultId, Studentid1 = (int)online.StudentId, Studentname = online.StudentName, Testname = online.TestName, Marks = (int)online.Marks });
            }
            return resultlist;
        }
      
    }
}
