﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
   public  class ClassScheduleS
    {
        int deptId;

        public int DeptId
        {
            get { return deptId; }
            set { deptId = value; }
        }
        string deptname;

        public string Deptname
        {
            get { return deptname; }
            set { deptname = value; }
        }
        string day1;

        public string Day1
        {
            get { return day1; }
            set { day1 = value; }
        }
        string day2;

        public string Day2
        {
            get { return day2; }
            set { day2 = value; }
        }
        string day3;

        public string Day3
        {
            get { return day3; }
            set { day3 = value; }
        }
        string day4;

        public string Day4
        {
            get { return day4; }
            set { day4 = value; }
        }
        string day5;

        public string Day5
        {
            get { return day5; }
            set { day5 = value; }
        }
        string semester;

        public string Semester
        {
            get { return semester; }
            set { semester = value; }
        }
        string time;

        public string Time
        {
            get { return time; }
            set { time = value; }
        }
        int _year;

        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }

    }
}
