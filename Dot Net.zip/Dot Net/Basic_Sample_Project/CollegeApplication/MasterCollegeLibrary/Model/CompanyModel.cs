﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
   public  class CompanyModel
    {
        string _CompanyName;

        public string CompanyName
        {
            get { return _CompanyName; }
            set { _CompanyName = value; }
        }
        string _location;

        public string Location
        {
            get { return _location; }
            set { _location = value; }
        }
    }
}
