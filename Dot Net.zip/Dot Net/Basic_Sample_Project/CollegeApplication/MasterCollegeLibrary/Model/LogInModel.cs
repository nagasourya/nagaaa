﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
  public  class LogInModel
    {
        int _Id;

        public int UserId
        {
            get { return _Id; }
            set { _Id = value; }
        }
        DateTime _LastModifiedDate;

        public DateTime LastModifiedDate
        {
            get { return _LastModifiedDate; }
            set { _LastModifiedDate = value; }
        }

        string _password;

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }
        string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        int _yearofjoining;

        public int Yearofjoining
        {
            get { return _yearofjoining; }
            set { _yearofjoining = value; }
        }
        string _oldpassword;

        public string Oldpassword
        {
            get { return _oldpassword; }
            set { _oldpassword = value; }
        }

        string _newPassword;

        public string NewPassword
        {
            get { return _newPassword; }
            set { _newPassword = value; }
        }
    }
}
