﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
   public class FeedBackModel
    {
        int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        string _comments;

        public string Comments
        {
            get { return _comments; }
            set { _comments = value; }
        }
        string _email;

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        DateTime _createddate;

        public DateTime Createddate
        {
            get { return _createddate; }
            set { _createddate = value; }
        }
    }
}
