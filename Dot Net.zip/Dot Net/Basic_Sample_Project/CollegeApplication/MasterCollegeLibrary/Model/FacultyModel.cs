﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
    public class FacultyModel
    {
        int _facultyid;

        public int Facultyid
        {
            get { return _facultyid; }
            set { _facultyid = value; }
        }
        string _gender;

        public string Gender
        {
            get { return _gender; }
            set { _gender = value; }
        }
       
        string _email;

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        
        String _password;

        public String Password
        {
            get { return _password; }
            set { _password = value; }
        }
        string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
       int _department;

        public int  Department
        {
            get { return _department; }
            set { _department = value; }
        }

        string _departmentname;

        public string Departmentname
        {
            get { return _departmentname; }
            set { _departmentname = value; }
        }
       int _doj;

        public int Doj
        {
            get { return _doj; }
            set { _doj = value; }
        }
        int subjectcode;

        public int Subjectcode
        {
            get { return subjectcode; }
            set { subjectcode = value; }
        }
        string subject;

       

        public string Subject
        {
            get { return subject; }
            set { subject = value; }
        }
        
        string address;

        public string Address
        {
            get { return address; }
            set { address = value; }
        }
        long contactno;

        public long Contactno
        {
            get { return contactno; }
            set { contactno = value; }
        }
        DateTime lastmodified;

        public DateTime Lastmodified
        {
            get { return lastmodified; }
            set { lastmodified = value; }
        }




    }
}
