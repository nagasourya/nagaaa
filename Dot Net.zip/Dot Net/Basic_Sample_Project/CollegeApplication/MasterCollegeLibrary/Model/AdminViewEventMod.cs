﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
  public class AdminViewEventMod
    {
        DateTime _fromdate;

        public DateTime Fromdate
        {
            get { return _fromdate; }
            set { _fromdate = value; }
        }
        DateTime _todate;

        public DateTime Todate
        {
            get { return _todate; }
            set { _todate = value; }
        }

        int _eventid;

        public int Eventid
        {
            get { return _eventid; }
            set { _eventid = value; }
        }
        string _eventname;

        public string Eventname
        {
            get { return _eventname; }
            set { _eventname = value; }
        }
        string _comments;

        public string Comments
        {
            get { return _comments; }
            set { _comments = value; }
        }
        DateTime _eventdate;

        public DateTime Eventdate
        {
            get { return _eventdate; }
            set { _eventdate = value; }
        }
        private String eventdateonly;

        public String Eventdateonly
        {
            get { return eventdateonly; }
            set { eventdateonly = value; }
        }
    }
}
