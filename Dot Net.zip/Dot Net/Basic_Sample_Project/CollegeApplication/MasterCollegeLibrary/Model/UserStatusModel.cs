﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
   public  class UserStatusModel : UserAppModel
    {
        //int _id;

        //public int Id
        //{
        //    get { return _id; }
        //    set { _id = value; }
        //}
        string _status;

        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }
        string _description;

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
    }
}
