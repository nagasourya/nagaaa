﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
   public class SubjectModel
    {
        int sid;

        public int Sid
        {
            get { return sid; }
            set { sid = value; }
        }
       
        string semester;

        public string Semester
        {
            get { return semester; }
            set { semester = value; }
        }
        int department;


        public int Department
        {
            get { return department; }
            set { department = value; }
        }
        string subject;

        public string Subject
        {
            get { return subject; }
            set { subject = value; }
        }
        int code;

        public int Code
        {
            get { return code; }
            set { code = value; }
        }
        DateTime Ondate;

        public DateTime OnDate
        {
            get { return Ondate; }
            set { Ondate = value; }
        }
        int year;

        public int Year
        {
            get { return year; }
            set { year = value; }
        }
        string deptname;

        public string Deptname
        {
            get { return deptname; }
            set { deptname = value; }
        }
    }
}
