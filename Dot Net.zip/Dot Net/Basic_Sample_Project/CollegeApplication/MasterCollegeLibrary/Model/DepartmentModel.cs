﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
   public class DepartmentModel
    {
        int _deptid;

        public int Deptid
        {
            get { return _deptid; }
            set { _deptid = value; }
        }
        string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        string _Description;

        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }
        int _vacancy;

        public int Vacancy
        {
            get { return _vacancy; }
            set { _vacancy = value; }
        }
        int _seats;

        public int Seats
        {
            get { return _seats; }
            set { _seats = value; }
        }


    }
}
