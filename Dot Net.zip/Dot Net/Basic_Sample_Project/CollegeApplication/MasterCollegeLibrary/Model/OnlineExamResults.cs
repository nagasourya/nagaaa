﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
     public  class OnlineExamResults
    {

        int id;

        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        int Studentid;

        public int Studentid1
        {
            get { return Studentid; }
            set { Studentid = value; }
        }
         string studentname;

         public string Studentname
         {
             get { return studentname; }
             set { studentname = value; }
         }
         string testname;

         public string Testname
         {
             get { return testname; }
             set { testname = value; }
         }
         int marks;

         public int Marks
         {
             get { return marks; }
             set { marks = value; }
         }
    }
}
