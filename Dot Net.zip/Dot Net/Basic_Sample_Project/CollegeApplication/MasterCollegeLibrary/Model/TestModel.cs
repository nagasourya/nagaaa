﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
     public class TestModel
    {
        private int testid;

        public int Testid
        {
            get { return testid; }
            set { testid = value; }
        }
        private string testname;

        public string Testname
        {
            get { return testname; }
            set { testname = value; }
        }
        private string testcode;

        public string Testcode
        {
            get { return testcode; }
            set { testcode = value; }
        }
        private int duration;

        public int Duration
        {
            get { return duration; }
            set { duration = value; }
        }
        private bool isactive;

        public bool Isactive
        {
            get { return isactive; }
            set { isactive = value; }
        }
    }
}
