﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
    public class QuestionModel
    {
        int QuestionId;

        public int QuestionId1
        {
            get { return QuestionId; }
            set { QuestionId = value; }
        }
        string QuestionData;

        public string QuestionData1
        {
            get { return QuestionData; }
            set { QuestionData = value; }
        }
        int CorrectData;

        public int CorrectData1
        {
            get { return CorrectData; }
            set { CorrectData = value; }
        }
        string Option1;

        public string Option11
        {
            get { return Option1; }
            set { Option1 = value; }
        }
        string Option2;

        public string Option21
        {
            get { return Option2; }
            set { Option2 = value; }
        }
        string Option3;

        public string Option31
        {
            get { return Option3; }
            set { Option3 = value; }
        }
        string Option4;

        public string Option41
        {
            get { return Option4; }
            set { Option4 = value; }
        }
        string TestName;

        public string TestName1
        {
            get { return TestName; }
            set { TestName = value; }
        }
    }
}
