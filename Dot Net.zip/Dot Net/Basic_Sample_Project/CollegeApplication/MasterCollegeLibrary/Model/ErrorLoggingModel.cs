﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
   public class ErrorLoggingModel
    {
        int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        string _error;

        public string Error
        {
            get { return _error; }
            set { _error = value; }
        }
        DateTime _errortime;

        public DateTime Errortime
        {
            get { return _errortime; }
            set { _errortime = value; }
        }
        string _loggeduser;

        public string Loggeduser
        {
            get { return _loggeduser; }
            set { _loggeduser = value; }
        }
    }
}
