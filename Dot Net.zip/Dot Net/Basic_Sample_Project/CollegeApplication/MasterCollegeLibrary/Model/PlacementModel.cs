﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
   public  class PlacementModel
    {
        int placementid;

        public int Placementid
        {
            get { return placementid; }
            set { placementid = value; }
        }
       
        string companyname;

        public string Companyname
        {
            get { return companyname; }
            set { companyname = value; }
        }
        DateTime date;

        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }
        string _dateonly;

        public string Dateonly
        {
            get { return _dateonly; }
            set { _dateonly = value; }
        }

        int eligiblity;

        public int Eligiblity
        {
            get { return eligiblity; }
            set { eligiblity = value; }
        }
        string departmentname;

        public string Departmentname
        {
            get { return departmentname; }
            set { departmentname = value; }
        }
    }
}
