﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
   public  class StudentModel
    {
        int _studentid;

        public int Studentid
        {
            get { return _studentid; }
            set { _studentid = value; }
        }
        string _Yojonly;

        public string Yojonly
        {
            get { return _Yojonly; }
            set { _Yojonly = value; }
        }
        string _gender;

        public string Gender
        {
            get { return _gender; }
            set { _gender = value; }
        }
        string _emailid;

        public string Emailid
        {
            get { return _emailid; }
            set { _emailid = value; }
        }
        long _contactno;

        public long Contactno
        {
            get { return _contactno; }
            set { _contactno = value; }
        }
        string _address;

        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }


        string _studentpassword;

        public string Studentpassword
        {
            get { return _studentpassword; }
            set { _studentpassword = value; }
        }
        string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        int departmentid;

        public int Departmentid
        {
            get { return departmentid; }
            set { departmentid = value; }
        }
        string departmentname;

        public string Departmentname
        {
            get { return departmentname; }
            set { departmentname = value; }
        }
        DateTime dob;

        public DateTime Dob
        {
            get { return dob; }
            set { dob = value; }
        }
        string DOBonly;

        public string DOBonly1
        {
            get { return DOBonly; }
            set { DOBonly = value; }
        }
        int yoj;

        public int Yoj
        {
            get { return yoj; }
            set { yoj = value; }
        }
        DateTime lastmodified;

        public DateTime Lastmodified
        {
            get { return lastmodified; }
            set { lastmodified = value; }
        }
        int _yop;

        public int Yop
        {
            get { return _yop; }
            set { _yop = value; }
        }
        string _designation;

        public string Designation
        {
            get { return _designation; }
            set { _designation = value; }
        }
        string _company;

        public string Company
        {
            get { return _company; }
            set { _company = value; }
        }
    }
}
