﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
   public class AssignmentModel
    {
        int _personid;

        public int Personid
        {
            get { return _personid; }
            set { _personid = value; }
        }
        string _personname;

        public string Personname
        {
            get { return _personname; }
            set { _personname = value; }
        }
        string _filename;

        public string Filename
        {
            get { return _filename; }
            set { _filename = value; }
        }
        string _filepath;

        public string Filepath
        {
            get { return _filepath; }
            set { _filepath = value; }
        }
        string _deptname;

        public string Deptname
        {
            get { return _deptname; }
            set { _deptname = value; }
        }
        DateTime _filedate;

        public DateTime Filedate
        {
            get { return _filedate; }
            set { _filedate = value; }
        }
    }
}
