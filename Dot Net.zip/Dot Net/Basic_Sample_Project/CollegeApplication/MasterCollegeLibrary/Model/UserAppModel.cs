﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
    public class UserAppModel
    {
        private int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        string _gender;

        public string Gender
        {
            get { return _gender; }
            set { _gender = value; }
        }

        string _department;

        public string Department
        {
            get { return _department; }
            set { _department = value; }
        }
      decimal _avgmark;

        public decimal Avgmark
        {
            get { return _avgmark; }
            set { _avgmark = value; }
        }
        string _address;

        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }
        string _email;

        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
        long _contactno;

        public long Contactno
        {
            get { return _contactno; }
            set { _contactno = value; }
        }

        int _statusid;

        public int Statusid
        {
            get { return _statusid; }
            set { _statusid = value; }
        }

        string _dob;

        public string Dob
        {
            get { return _dob; }
            set { _dob = value; }
        }


    }
}
