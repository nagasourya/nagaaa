﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterCollegeLibrary
{
  public   class ResultModel
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private int regno;

        public int Regno
        {
            get { return regno; }
            set { regno = value; }
        }

        private string department;

        public string Department
        {
            get { return department; }
            set { department = value; }
        }
        //private int DepartmentId;

        //public int DepartmentId1
        //{
        //    get { return DepartmentId; }
        //    set { DepartmentId = value; }
        //}

        private string firstsem;

        public string Firstsem
        {
            get { return firstsem; }
            set { firstsem = value; }
        }
        private string secondsem;

        public string Secondsem
        {
            get { return secondsem; }
            set { secondsem = value; }
        }
        private string thirdsem;

        public string Thirdsem
        {
            get { return thirdsem; }
            set { thirdsem = value; }
        }
        private string fourthsem;

        public string Fourthsem
        {
            get { return fourthsem; }
            set { fourthsem = value; }
        }
        private string fifthsem;

        public string Fifthsem
        {
            get { return fifthsem; }
            set { fifthsem = value; }
        }
        private string sixthsem;

        public string Sixthsem
        {
            get { return sixthsem; }
            set { sixthsem = value; }
        }
        private string sevensem;

        public string Sevensem
        {
            get { return sevensem; }
            set { sevensem = value; }
        }
        private string eightsem;

        public string Eightsem
        {
            get { return eightsem; }
            set { eightsem = value; }
        }
    }
}
