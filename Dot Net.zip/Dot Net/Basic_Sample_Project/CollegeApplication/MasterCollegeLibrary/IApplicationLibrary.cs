﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MasterDataAccess;

namespace MasterCollegeLibrary
{
   public interface IApplicationLibrary
    {
       /// <summary>
       /// To Get Department List
       /// </summary>
       /// <returns></returns>
       List<string> GetDeptList();

       /// <summary>
       /// To View Events
       /// </summary>
       /// <returns></returns>
       IEnumerable<AdminViewEventMod> ViewEvents();


       IEnumerable<AdminViewEventMod> ViewEventsFaculty();
       int SubmitEvent(AdminViewEventMod oAdminEvtMod);
       List<AdminViewEventMod> GetEvent(AdminViewEventMod oAdminMod);
       string Encryptdata(string password);
       string Decryptdata(string encryptpwd);
       bool FacultyValidation(LogInModel oLogInModel);
       bool StudentValidation(LogInModel oLogInModel);
       bool AluminiValidation(LogInModel oLogInModel);
       void SaveFacultyPassword(string password, int newuserid);
       void SaveStudentsPassword(string password, int newuserid);
       LogInModel StudentSignIn(LogInModel oLogInModel);
       LogInModel AlumniSignIn(LogInModel oLogInModel);
       LogInModel FacultySignIn(LogInModel oLogInModel);
       LogInModel AdminSignIn(LogInModel oLogInModel);
       LogInModel ChangeStudentPassword(LogInModel oLogInModel);
       LogInModel ChangeFacultyPassword(LogInModel oLogInModel);
       LogInModel ChangeAdminPassword(LogInModel oLogInModel);
       List<FeedBackModel> FeedBackLoad();
       void FeedBackUpdate(FeedBackModel oFbMod);
       int SubmitForm(UserAppModel oUserMod);
       UserStatusModel CheckStatus(UserStatusModel oUserStatusMod);
       string GetStatus(int statusid);
       List<SubjectModel> GetSubject(string sem, int dept);
       bool Inserttable(List<ExamModel> examlist, int year, string sem, int dept);
       int ConvertingDeptId(string dept);
       bool Addsubject(SubjectModel osubjectmodel, int code);
       List<ExamModel> GetForReschedule(int year, string sem, int dept);
       bool RescheduleDate(int code, DateTime dt, int year);
       List<ExamModel> ViewSchedule(int year, int dept, string sem);
       int GetSubjectCode(string subjectname);
       string GetSubjectName(int code);
       List<string> GetSubjectOnDept(int dept);
       List<string> GetSubjectOnDeptandSemester(int dept, string sem);
       int AddStudent(StudentModel oStudMod);
       int AddFaculty(FacultyModel ofacultymod);
       int AddCompany(CompanyModel ocompanymodel);
       bool AddPlacement(PlacementModel oplacementmodel, DateTime date, string companyname);
       bool Inserttable(List<ClassScheduleS> classlist, string sem, int dept, int years);
       List<ClassScheduleS> GetClassSchedule(string sem, int dept,int years);
       List<FacultyModel> GetFaculty(int dpt);
       List<StudentModel> GetStudent(int dpt);
       List<PlacementModel> GetPlacementCalender();
       List<string> GetCompanynames();
       List<DepartmentModel> GetDepartment();
       List<UserAppModel> GetUserform(string dept);
       void UpdateStatus(int id, string status);
       void UpdateVacancy(string dept, string status);
       List<UserAppModel> GetUserformOnStatus(string status);
       string GetDepartmentId(string[] dept);
       List<StudentModel> GetTable(int dept, int year);
       bool InsertTable(string name, int id, int sem, decimal marks, int dept);
       List<ResultModel> GetResult(int department);
       List<ResultModel> GetResultForStudents(int id, int dept);
       string getmarks(decimal mark);
       int updatealumini(int id, long no, string address, string designation, string company);
       List<Student> viewAlumini();
       List<Student> viewAlumini(string s, int yop);
       List<Student> viewAlumini(int yop);
       List<Student> viewAlumini(string s);
       void inserttestname(TestModel otestmodel);
       List<TestModel> GetTest();
       List<TestModel> GetTestAdmin();
       void UpdateTestStatus(bool value, int id);
       List<QuestionModel> GetQuestion(string testname);
       int GiveScore(int id);
       void StoreQuestion(List<QuestionModel> olist);
       List<string> GetTestName();
       IEnumerable<AssignmentModel> getdata(string loguser, int id);
       AssignmentModel getstudent(AssignmentModel oAd);
       AssignmentModel getfaculty(AssignmentModel oAd);
       void insertgrid(AssignmentModel oAsm);
       string GetYear(int year);
       string GetDept(int department);
       List<StudentModel> ViewProfileStudent(int id);
       List<FacultyModel> ViewProfilefaculty(int id);
       int AddDepartment(DepartmentModel odepartmentmodel);
       void DeletingFaculty(int id);
       void logException(ErrorLoggingModel oerrorlogging);
       List<MasterCollegeLibrary.ApplicationLibrary.Semester> GetSemester();
    }
}
