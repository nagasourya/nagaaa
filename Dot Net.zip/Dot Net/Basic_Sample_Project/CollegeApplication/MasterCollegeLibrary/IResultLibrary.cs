﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MasterDataAccess;
namespace MasterCollegeLibrary
{
   public interface IResultLibrary
    {
       StudentModel getIdandYear(int id);
       void InserOnlineResult(OnlineExamResults onlineResult);
       List<OnlineExamResults> GetOnlineResult();
    }
}
