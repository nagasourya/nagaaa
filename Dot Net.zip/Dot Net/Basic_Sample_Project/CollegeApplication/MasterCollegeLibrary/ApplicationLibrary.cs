﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MasterDataAccess;

namespace MasterCollegeLibrary
{
    public class ApplicationLibrary : IApplicationLibrary
    {
        ApplicationDataAccess oApplicationDataAccess = new ApplicationDataAccess();
        // get view Events

        public List<string> GetDeptList()
        {
            List<string> ideptlist = oApplicationDataAccess.ShowDepartment();
            return ideptlist;
        }

        public IEnumerable<AdminViewEventMod> ViewEvents()
        {

            var gtevt = oApplicationDataAccess.ViewEvents();
            return gtevt.Select(ce => new AdminViewEventMod
                                          {
                                              Eventname = ce.EventsName,
                                              Comments = ce.Comments,
                                              Eventdateonly = ce.EventDate.ToString().Substring(0, 9)
                                          }).ToList();

        }
        //faculty viewing class meeting
        public IEnumerable<AdminViewEventMod> ViewEventsFaculty()
        {

            var gtevt = oApplicationDataAccess.ViewEventsFaculty();
            return gtevt.Select(ce => new AdminViewEventMod
                                          {
                                              Eventname = ce.EventsName,
                                              Comments = ce.Comments,
                                              Eventdateonly = ce.EventDate.ToString().Substring(0, 9)
                                          }).ToList();

        }
        //adding events

        public int SubmitEvent(AdminViewEventMod oAdminEvtMod)
        {
            var oCollEvt = new CollegeEvent
                               {
                                   EventsName = oAdminEvtMod.Eventname,
                                   EventDate = oAdminEvtMod.Eventdate,
                                   Comments = oAdminEvtMod.Comments
                               };


            var x = oApplicationDataAccess.SubmitEvent(oCollEvt);
            return x;
        }
        //viewing all events for admin page
        public List<AdminViewEventMod> GetEvent(AdminViewEventMod oAdminMod)
        {


            var oListdate = new List<DateTime> { oAdminMod.Fromdate, oAdminMod.Todate };
            var gtevtname = oApplicationDataAccess.ShowEvent(oListdate);

            return gtevtname.Select(item => new AdminViewEventMod
                                                {
                                                    Eventid = item.EventId,
                                                    Eventname = item.EventsName,
                                                    Comments = item.Comments,
                                                    Eventdateonly = item.EventDate.Value.ToShortDateString()
                                                }).ToList();


        }

        //----PWD ENCRYPTION DECRYPTION-----------
        public string Encryptdata(string password)
        {
            //string strmsg = string.Empty;
            byte[] encode = Encoding.UTF8.GetBytes(password);
            return Convert.ToBase64String(encode);
            //return strmsg;
        }

        //password decryption
        public string Decryptdata(string encryptpwd)
        {
            var encodepwd = new UTF8Encoding();
            Decoder decode = encodepwd.GetDecoder();
            byte[] todecodeByte = Convert.FromBase64String(encryptpwd);
            var charCount = decode.GetCharCount(todecodeByte, 0, todecodeByte.Length);
            var decodedChar = new char[charCount];
            decode.GetChars(todecodeByte, 0, todecodeByte.Length, decodedChar, 0);
            var decryptpwd = new String(decodedChar);
            return decryptpwd;
        }
        //------------------------------

        //-------LOGIN---------------------
        //faculty credential validation
        public bool FacultyValidation(LogInModel oLogInModel)
        {
            bool result = false;

            var fac = oApplicationDataAccess.FacultyDataBase().ToList();
            foreach (var f in fac.Where(f => oLogInModel.UserId.Equals(f.Id)))
            {
                oLogInModel.Password = f.Password;
                result = true;
                break;
            }
            return result;
        }
        //student credential validation
        public bool StudentValidation(LogInModel oLogInModel)
        {
            var result = false;


            List<Student> stu = oApplicationDataAccess.StudentDataBase().ToList();
            foreach (Student s in stu.Where(s => oLogInModel.UserId.Equals(s.Id)))
            {
                oLogInModel.Password = s.Password;
                result = true;
                break;
            }
            return result;
        }
        //Alunini credential validation
        public bool AluminiValidation(LogInModel oLogInModel)
        {
            bool result = false;

            var stu = oApplicationDataAccess.StudentDataBase().ToList();
            foreach (var s in
                stu.Where(s => oLogInModel.UserId.Equals(s.Id) && ((s.PassedOutYear) <= (System.DateTime.Now.Year - 1))))
            {
                oLogInModel.Password = s.Password;
                result = true;
                break;
            }
            return result;
        }
        //Saving Password for faculty
        public void SaveFacultyPassword(string password, int newuserid)
        {

            var encryptedpwd = Encryptdata(password);
            oApplicationDataAccess.SaveFacultyPassword(encryptedpwd, newuserid);
        }
        //Saving Password for student

        public void SaveStudentsPassword(string password, int newuserid)
        {
            var encryptedpwd = Encryptdata(password);
            oApplicationDataAccess.SaveStudentPassword(encryptedpwd, newuserid);
        }
        public LogInModel StudentSignIn(LogInModel oLogInModel)
        {


            var stu = oApplicationDataAccess.StudentDataBase().ToList();

            foreach (var s in stu)
            {
                if ((string.IsNullOrEmpty(s.Password)) || (s.Password == "NULL") || (s.Password.Equals("null")) || (s.Password.Equals("")))
                {
                    continue;
                }
                var decryptedpwd = Decryptdata(s.Password);
                if ((oLogInModel.UserId.Equals(s.Id)) && (oLogInModel.Password.Equals(decryptedpwd)) && (s.IsActive == true))
                {
                    oLogInModel.Name = s.Name;
                    oLogInModel.LastModifiedDate = (DateTime)s.LastModifiedDate;
                    oApplicationDataAccess.UpdateStudentLastLogIn(oLogInModel.UserId, oLogInModel.Password);
                    break;
                }
            }
            return oLogInModel;

        }
        public LogInModel AlumniSignIn(LogInModel oLogInModel)
        {


            var stu = oApplicationDataAccess.StudentDataBase().ToList();

            foreach (var s in stu)
            {

                if ((string.IsNullOrEmpty(s.Password)) || (s.Password == "NULL") || (s.Password.Equals("null")) || (s.Password.Equals("")))
                {
                    continue;
                }
                string decryptedpwd = Decryptdata(s.Password);
                if ((oLogInModel.UserId.Equals(s.Id)) && (oLogInModel.Password.Equals(decryptedpwd)) && (s.IsActive == false))
                {
                    oLogInModel.Name = s.Name;
                    oLogInModel.LastModifiedDate = (DateTime)s.LastModifiedDate;
                    oApplicationDataAccess.UpdateStudentLastLogIn(oLogInModel.UserId, oLogInModel.Password);
                    break;
                }
            }
            return oLogInModel;

        }

        public LogInModel FacultySignIn(LogInModel oLogInModel)
        {


            var fac = oApplicationDataAccess.FacultyDataBase().ToList();

            foreach (var f in fac)
            {

                if ((string.IsNullOrEmpty(f.Password)) || (f.Password == "NULL") || (f.Password.Equals("null")) || (f.Password.Equals("")))
                {
                    continue;
                }
                var decryptedpwd = Decryptdata(f.Password);
                if ((oLogInModel.UserId.Equals(f.Id)) && (oLogInModel.Password.Equals(decryptedpwd)))
                {
                    oLogInModel.Name = f.Name;
                    oLogInModel.LastModifiedDate = (DateTime)f.LastModifiedDate;
                    oApplicationDataAccess.UpdateFacultyLastLogIn(oLogInModel.UserId, oLogInModel.Password);
                    break;
                }
            }
            return oLogInModel;
        }

        public LogInModel AdminSignIn(LogInModel oLogInModel)
        {

            var adm = oApplicationDataAccess.AdminDataBase().ToList();

            foreach (var a in adm)
            {

                if ((string.IsNullOrEmpty(a.Password)) || (a.Password == "NULL") || (a.Password.Equals("null")) || (a.Password.Equals("")))
                {
                    continue;
                }
                var decryptedpwd = Decryptdata(a.Password);
                if ((oLogInModel.UserId.Equals(a.Id)) && (oLogInModel.Password.Equals(decryptedpwd)))
                {
                    oLogInModel.Name = a.Name;
                    oLogInModel.LastModifiedDate = (DateTime)a.LastModifiedDate;
                    oApplicationDataAccess.UpdateAdminLastLogIn(oLogInModel.UserId, oLogInModel.Password);
                    break;
                }
            }
            return oLogInModel;
        }

        public LogInModel ChangeStudentPassword(LogInModel oLogInModel)
        {

            var stu = oApplicationDataAccess.StudentDataBase().ToList();

            foreach (Student s in stu)
            {
                string decryptedpwd;
                if ((string.IsNullOrEmpty(s.Password)) || (s.Password == "NULL") || (s.Password.Equals("null")) || (s.Password.Equals("")))
                {
                    continue;
                }
                decryptedpwd = Decryptdata(s.Password);
                if ((oLogInModel.Oldpassword.Equals(decryptedpwd)) && (oLogInModel.UserId.Equals(s.Id)))
                {
                    var encryptedpwd = Encryptdata(oLogInModel.NewPassword);
                    oApplicationDataAccess.ChangeStudentPassword(encryptedpwd, oLogInModel.UserId);
                    break;
                }
                oLogInModel.Oldpassword = decryptedpwd;
            }

            return oLogInModel;

        }

        public LogInModel ChangeFacultyPassword(LogInModel oLogInModel)
        {

            var fac = oApplicationDataAccess.FacultyDataBase().ToList();

            foreach (Faculty f in fac)
            {
                string decryptedpwd;
                if ((string.IsNullOrEmpty(f.Password)) || (f.Password == "NULL") || (f.Password.Equals("null")) || (f.Password.Equals("")))
                {
                    continue;
                }
                else
                {
                    decryptedpwd = Decryptdata(f.Password);
                    if ((oLogInModel.Oldpassword.Equals(decryptedpwd)) && (oLogInModel.UserId.Equals(f.Id)))
                    {
                        var encryptedpwd = Encryptdata(oLogInModel.NewPassword);
                        oApplicationDataAccess.ChangeFacultyPassword(encryptedpwd, oLogInModel.UserId);
                        break;
                    }
                }
                oLogInModel.Oldpassword = decryptedpwd;
            }

            return oLogInModel;
        }
        public LogInModel ChangeAdminPassword(LogInModel oLogInModel)
        {

            var fac = oApplicationDataAccess.AdminDataBase().ToList();

            foreach (Admin ad in fac)
            {
                string decryptedpwd;
                if ((string.IsNullOrEmpty(ad.Password)) || (ad.Password == "NULL") || (ad.Password.Equals("null")) || (ad.Password.Equals("")))
                {
                    continue;
                }
                decryptedpwd = Decryptdata(ad.Password);
                if ((oLogInModel.Oldpassword.Equals(decryptedpwd)) && (oLogInModel.UserId.Equals(ad.Id)))
                {
                    var encryptedpwd = Encryptdata(oLogInModel.NewPassword);
                    oApplicationDataAccess.ChangeAdminPassword(encryptedpwd, oLogInModel.UserId);
                }
                oLogInModel.Oldpassword = decryptedpwd;
            }
            return oLogInModel;
        }

        //-------------------------------------

        public List<FeedBackModel> FeedBackLoad()
        {
            var result = oApplicationDataAccess.FeedBackLoad();
            return result.Select(temp => new FeedBackModel
                                             {
                                                 Name = temp.Name,
                                                 Comments = temp.Comments,
                                                 Email = temp.Email,
                                                 Createddate = (DateTime)temp.CreatedDate
                                             }).ToList();
        }

        public void FeedBackUpdate(FeedBackModel oFbMod)
        {


            var oFb = new Feedback
                          {
                              Name = oFbMod.Name,
                              Comments = oFbMod.Comments,
                              Email = oFbMod.Email,
                              CreatedDate = oFbMod.Createddate
                          };

            oApplicationDataAccess.FeedBackUpdate(oFb);


        }


        public int SubmitForm(UserAppModel oUserMod)
        {


            var oUserForm = new UserForm
                                {
                                    Name = oUserMod.Name,
                                    Gender = oUserMod.Gender,
                                    Department = oUserMod.Department,
                                    AverageMark = oUserMod.Avgmark,
                                    Address = oUserMod.Address,
                                    ContactNo = oUserMod.Contactno,
                                    Email = oUserMod.Email,
                                    DOB = oUserMod.Dob
                                };

            return oApplicationDataAccess.SubmitForm(oUserForm);

        }

        public UserStatusModel CheckStatus(UserStatusModel oUserStatusMod)
        {

            //var oUserStatus = new UserStatu();
            //oUserStatus.Id = oUserStatusMod.Id;
            var oUserForm = new UserForm();
            oUserForm.Id = oUserStatusMod.Id;
            var oUserListForm = oApplicationDataAccess.CheckStatus(oUserForm);

            foreach (var item in oUserListForm)
            {
                oUserStatusMod.Id = item.Id;
                oUserStatusMod.Name = item.Name;
                oUserStatusMod.Gender = item.Gender;
                oUserStatusMod.Department = item.Department;
                oUserStatusMod.Address = item.Address;
                oUserStatusMod.Avgmark = int.Parse(item.AverageMark.ToString());
                oUserStatusMod.Contactno = long.Parse(item.ContactNo.ToString());
                oUserStatusMod.Email = item.Email;
                oUserStatusMod.Statusid = (int)item.Statusid;
            }

            return oUserStatusMod;
        }
        public string GetStatus(int statusid)
        {

            //UserStatus oUserStatus = new UserStatus();
            //List<UserForm> oUserListForm = new List<UserForm>();
            var status = oApplicationDataAccess.GetStatus(statusid);
            return status;
        }


        //-----------------Student Lib---------


        public List<SubjectModel> GetSubject(string sem, int dept)
        {

            var result = oApplicationDataAccess.GetSubjects(sem, dept);
            return result.Select(ss => new SubjectModel
                                           {
                                               Semester = ss.Semester,
                                               Deptname = GetDept(int.Parse(ss.DepartmentId.ToString())),
                                               Subject = ss.SubjectName,
                                               Code = int.Parse(ss.Code.ToString())
                                           }).ToList();
        }

        public bool Inserttable(List<ExamModel> examlist, int year, string sem, int dept)
        {
            var exam = examlist.Select(ex => new ExamSchedule
                                                 {
                                                     Semester = ex.Semester,
                                                     DepartmentId = ex.Department,
                                                     Subject = ex.Subject,
                                                     Code = ex.Code,
                                                     OnDate = ex.OnDate,
                                                     Year = ex.Year
                                                 }).ToList();

            var value = oApplicationDataAccess.InserData(exam, year, sem, dept);
            return value == true;

        }
        public int ConvertingDeptId(string dept)
        {
            return oApplicationDataAccess.ConvertingDeptID(dept);
        }
        public bool Addsubject(SubjectModel osubjectmodel, int code)
        {
            var osubject = new Subject
                               {
                                   DepartmentId = osubjectmodel.Department,
                                   Semester = osubjectmodel.Semester,
                                   SubjectName = osubjectmodel.Subject,
                                   Code = osubjectmodel.Code
                               };
            //  osubject.year = osubjectmodel.Year;

            var value = oApplicationDataAccess.Addsubject(osubject, code);
            return value == true;
        }
        public List<ExamModel> GetForReschedule(int year, string sem, int dept)
        {

            var result = oApplicationDataAccess.GetForReschedule(year, sem, dept);
            return result.Select(exam => new ExamModel
                                             {
                                                 Semester = exam.Semester,
                                                 Deptname = GetDept(int.Parse(exam.DepartmentId.ToString())),
                                                 Subject = exam.Subject,
                                                 Code = int.Parse(exam.Code.ToString()),
                                                 OndateOnly1 = exam.OnDate.ToString().Substring(0, 9),
                                                 Year = int.Parse(exam.Year.ToString())
                                             }).ToList();
        }
        //public bool RescheduleDate(int code, DateTime dt, int year)
        public bool RescheduleDate(int code, DateTime dt, int year)
        {
            var value = oApplicationDataAccess.RescheduleDate(code, dt, year);
            return value == true;
        }

        public List<ExamModel> ViewSchedule(int year, int dept, string sem)
        {

            var result = oApplicationDataAccess.ViewSchedule(year, dept, sem);

            return result.Select(exam => new ExamModel
                                             {
                                                 Year = int.Parse(exam.Year.ToString()),
                                                 Semester = exam.Semester,
                                                 Deptname = GetDept(int.Parse(exam.DepartmentId.ToString())),
                                                 Subject = exam.Subject,
                                                 Code = int.Parse(exam.Code.ToString()),
                                                 OndateOnly1 = exam.OnDate.ToString().Substring(0, 9) + "-10:00 A.M"
                                             }).ToList();


        }

        public int GetSubjectCode(string subjectname)
        {

            return oApplicationDataAccess.GetSubjectCode(subjectname);

        }
        public string GetSubjectName(int code)
        {
            return oApplicationDataAccess.GetSubjectName(code);
        }
        public List<string> GetSubjectOnDept(int dept)
        {
            return oApplicationDataAccess.GetSubjectOnDept(dept);

        }
        public List<string> GetSubjectOnDeptandSemester(int dept, string sem)
        {

            var subjects = oApplicationDataAccess.GetSubjectOnDeptandSemester(dept, sem);
            return subjects;
        }



        /// <summary>
        /// /////////////////
        /// </summary>
        /// <param name="dept"></param>
        /// <returns></returns>

        public int AddStudent(StudentModel oStudMod)
        {
            var oStudent = new Student
                               {
                                   PassedOutYear = oStudMod.Yop,
                                   Gender = oStudMod.Gender,
                                   EmailId = oStudMod.Emailid,
                                   ContactNo = oStudMod.Contactno,
                                   Address = oStudMod.Address,
                                   Name = oStudMod.Name
                               };
            oStudent.Gender = oStudMod.Gender;
            oStudent.EmailId = oStudMod.Emailid;
            oStudent.DepartmentId = oStudMod.Departmentid;
            oStudent.DateOfBirth = oStudMod.Dob;
            oStudent.YearOfJoining = oStudMod.Yoj;
            oStudent.LastModifiedDate = oStudMod.Lastmodified;
            return oApplicationDataAccess.InsertData(oStudent);

        }
        public int AddFaculty(FacultyModel ofacultymod)
        {
            var ofaculty = new Faculty
                               {
                                   Name = ofacultymod.Name,
                                   Gender = ofacultymod.Gender,
                                   Email = ofacultymod.Email,
                                   DepartmentId = ofacultymod.Department,
                                   YearOfJoining = (int)ofacultymod.Doj,
                                   ContactNo = ofacultymod.Contactno,
                                   Address = ofacultymod.Address,
                                   Subject = ofacultymod.Subjectcode,
                                   LastModifiedDate = ofacultymod.Lastmodified
                               };
            //   ofaculty.Id = ofacultymod.Facultyid;
            //  ofaculty.Password = ofacultymod.Name;
            return oApplicationDataAccess.InsertData(ofaculty);
        }
        public int AddCompany(CompanyModel ocompanymodel)
        {

            var ocompany = new Company { CompanyName = ocompanymodel.CompanyName, Location = ocompanymodel.Location };
            return oApplicationDataAccess.InsertData(ocompany);

        }
        public bool AddPlacement(PlacementModel oplacementmodel, DateTime date, string companyname)
        {
            var oplacementcalender = new PlacementCalendar
                                         {
                                             PlacementId = oplacementmodel.Placementid,
                                             Company = oplacementmodel.Companyname,
                                             Department = oplacementmodel.Departmentname,
                                             OnDate = oplacementmodel.Date,
                                             Eligibility = oplacementmodel.Eligiblity
                                         };

            var value = oApplicationDataAccess.InsertData(oplacementcalender, date, companyname);
            return value == true;

        }

        /// <summary>
        /// ///////////////class Schedule////////
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool Inserttable(List<ClassScheduleS> classlist, string sem, int dept, int years)
        {
            var schedule = classlist.Select(cs => new ClassSchedule
                                                      {
                                                          Year = cs.Year,
                                                          Timing = cs.Time,
                                                          semester = cs.Semester,
                                                          dept = cs.DeptId,
                                                          Day1 = cs.Day1,
                                                          Day2 = cs.Day2,
                                                          Day3 = cs.Day3,
                                                          Day4 = cs.Day4,
                                                          Day5 = cs.Day5
                                                      }).ToList();
            var odataaccess = new ApplicationDataAccess();
            var value = odataaccess.InserData(schedule, sem, dept, years);
            return value == true;

        }
        public List<ClassScheduleS> GetClassSchedule(string sem, int dept, int years)
        {
            var odataaccess = new ApplicationDataAccess();
            return odataaccess.GetClassSchedule(sem, dept, years).Select(cs => new ClassScheduleS
                                           {
                                               Semester = cs.semester,
                                               Time = cs.Timing,
                                               Deptname = GetDept(int.Parse(cs.dept.ToString())),
                                               Day1 = cs.Day1,
                                               Day2 = cs.Day2,
                                               Day3 = cs.Day3,
                                               Day4 = cs.Day4,
                                               Day5 = cs.Day5
                                           }).ToList();
        }


        //getdept((int)facult.DepartmentId)
        public List<FacultyModel> GetFaculty(int dpt)
        {

            var facultys = oApplicationDataAccess.GetFacuty(dpt);

            return (from facult in facultys
                    let departmentname = GetDept((int)facult.DepartmentId)
                    select new FacultyModel
                               {
                                   Facultyid = facult.Id,
                                   Password = facult.Password,
                                   Name = facult.Name,
                                   Departmentname = departmentname,
                                   Doj = int.Parse(facult.YearOfJoining.ToString()),
                                   Subject = GetSubjectName(int.Parse(facult.Subject.ToString()))
                               }).ToList();
        }
        public List<StudentModel> GetStudent(int dpt)
        {

            var studentt = oApplicationDataAccess.GetStudent(dpt);

            return studentt.Select(stud => new StudentModel
                                               {
                                                   Studentid = stud.Id,
                                                   Studentpassword = stud.Password,
                                                   Name = stud.Name,
                                                   Departmentname = GetDept(int.Parse(stud.DepartmentId.ToString())),
                                                   DOBonly1 = stud.DateOfBirth.ToString().Substring(0, 9),
                                                   Yoj = int.Parse(stud.YearOfJoining.ToString()),
                                                   Yop = int.Parse(stud.PassedOutYear.ToString())
                                               }).ToList();
        }
        public List<PlacementModel> GetPlacementCalender()
        {


            var calender = oApplicationDataAccess.GetPlacementCalender();
            return calender.Select(dates => new PlacementModel
                                                {
                                                    Companyname = dates.Company,
                                                    Dateonly = dates.OnDate.ToString().Substring(0, 9),
                                                    Departmentname = dates.Department,
                                                    Eligiblity = int.Parse(dates.Eligibility.ToString())
                                                }).ToList();
        }

        public List<string> GetCompanynames()
        {

            return oApplicationDataAccess.GetCompany();

        }

        public List<DepartmentModel> GetDepartment()
        {

            return oApplicationDataAccess.GetDepartment().Select(dept => new DepartmentModel
                                             {
                                                 Name = dept.Name,
                                                 Vacancy = int.Parse(dept.Vacancy.ToString()),
                                                 Seats = int.Parse(dept.Seats.ToString())
                                             }).ToList();
        }
        public List<UserAppModel> GetUserform(string dept)
        {
            return oApplicationDataAccess.GetUserForm(dept).Select(form => new UserAppModel
                                           {
                                               Id = form.Id,
                                               Name = form.Name,
                                               Department = form.Department,
                                               Avgmark = int.Parse(form.AverageMark.ToString())
                                           }).ToList();


        }
        public void UpdateStatus(int id, string status)
        {

            oApplicationDataAccess.Updatestatus(id, status);

        }
        public void UpdateVacancy(string dept, string status)
        {

            oApplicationDataAccess.Updatevacancy(dept, status);

        }
        public List<UserAppModel> GetUserformOnStatus(string status)
        {


            return oApplicationDataAccess.ViewOnStatus(status).Select(form => new UserAppModel
                                           {
                                               Id = form.Id,
                                               Name = form.Name,
                                               Department = form.Department,
                                               Avgmark = int.Parse(form.AverageMark.ToString())
                                           }).ToList();


        }
        public string GetDepartmentId(string[] dept)
        {
            return oApplicationDataAccess.GetDeptOnDeptId(dept);

        }

        //-------------------RESULT ----------------


        public List<StudentModel> GetTable(int dept, int year)
        {
            var result = oApplicationDataAccess.GetStudent(dept, year);
            return result.Select(output => new StudentModel
                                               {
                                                   Name = output.Name,
                                                   Studentid = output.Id,
                                                   Departmentname = GetDept(int.Parse(output.DepartmentId.ToString())),
                                                   Yoj = int.Parse(output.YearOfJoining.ToString())
                                               }).ToList();

        }
        public bool InsertTable(string name, int id, int sem, decimal marks, int dept)
        {
            var value = oApplicationDataAccess.InsertResult(name, id, sem, marks, dept);
            return value == true;
        }

        public List<ResultModel> GetResult(int department)
        {

            var result = oApplicationDataAccess.GetResult(department);
            return result.Select(output => new ResultModel
                                               {
                                                   Name = output.Name,
                                                   Regno = output.RegisterNo,
                                                   Department = GetDept(int.Parse(output.Department.ToString())),
                                                   Firstsem = getmarks(System.Convert.ToDecimal(output.FirstSem)),
                                                   Secondsem = getmarks(System.Convert.ToDecimal(output.SecondSem)),
                                                   Thirdsem = getmarks(System.Convert.ToDecimal(output.ThirdSem)),
                                                   Fourthsem = getmarks(System.Convert.ToDecimal(output.FourthSem)),
                                                   Fifthsem = getmarks(System.Convert.ToDecimal(output.FifthSem)),
                                                   Sixthsem = getmarks(System.Convert.ToDecimal(output.SixthSem)),
                                                   Sevensem = getmarks(System.Convert.ToDecimal(output.SeventhSem)),
                                                   Eightsem = getmarks(System.Convert.ToDecimal(output.EigthSem))
                                               }).ToList();

        }
        public List<ResultModel> GetResultForStudents(int id, int dept)
        {
            var odataAccess = new ApplicationDataAccess2();
            var result = odataAccess.GetResultForStudents(id, dept);
            return result.Select(output => new ResultModel
                                               {
                                                   Firstsem = getmarks(System.Convert.ToDecimal(output.FirstSem)),
                                                   Secondsem = getmarks(System.Convert.ToDecimal(output.SecondSem)),
                                                   Thirdsem = getmarks(System.Convert.ToDecimal(output.ThirdSem)),
                                                   Fourthsem = getmarks(System.Convert.ToDecimal(output.FourthSem)),
                                                   Fifthsem = getmarks(System.Convert.ToDecimal(output.FifthSem)),
                                                   Sixthsem = getmarks(System.Convert.ToDecimal(output.SixthSem)),
                                                   Sevensem = getmarks(System.Convert.ToDecimal(output.SeventhSem)),
                                                   Eightsem = getmarks(System.Convert.ToDecimal(output.EigthSem))
                                               }).ToList();

        }
        public string getmarks(decimal mark)
        {
            return mark == 0 ? "NA" : mark.ToString();
        }

        //--------------Alumini-EditProfile-------------------
        public int updatealumini(int id, long no, string address, string designation, string company)
        {
            return oApplicationDataAccess.updatealumini(id, no, address, designation, company);
        }

        //-----------Alumin-View Alumini
        public List<Student> viewAlumini()
        {
            return oApplicationDataAccess.ShowAlumini();
        }

        //-----------Alumini-Search by name---------
        public List<Student> viewAlumini(string s, int yop)
        {
            return oApplicationDataAccess.ShowAlumini(s, yop);
        }

        public List<Student> viewAlumini(int yop)
        {
            return oApplicationDataAccess.ShowAlumini(yop);
        }

        public List<Student> viewAlumini(string s)
        {
            return oApplicationDataAccess.ShowAlumini(s);
        }



        /*---------------------------------------------ADD QUESTIONS-----------------------------------------*/


        readonly ApplicationDataAccess1 _oapplicationdataaccess = new ApplicationDataAccess1();
        public void inserttestname(TestModel otestmodel)
        {

            var otest = new Test { TestName = otestmodel.Testname, Duration = otestmodel.Duration };

            otest.TestCode = ((_oapplicationdataaccess.gttestid() + 1) + otest.TestName);

            _oapplicationdataaccess.inserttestname(otest);

        }
        public List<TestModel> GetTest()
        {
            var result = _oapplicationdataaccess.GetTest();

            return result.Select(exam => new TestModel
                                             {
                                                 Testname = exam.TestName,
                                                 Testid = exam.TestId,
                                                 Testcode = exam.TestCode,
                                                 Duration = int.Parse(exam.Duration.ToString()),
                                                 Isactive = (bool)exam.IsActive
                                             }).ToList();

        }
        public List<TestModel> GetTestAdmin()
        {
            var result = _oapplicationdataaccess.GetTestAdmin();

            return result.Select(exam => new TestModel
                                             {
                                                 Testname = exam.TestName,
                                                 Testid = exam.TestId,
                                                 Testcode = exam.TestCode,
                                                 Duration = int.Parse(exam.Duration.ToString()),
                                                 Isactive = (bool)exam.IsActive
                                             }).ToList();

        }
        public void UpdateTestStatus(bool value, int id)
        {
            _oapplicationdataaccess.UpdateTestStatus(value, id);

        }
        public List<QuestionModel> GetQuestion(string testname)
        {
            var oapplicationDataAccess = new ApplicationDataAccess();

            var result = oapplicationDataAccess.GetQuestion(testname);
            return result.Select(question => new QuestionModel
                                                 {
                                                     QuestionId1 = question.QuestionId,
                                                     QuestionData1 = question.QuestionData,
                                                     CorrectData1 = (int)question.CorrectOption,
                                                     Option11 = question.Option1,
                                                     Option21 = question.Option2,
                                                     Option31 = question.Option3,
                                                     Option41 = question.Option4
                                                 }).ToList();

        }
        public int GiveScore(int id)
        {
            var oapplicationDataAccess = new ApplicationDataAccess();
            return oapplicationDataAccess.GiveScore(id);

        }
        public void StoreQuestion(List<QuestionModel> olist)
        {
            var questionlist = olist.Select(question => new QuestionDetail
                                                            {
                                                                QuestionData = question.QuestionData1,
                                                                QuestionId = question.QuestionId1,
                                                                TestName = question.TestName1,
                                                                Option1 = question.Option11,
                                                                Option2 = question.Option21,
                                                                Option3 = question.Option31,
                                                                Option4 = question.Option41,
                                                                CorrectOption = question.CorrectData1
                                                            }).ToList();
            var oApplicationDataAccess = new ApplicationDataAccess();
            oApplicationDataAccess.StoreQuestion(questionlist);
        }
        public List<string> GetTestName()
        {
            return oApplicationDataAccess.GetTestName();
        }

        //-------------------FILE UPLOAD AND DOWNLOAD----------------------
        // AssignmetnDA oassignda = new AssignmetnDA();
        Assignment oassign = new Assignment();
        AssignmentModel _oassignmod = new AssignmentModel();
        public IEnumerable<AssignmentModel> getdata(string loguser, int id)
        {
            var deptid = oApplicationDataAccess.gtdept(loguser, id);
            var deptname = GetDept(deptid);
            var output = oApplicationDataAccess.getgrid(deptname);
            return output.Select(dd => new AssignmentModel
                                           {
                                               Personname = dd.PersonName, Personid = int.Parse(dd.PersonId.ToString()), Filename = dd.FileName, Filepath = dd.FilePath, Deptname = dd.DepartmentName, Filedate = dd.FileDate.Value
                                           }).ToList();
        }

        public AssignmentModel getstudent(AssignmentModel oAd)
        {

            oassign.PersonId = oAd.Personid;
            var gtstuddb = oApplicationDataAccess.GetStudentDb(oassign);
            //string deptname = oassignmod.Deptname;
            oAd.Deptname = gtstuddb.DepartmentName;
            oAd.Filedate = System.DateTime.Now;
            oAd.Filename = gtstuddb.FileName;
            oAd.Filepath = gtstuddb.FilePath;
            if (gtstuddb.PersonId != null) oAd.Personid = (int)gtstuddb.PersonId;
            oAd.Personname = gtstuddb.PersonName;
            return oAd;
        }

        public AssignmentModel getfaculty(AssignmentModel oAd)
        {
            oassign.PersonId = oAd.Personid;
            var gtfacultydb = oApplicationDataAccess.GetFacultyDb(oassign);
            oAd.Deptname = gtfacultydb.DepartmentName;
            oAd.Filedate = DateTime.Now;
            oAd.Filename = gtfacultydb.FileName;
            oAd.Filepath = gtfacultydb.FilePath;
            oAd.Personid = (int)gtfacultydb.PersonId;
            oAd.Personname = gtfacultydb.PersonName;
            return oAd;
        }
        public void insertgrid(AssignmentModel oAsm)
        {
            var ofiletables = new Assignment
                                  {
                                      FileName = oAsm.Filename,
                                      FilePath = oAsm.Filepath,
                                      PersonId = oAsm.Personid,
                                      DepartmentName = oAsm.Deptname,
                                      FileDate = oAsm.Filedate,
                                      PersonName = oAsm.Personname
                                  };
            // ofiletables.Id = dt.Fileid;
            oApplicationDataAccess.InsertData(ofiletables);

        }
        //---------View profile for students----------//
        public string GetYear(int year)
        {
            var curyear = DateTime.Now.Year - year;
            var currentmonth = DateTime.Now.Month;
            var output = "";
            switch (curyear)
            {
                case 0:
                    output = "I YEAR";
                    break;
                case 4:
                    output = "IV YEAR";
                    break;
                default:
                    if ((curyear == 1) && (currentmonth >= 6))
                    {
                        output = "II YEAR";
                    }
                    else if ((curyear == 1) && (currentmonth < 6))
                    {
                        output = "I YEAR";
                    }
                    else if ((curyear == 2) && (currentmonth < 6))
                    {
                        output = "II YEAR";
                    }
                    else if ((curyear == 2) && (currentmonth >= 6))
                    {
                        output = "III YEAR";
                    }
                    else if ((curyear == 3) && (currentmonth < 6))
                    {
                        output = "III YEAR";
                    }
                    else if ((curyear == 3) && (currentmonth >= 6))
                    {
                        output = "IV YEAR";
                    }
                    break;
            }
            return output;
        }

        public string GetDept(int department)
        {
           return oApplicationDataAccess.GetDept(department);
        }
        public List<StudentModel> ViewProfileStudent(int id)
        {
            var oapplication = new ApplicationDataAccess2();
            return oapplication.ViewProfileStudent(id).Select(view => new StudentModel
                                             {
                                                 Name = view.Name, Studentid = view.Id, DOBonly1 = view.DateOfBirth.ToString().Substring(0, 9), Gender = view.Gender, Contactno = long.Parse(view.ContactNo.ToString()), Departmentname = GetDept(int.Parse(view.DepartmentId.ToString())), Emailid = view.EmailId, Yojonly = GetYear((int) view.YearOfJoining), Designation = view.Designation, Company = view.CompanyName
                                             }).ToList();
        }
        public List<FacultyModel> ViewProfilefaculty(int id)
        {
            var oapplication = new ApplicationDataAccess2();
            return oapplication.ViewProfileFaculty(id).Select(view => new FacultyModel
                                             {
                                                 Name = view.Name, Facultyid = view.Id, Gender = view.Gender, Contactno = long.Parse(view.ContactNo.ToString()), Departmentname = GetDept(int.Parse(view.DepartmentId.ToString())), Email = view.Email, Address = view.Address
                                             }).ToList();
        }
        //view Alumini Profile

        //Add Department
        public int AddDepartment(DepartmentModel odepartmentmodel)
        {
            var odepartment = new Department
                                  {
                                      Id = odepartmentmodel.Deptid,
                                      Name = odepartmentmodel.Name,
                                      Description = odepartmentmodel.Description,
                                      Vacancy = odepartmentmodel.Vacancy,
                                      Seats = odepartmentmodel.Seats
                                  };
            var oApplicationDataAccess = new ApplicationDataAccess();
            return oApplicationDataAccess.AddDepartment(odepartment);

        }
        public void DeletingFaculty(int id)
        {
            var oapplicationDataAccess = new ApplicationDataAccess();
            oapplicationDataAccess.DeletingFaculty(id);
        }

        //-----------Error Logging-------------
        public void logException(ErrorLoggingModel oerrorlogging)
        {
            var oExceptionTable = new ExceptionTable
                                      {
                                          Error = oerrorlogging.Error,
                                          ErrorTime = System.DateTime.Now,
                                          LoggedUser = oerrorlogging.Loggeduser
                                      };
            oApplicationDataAccess.InsertException(oExceptionTable);


        }
        //Enum for Semester
        public enum Semester
        {
            SELECT,
            SEM1,
            SEM2,
            SEM3,
            SEM4,
            SEM5,
            SEM6,
            SEM7,
            SEM8

        };
        //Getting Semester for dropdown
        public List<Semester> GetSemester()
        {
            // Array lis = Enum.GetValues(typeof(semester));
            var semesterlist = Enum.GetValues(typeof(Semester)).Cast<Semester>().ToList();
            return semesterlist;
        }


    }
}




