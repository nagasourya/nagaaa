﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterDataAccess;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class HomePage : System.Web.UI.Page
    {
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();
        protected void Page_Load(object sender, EventArgs e)
        {
           
            CollegeApplicationEntities oCollegeAppEntity = new CollegeApplicationEntities();
            var gtevt = from evt in oCollegeAppEntity.CollegeEvents where evt.EventsName == "General Events" select evt;
            string s1;
            s1 = "<table><tr><td>";
            foreach (var item in gtevt)
            {
                s1 += "<p style=\"font-family:Book Antiqua;font-size:medium;font-weight:bold;font-style:italic;color:white\">" + item.Comments + "</p></td>";
                s1 += "\t";
            }
            s1 += "</tr></table>";
            lt1.Text = s1.ToString();
            if (!IsPostBack)
            {
                Label olabel1 = new Label();
                Label olabel2 = new Label();
                Label olabel3 = new Label();
                Label olabel4 = new Label();
                olabel1 = (Label)Master.FindControl("lblWelcome");
                olabel2 = (Label)Master.FindControl("lblWelcomeName");
                olabel3 = (Label)Master.FindControl("lblLastLogInTime");
                olabel4 = (Label)Master.FindControl("lblLastLogIn");
                ImageButton oImageButton = new ImageButton();
                oImageButton = (ImageButton)Master.FindControl("imgbtnLogout");

                if (Session["ID"] == null)
                {
                    olabel1.Visible = false;
                    olabel2.Visible = false;
                    olabel3.Visible = false;
                    olabel4.Visible = false;
                    oImageButton.Visible = false;

                }
                else
                {
                    string username = Session["name"].ToString();
                    olabel2.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    olabel4.Text = lastdate;
                    imagebtnLogin.Visible = false;

                }
            }

        }      

        protected void ImageBtnValidate_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                int _userid = int.Parse(txtNewUserId.Text);

                switch (drpTables1.SelectedItem.Value)
                {

                    case "Faculty":
                        LogInModel oLoginModelf = new LogInModel();
                        oLoginModelf.UserId = _userid;

                        bool result = oApplicationLib.FacultyValidation(oLoginModelf);
                        Response.Write(oLoginModelf.Password);
                        if (result)
                        {
                            lblStatusandValidation1.Text = "Valid UserID";

                            if (oLoginModelf.Password == null)
                            {
                                txtNewUserId.Enabled = false;
                                ImageBtnValidate.Visible = false;
                                panelConformPassword.Visible = true;
                            }
                            else
                            {
                              //  Response.Write("<script>alert('You are already a Registered User')</script>");
                                lblStatusandValidation1.Text = "You are already a Registered User";
                            }
                        }
                        else
                        {
                            lblStatusandValidation1.Text = "Invalid UserID";
                        }

                        break;
                    case "Student":

                        LogInModel oLoginModels = new LogInModel();
                        oLoginModels.UserId = _userid;

                        result = oApplicationLib.StudentValidation(oLoginModels);
                        if (result)
                        {
                            lblStatusandValidation1.Text = "Valid UserID";

                            if (oLoginModels.Password == null)
                            {
                                txtNewUserId.Enabled = false;
                                ImageBtnValidate.Visible = false;
                                panelConformPassword.Visible = true;
                            }
                            else
                            {
                                //Response.Write("<script>alert('You are already a Registered User')</script>");
                                lblStatusandValidation1.Text = "You are already a Registered User";
                            }
                        }
                        else
                        {
                            lblStatusandValidation1.Text = "Invalid UserID";
                        }

                        break;

                    case "Alumni":
                        LogInModel oLoginModela = new LogInModel();
                        oLoginModela.UserId = _userid;

                        result = oApplicationLib.AluminiValidation(oLoginModela);
                        if (result)
                        {
                            lblStatusandValidation1.Text = "Valid UserID";

                            if (oLoginModela.Password == null)
                            {
                                txtNewUserId.Enabled = false;
                                ImageBtnValidate.Visible = false;
                                panelConformPassword.Visible = true;
                            }
                            else
                            {
                                //Response.Write("<script>alert('You are already a Registered User')</script>");
                                lblStatusandValidation1.Text = "You are already a Registered User";
                            }
                        }
                        else
                        {
                            lblStatusandValidation1.Text = "Invalid UserID";
                        }
                        break;
                }
            }
            catch (Exception)
            {
               
                lblStatusandValidation1.Text = "Invalid UserID";
            }
        }

        protected void ImageBtnSave_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                string _pwd = txtNewUserPassword.Text;
                int _newuserid = int.Parse(txtNewUserId.Text);

                switch (drpTables1.SelectedItem.Value)
                {
                    case "Faculty":


                        oApplicationLib.SaveFacultyPassword(_pwd, _newuserid);

                        lblStatusandValidation1.Text = "Your new password has been saved";


                        break;

                    case "Student":

                        oApplicationLib.SaveStudentsPassword(_pwd, _newuserid);
                        lblStatusandValidation1.Text = "Your new password has been saved";

                        break;

                    case "Alumni":

                        oApplicationLib.SaveStudentsPassword(_pwd, _newuserid);
                        lblStatusandValidation1.Text = "Your new password has been saved";

                        break;
                }

            }
            catch (Exception)
            {
                lblStatusandValidation1.Text = "Invalid User ID";

            }
        }

        protected void ImageBtnCancel_Click(object sender, ImageClickEventArgs e)
        {
            TabContainer1.Visible = false;
        }

        protected void imgbtnValidateCancel_Click(object sender, ImageClickEventArgs e)
        {
            txtNewUserId.Enabled = true;
            //TabContainer1.Visible = false;
            ImageBtnValidate.Visible = true;
        }

        protected void ImageBtnSignIn_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                int _signinid = int.Parse(txtSignInUserId.Text);
                string _password = txtSignInPassword.Text;


                switch (drpTables2.SelectedItem.Value)
                {
                    case "Student":
                        LogInModel oLogInModels = new LogInModel();
                        oLogInModels.UserId = _signinid;
                        oLogInModels.Password = _password;

                        oLogInModels = oApplicationLib.StudentSignIn(oLogInModels);
                        Session["ID"] = txtSignInUserId.Text;
                        Session["name"] = oLogInModels.Name;
                        Session["LoggedUser"] = drpTables2.SelectedItem.Text;
                        Session["LastLogIn"] = oLogInModels.LastModifiedDate;
                        if (oLogInModels.Name != null)
                        {
                            Response.Redirect("Students_view.aspx");
                        }
                        else
                        {
                            lblStatusandValidation2.Text = "Invalid UserID";
                        }

                        break;

                    case "Faculty":
                        LogInModel oLogInModelf = new LogInModel();
                        oLogInModelf.UserId = _signinid;
                        oLogInModelf.Password = _password;

                        oLogInModelf = oApplicationLib.FacultySignIn(oLogInModelf);
                        Session["ID"] = txtSignInUserId.Text;
                        Session["name"] = oLogInModelf.Name;
                        Session["LoggedUser"] = drpTables2.SelectedItem.Text;
                        Session["LastLogIn"] = oLogInModelf.LastModifiedDate;
                        if (oLogInModelf.Name != null)
                        {
                            Response.Redirect("Faculty_View.aspx");
                        }
                        else
                        {
                            lblStatusandValidation2.Text = "Invalid UserID";
                        }

                        break;
                    case "Admin":
                        LogInModel oLogInModela = new LogInModel();
                        oLogInModela.UserId = _signinid;
                        oLogInModela.Password = _password;

                        oLogInModela = oApplicationLib.AdminSignIn(oLogInModela);
                        Session["ID"] = txtSignInUserId.Text;
                        Session["name"] = oLogInModela.Name;
                        Session["LoggedUser"] = drpTables2.SelectedItem.Text;
                        Session["LastLogIn"] = oLogInModela.LastModifiedDate;
                        if (oLogInModela.Name != null)
                        {
                            Response.Redirect("Admin.aspx");
                        }
                        else
                        {
                            lblStatusandValidation2.Text = "Invalid UserID";
                        }

                        break;
                    case "Alumni":
                        LogInModel oLogInModelal = new LogInModel();
                        oLogInModelal.UserId = _signinid;
                        oLogInModelal.Password = _password;

                        oLogInModelal = oApplicationLib.AlumniSignIn(oLogInModelal);
                        Session["ID"] = txtSignInUserId.Text;
                        Session["name"] = oLogInModelal.Name;
                        Session["LoggedUser"] = drpTables2.SelectedItem.Text;
                        Session["LastLogIn"] = oLogInModelal.LastModifiedDate;
                        if (oLogInModelal.Name != null)
                        {
                            Response.Redirect("Alumini.aspx");
                        }
                        else
                        {
                            lblStatusandValidation2.Text = "Invalid UserID";
                        }

                        break;
                }

            }
            catch (Exception)
            {
                lblStatusandValidation2.Text = "Invalid UserID";
            }
        }

        protected void ImageBtnSignCancel_Click(object sender, ImageClickEventArgs e)
        {
            TabContainer1.Visible = false;
        }

      


        protected void imagebtnLogin_Click1(object sender, ImageClickEventArgs e)
        {
            TabContainer1.Visible = true;
        }

        protected void ImagebtnFeedback_Click1(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("FeedBack.aspx");
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

            Response.Redirect("UserApplicationForm.aspx");
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("UserApplicationStatus.aspx");
        }
    }
}