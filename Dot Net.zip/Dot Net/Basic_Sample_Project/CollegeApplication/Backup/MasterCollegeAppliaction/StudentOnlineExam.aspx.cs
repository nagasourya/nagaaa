﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class StudentOnlineExam : System.Web.UI.Page
    {
        ApplicationLibrary oapplicationlib = new ApplicationLibrary();

        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();  
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Label oLabel = new Label();
                Label oLabel1 = new Label();
                oLabel = (Label)Master.FindControl("lblWelcomeName");
                oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                string username = Session["name"].ToString();
                oLabel.Text = username;
                string lastdate = Session["LastLogIn"].ToString();
                oLabel1.Text = lastdate;
                string testname = Request.QueryString["test"];
                Session["timeout"] = int.Parse(Request.QueryString["duration"]);

                //var res = from r in oce.QuestionDetails select r;
                GridView1.DataSource = oapplicationlib.GetQuestion(testname);
                GridView1.DataBind();

            }
        }



        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
          
                    if (e.Row.RowType == DataControlRowType.DataRow)
                    {
                        Label lblqid = (Label)e.Row.FindControl("lblqid");
                        lblqid.Text = DataBinder.Eval(e.Row.DataItem, "QuestionId1").ToString();

                        Label lbl = (Label)e.Row.FindControl("lblques");
                        lbl.Text = DataBinder.Eval(e.Row.DataItem, "QuestionData1").ToString();


                        RadioButtonList rdbtn1 = (RadioButtonList)e.Row.FindControl("rbl");
                        rdbtn1.Items.Add(new ListItem(DataBinder.Eval(e.Row.DataItem, "Option11").ToString()));

                        rdbtn1.Items.Add(new ListItem(DataBinder.Eval(e.Row.DataItem, "Option21").ToString()));
                        rdbtn1.Items.Add(new ListItem(DataBinder.Eval(e.Row.DataItem, "Option31").ToString()));
                        rdbtn1.Items.Add(new ListItem(DataBinder.Eval(e.Row.DataItem, "Option41").ToString()));

                    }
              
        }


        public double findpercentage(int score, int count)
        {
            
                double percent = ((score * 100) / count);
                return percent;
            

        }
        public void countmarks()
        {
            try
            {
                GridView1.Enabled = false;
                int answer = 0;
                int quesid = 0;
                int result = 0;
                int score = 0;
                int count = 0;
                Label oLabel = new Label();
                Label oLabel1 = new Label();
                oLabel = (Label)Master.FindControl("lblWelcomeName");
                oLabel1 = (Label)Master.FindControl("lblLastLogIn");
                int id = int.Parse(Session["id"].ToString());
                string username = Session["name"].ToString();
                oLabel.Text = username;
                string lastdate = Session["LastLogIn"].ToString();
                oLabel1.Text = lastdate;
                string testname = Request.QueryString["test"];
                GridViewRowCollection oGvcoll = GridView1.Rows;
                List<int> l = new List<int>();
                foreach (GridViewRow row in oGvcoll)
                {
                    answer = ((RadioButtonList)row.FindControl("rbl")).SelectedIndex;
                    quesid = int.Parse(((Label)row.FindControl("lblqid")).Text);
                    count = GridView1.Rows.Count;

                    ApplicationLibrary oApplicationLibrary = new ApplicationLibrary();
                    result = oApplicationLibrary.GiveScore(quesid);
                    if (answer == result)
                    {
                        score = score + 1;
                    }

                }
                int output = (int)findpercentage(score, count);

                OnlineExamResults oOnlineResult = new OnlineExamResults();
                oOnlineResult.Studentid1 = id;
                oOnlineResult.Studentname = username;
                oOnlineResult.Testname = testname;
                oOnlineResult.Marks = output;
                ResultLibrary oapplication = new ResultLibrary();
                oapplication.InserOnlineResult(oOnlineResult);
                Lblscore.Text = "Your Score is " + output + "%";
                ErrMsgBox.AddMessage("Your Score is '" + output + "'%", MasterCollegeAppliaction.ErrorForm.enmMessageType.Info);               

                ImgBtnSubmit.Enabled = false;
            }
            catch (Exception)
            {
                Response.Redirect("EmptyPage");
            }
        }

        protected void ImgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                LnkBtnBack.Visible = true;
                countmarks();
                Timer1.Enabled = false;
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void LnkBtnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("OnlineExamChoose.aspx");
        }

        protected void Timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                hid_Ticker.Value = TimeSpan.Parse(hid_Ticker.Value).Add(new TimeSpan(0, 0, 1)).ToString();
                lbltimer.Text = "Time: " + hid_Ticker.Value.ToString();
                if (TimeSpan.Parse(hid_Ticker.Value).Minutes == int.Parse(Session["timeout"].ToString()))
                {
                    GridView1.Enabled = false;
                    countmarks();
                    Timer1.Enabled = false;
                    LnkBtnBack.Visible = true;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            string testname = Request.QueryString["test"];
            GridView1.DataSource = oapplicationlib.GetQuestion(testname);
            GridView1.PageIndex = e.NewPageIndex;
            GridView1.DataBind();
        }



    }
}