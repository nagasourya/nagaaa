﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;
namespace MasterCollegeAppliaction
{
    public partial class AddEventForm : System.Web.UI.Page
    {
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();
        protected void Page_Load(object sender, EventArgs e)
        {
           if (!IsPostBack)
                {
                    var oLabel1 = new Label();
                    var oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    var username = Session["name"].ToString().ToUpper();
                    oLabel.Text = username;
                    var lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                }
          
            
        }
      

        protected void ImgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                var oAdminEvtMod = new AdminViewEventMod
                                       {
                                           Eventname = ddwnevts.SelectedValue,
                                           Comments = txtevtcmts.Text
                                       };
                var date = DateTime.Parse(txtdate.Text);
                if (date > DateTime.Now)
                {
                    oAdminEvtMod.Eventdate = date;


                    var x = oApplicationLib.SubmitEvent(oAdminEvtMod);
                    switch (x)
                    {
                        case 1:
                            ErrMsgBox.AddMessage("Events Added Successfully.", MasterCollegeAppliaction.ErrorForm.enmMessageType.Success);
                            txtevtcmts.Text = "";
                            txtevtcmts.Text = "";
                            txtdate.Text = "";
                            break;
                        default:
                            ErrMsgBox.AddMessage("Updating Events Failed..Check Details ..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Error);
                            break;
                    }
                }
                else
                {
                    ErrMsgBox.AddMessage("Give Date Greater than Present Date", MasterCollegeAppliaction.ErrorForm.enmMessageType.Attention);
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");    
            }

        }

      
        protected void ImgBtnClose_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                txtevtcmts.Text = "";
                txtdate.Text = "";
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void LnkBtnAddEvent_Click(object sender, EventArgs e)
        {

        }

        protected void LnkBtnAddCmpny_Click1(object sender, EventArgs e)
        {
            try
            {
                PnlVwEvents.Visible = false;
                PnlAddEvt.Visible = true;
                lblVwevt.Visible = false;
                LblAddEvtTitle.Visible = true;
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void LnkBtnHome_Click(object sender, EventArgs e)
        {
          
                Response.Redirect("Admin.aspx");
          
        }

        protected void LnkBtnVwEvt_Click(object sender, EventArgs e)
        {
            try
            {
                lblVwevt.Visible = true;
                LblAddEvtTitle.Visible = false;
                PnlAddEvt.Visible = false;
                PnlVwEvents.Visible = true;
                GrdVwEvent.DataSource = oApplicationLib.ViewEvents();
                GrdVwEvent.DataBind();
                if (GrdVwEvent.Rows.Count == 0)
                {
                    lblErr.Visible = true;
                    lblErr.Text = "No Data Found!!!!!!!!!!!";
                    GrdVwEvent.Visible = false;
                    
                }
                else
                {
                    lblErr.Visible = false;
                    GrdVwEvent.Visible = true;
                  
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void ImgBtnSubmitDate_Click(object sender, ImageClickEventArgs e)
        {
            try
            {

                var oAdminMod = new AdminViewEventMod
                                    {
                                        Fromdate = DateTime.Parse(txtdate1.Text),
                                        Todate = DateTime.Parse(txtdate2.Text)
                                    };
                var gtevtname = oApplicationLib.GetEvent(oAdminMod);
                GrdVwEvent.DataSource = gtevtname;
                GrdVwEvent.DataBind();
                if (GrdVwEvent.Rows.Count == 0)
                {
                    lblVwEvtErr.Visible = true;
                    GrdVwEvent.Visible = false;
                }
                else
                {
                    lblVwEvtErr.Visible = false;
                    GrdVwEvent.Visible = true;
                }
            }
            catch(Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }       

       
    }
}