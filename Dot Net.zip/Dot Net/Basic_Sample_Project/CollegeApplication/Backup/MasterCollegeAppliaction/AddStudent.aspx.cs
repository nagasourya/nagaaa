﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class AddStudent : System.Web.UI.Page
    {
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();   
        ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    string username = Session["name"].ToString();
                    oLabel.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                    drp_deptname.DataSource = oapplicationlibrary.GetDeptList();
                    drp_deptname.DataBind();
                   
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
              
            }
        }

       

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
               
                StudentModel ostudentmodel = new StudentModel();
                //  ostudentmodel.Studentid=int.Parse(TextBox1.Text);
                ostudentmodel.Gender = drp_Gender.SelectedValue;
                ostudentmodel.Emailid = txtEmail.Text;
                ostudentmodel.Contactno = long.Parse(txtContact.Text);
                ostudentmodel.Address = txtAddr.Text;
                ostudentmodel.Name = txt_name.Text;
                ostudentmodel.Departmentid = oapplicationlibrary.ConvertingDeptId(drp_deptname.SelectedItem.Text);
                ostudentmodel.Dob = DateTime.Parse(txt_dob.Text);
                ostudentmodel.Yoj = int.Parse(txt_yoj.Text);

                int yoj = int.Parse(txt_yoj.Text);
                ostudentmodel.Yop = yoj + 4;
                ostudentmodel.Lastmodified = System.DateTime.Now;

                int x = oapplicationlibrary.AddStudent(ostudentmodel);
                if (x == 1)
                {
                    ErrMsgBox.AddMessage("Added Student..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Success);
                    // Response.Redirect("Admin_Student.aspx");
                }
                else
                {
                    ErrMsgBox.AddMessage("Error in Adding  Student..Pls Check the Details..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Error);
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
          ;
            }
           
        }

        protected void LnkBtnBakHome_Click(object sender, EventArgs e)
        {
         
                Response.Redirect("Admin_Student.aspx");
           
        }

        protected void ImgBtnClear_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                txt_dob.Text = "";
                txt_name.Text = "";
                txt_yoj.Text = "";
                txtAddr.Text = "";
                txtContact.Text = "";
                txtEmail.Text = "";
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
              
            }
        }

       
    }
}