﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MasterCollegeAppliaction
{
    public partial class Contact_Us : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label oLabel = new Label();
            Label oLabel1 = new Label();        
            Label olabel2 = new Label();
            Label olabel3 = new Label();
            olabel2 = (Label)Master.FindControl("lblWelcome");
            olabel2.Visible = false;
            olabel3 = (Label)Master.FindControl("lblLastLogInTime");
            olabel3.Visible = false;

            oLabel = (Label)Master.FindControl("lblWelcomeName");
            oLabel.Visible = false;
            oLabel1 = (Label)Master.FindControl("lblLastLogIn");
            oLabel1.Visible = false;
            ImageButton oImgButton = new ImageButton();
            oImgButton = (ImageButton)Master.FindControl("imgbtnLogout");
            oImgButton.Visible = false;
        }
    }
}