﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class ChangePassword : System.Web.UI.Page
    {
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();
        ApplicationLibrary oApplicationLib = new ApplicationLibrary(); 
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Label oLabel = new Label();
                Label oLabel1 = new Label();
                oLabel = (Label)Master.FindControl("lblWelcomeName");
                oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                string username = Session["name"].ToString();
                oLabel.Text = username;
                string lastdate = Session["LastLogIn"].ToString();
                oLabel1.Text = lastdate;
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
               
            }

        }
        

        protected void ImgBtnSavePassword_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                string _oldpassword = txtOldPassword.Text;
                string _newpassword = txtNewPassword.Text;

                LogInModel oLogInModel = new LogInModel();

                oLogInModel.UserId = int.Parse(Session["ID"].ToString());
                oLogInModel.Oldpassword = _oldpassword;
                oLogInModel.NewPassword = _newpassword;

                if (Session["LoggedUser"].ToString() == "Student")
                {
                    oLogInModel = oApplicationLib.ChangeStudentPassword(oLogInModel);
                    lblPasswordChanged.Visible = true;

                    if (oLogInModel.Oldpassword == _oldpassword)
                    {

                        lblPasswordChanged.Text = "Your password has been changed";
                    }
                    else
                    {
                        lblPasswordChanged.Text = "Your Old Password Is Wrong.";
                    }
                }
                else if (Session["LoggedUser"].ToString() == "Faculty")
                {
                    oLogInModel = oApplicationLib.ChangeFacultyPassword(oLogInModel);
                    lblPasswordChanged.Visible = true;
                    if (oLogInModel.Oldpassword == _oldpassword)
                    {

                        lblPasswordChanged.Text = "Your password has been changed";
                    }
                    else
                    {
                        lblPasswordChanged.Text = "Your Old Password Is Wrong.";
                    }

                }
                else if (Session["LoggedUser"].ToString() == "Admin")
                {
                    oLogInModel = oApplicationLib.ChangeAdminPassword(oLogInModel);
                    lblPasswordChanged.Visible = true;

                    if (oLogInModel.Oldpassword == _oldpassword)
                    {

                        lblPasswordChanged.Text = "Your password has been changed";
                    }
                    else
                    {
                        lblPasswordChanged.Text = "Your Old Password Is Wrong.";
                    }

                }
                else if (Session["LoggedUser"].ToString() == "Alumni")
                {
                    oLogInModel = oApplicationLib.ChangeStudentPassword(oLogInModel);
                    lblPasswordChanged.Visible = true;
                    if (oLogInModel.Oldpassword == _oldpassword)
                    {

                        lblPasswordChanged.Text = "Your password has been changed";
                    }
                    else
                    {

                        lblPasswordChanged.Text = "Your Old Password Is Wrong.";
                    }
                }
                else
                {
                    LblInvalidPwd.Text = "Your password has not been changed";
                    LblInvalidPwd.Visible = true;
                }
            }
            catch (Exception ex)
            {

                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
          
        }

       

        protected void LnkBtnHome_Click(object sender, EventArgs e)
        {
            
                if (Session["LoggedUser"].ToString() == "Student")
                {
                    Response.Redirect("Students_view.aspx");
                }
                else if (Session["LoggedUser"].ToString() == "Faculty")
                {
                    Response.Redirect("Faculty_View.aspx");
                }
                else if (Session["LoggedUser"].ToString() == "Admin")
                {
                    Response.Redirect("Admin.aspx");
                }
                else if (Session["LoggedUser"].ToString() == "Alumni")
                {
                    Response.Redirect("Alumini.aspx");
                }
        

        }

        protected void ImgBtnCancel_Click1(object sender, ImageClickEventArgs e)
        {
            txtConformPassword.Text = "";
            txtNewPassword.Text = "";
            txtOldPassword.Text = "";
        }
    }
}