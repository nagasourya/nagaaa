﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class AddExamSchedule : System.Web.UI.Page
    {
        ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                Label oLabel = new Label();
                Label oLabel1 = new Label();
                oLabel = (Label)Master.FindControl("lblWelcomeName");
                oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                string username = Session["name"].ToString();
                oLabel.Text = username;
                string lastdate = Session["LastLogIn"].ToString();
                oLabel1.Text = lastdate;
                int dt = (System.DateTime.Now.Year) + 4;
                for (int i = 0; i <= 8; i++)
                {
                    ListItem ilist = new ListItem();
                    ilist.Value = (dt - i).ToString();
                    drp_year.Items.Add(ilist);

                }
                drp_deptment.DataSource = oapplicationlibrary.GetDeptList();
                drp_deptment.DataBind();
                drp_semester.DataSource = oapplicationlibrary.GetSemester();
                drp_semester.DataBind();
            }
        }



        protected void LnkBtnAddCmpny_Click1(object sender, EventArgs e)
        {
            Response.Redirect("ExamSchedule.aspx");
        }

        protected void ImgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                int presentyear = int.Parse(drp_year.SelectedItem.Text);
                string sem = drp_semester.SelectedItem.Text;
                string dept = drp_deptment.SelectedItem.Text;
                int dpt = oapplicationlibrary.ConvertingDeptId(dept);
                var gtsub = oapplicationlibrary.GetSubject(sem, dpt);
                GridView1.DataSource = gtsub;
                GridView1.DataBind();
                if (gtsub.Count == 0)
                {
                    GridView1.Visible = false;
                    lblErr.Visible = true;
                    lblErr.Text = "No Exams List Available..";
                    ImgBtnSave.Visible = false;
                }
                else
                {
                    GridView1.Visible = true;

                    ImgBtnSave.Visible = true;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");

            }
        }

        protected void ImgBtnSave_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
                List<ExamModel> examlist = new List<ExamModel>();
                GridViewRowCollection rows = GridView1.Rows;
                int year = 0;
                string sem = "";
                string dept = "";
                bool value = false;
                bool IsCorrect = true;

                foreach (GridViewRow row in rows)
                {
                    if (DateTime.Parse(((TextBox)row.FindControl("Txt_date")).Text) > System.DateTime.Now)
                    {

                        year = int.Parse(drp_year.SelectedValue);
                        sem = ((Label)row.FindControl("lbl_semester")).Text;
                        dept = ((Label)row.FindControl("lbl_dept")).Text;
                        examlist.Add(new ExamModel { Semester = ((Label)row.FindControl("lbl_semester")).Text, Department = oapplicationlibrary.ConvertingDeptId(((Label)row.FindControl("lbl_dept")).Text), Subject = ((Label)row.FindControl("lbl_subject")).Text, Code = int.Parse(((Label)row.FindControl("lbl_code")).Text), OnDate = DateTime.Parse(((TextBox)row.FindControl("Txt_date")).Text), Year = int.Parse(drp_year.SelectedValue) });

                    }
                    else
                    {

                        IsCorrect = false;
                        break;
                    }
                }

                if (IsCorrect == true)
                {
                    int deptid = oapplicationlibrary.ConvertingDeptId(dept);
                    value = oapplicationlibrary.Inserttable(examlist, year, sem, deptid);
                    if (value == true)
                    {

                        ErrMsgBox.AddMessage("Schedule Saved..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Success);
                    }
                    else
                    {

                        ErrMsgBox.AddMessage("Schedule not saved..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Error);
                    }
                }
                else
                {
                    ErrMsgBox.AddMessage("Give date greater than present date..Pls Check the Date..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Attention);
                }

            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }
    }
}
