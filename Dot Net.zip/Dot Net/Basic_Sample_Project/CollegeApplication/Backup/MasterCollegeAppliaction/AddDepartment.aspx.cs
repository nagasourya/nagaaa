﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class AddDepartment : System.Web.UI.Page
    {
        ApplicationLibrary oapplicationlib = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var oLabel1 = new Label();
                var oLabel = (Label)Master.FindControl("lblWelcomeName");
                oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                var username = Session["name"].ToString();
                oLabel.Text = username;
                var lastdate = Session["LastLogIn"].ToString();
                oLabel1.Text = lastdate;
            }

        }

        protected void ImgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                var saved = 0;
                var odepartmentmod = new DepartmentModel
                                         {
                                             Deptid = int.Parse(TxtDeptId.Text),
                                             Name = TxtDeptName.Text,
                                             Description = TxtDescription.Text,
                                             Vacancy = int.Parse(TxtVacancy.Text),
                                             Seats = int.Parse(TxtSeats.Text)
                                         };
                saved = oapplicationlib.AddDepartment(odepartmentmod);
                switch (saved)
                {
                    case 1:
                        LblErr.Visible = true;
                        LblErr.Text = "Deparment Added Successfully..";
                        break;
                    default:
                        LblErr.Visible = true;
                        LblErr.Text = "Adding Deparment Failed!!!";
                        break;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }
        

        protected void LnkBtnbck_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin.aspx");
        }
    }
}