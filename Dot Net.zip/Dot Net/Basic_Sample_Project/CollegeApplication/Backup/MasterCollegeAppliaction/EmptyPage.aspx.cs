﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MasterCollegeAppliaction
{
    public partial class EmptyPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          

        }

        protected void lnkbtnhome_Click(object sender, EventArgs e)
        {
            if (Session["LoggedUser"] == null)
            {
                Response.Redirect("HomePage.aspx");
            }
            else
            {
                string s = Session["LoggedUser"].ToString();

                switch (s)
                {
                    case "Student":
                        Response.Redirect("Students_view.aspx");
                        break;
                    case "Faculty":
                        Response.Redirect("Faculty_View.aspx");
                        break;
                    case "Admin":
                        Response.Redirect("Admin.aspx");

                        break;
                    case "Alumni":
                        Response.Redirect("Alumini.aspx");
                        break;
                }
            }
        }
    }
}