﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class OnlinExamChoose : System.Web.UI.Page
    {
        string Testname = "";
        int duration = 0;
        ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();   
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
               
                GridView1.DataSource = oapplicationlibrary.GetTest();
                GridView1.DataBind();
                if (!IsPostBack)
                {
                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    string username = Session["name"].ToString();
                    oLabel.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            
                string j = "";
                if (e.CommandName == "SAVE")
                {
                    Testname = e.CommandArgument.ToString();
                    GridViewRowCollection rows = GridView1.Rows;
                    foreach (GridViewRow row in rows)
                    {
                        if (((LinkButton)row.Cells[0].FindControl("lbltestname")).Text.Equals(Testname))
                        {
                            j = ((Label)row.Cells[1].FindControl("lblduration")).Text;
                            duration = int.Parse(j);


                            //  Response.Write(j);
                            break;
                        }
                    }

                }
                Response.Redirect("StudentOnlineExam.aspx?test=" + Testname + "&duration=" + duration);
           

        }

        protected void lnkbtnhome_Click(object sender, EventArgs e)
        {
            Response.Redirect("Students_view.aspx");
        }
    }
}