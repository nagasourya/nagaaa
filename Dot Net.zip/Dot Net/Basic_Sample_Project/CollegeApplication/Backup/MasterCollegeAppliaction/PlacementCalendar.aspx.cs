﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;
namespace MasterCollegeAppliaction
{
    public partial class PlacementCalendar : System.Web.UI.Page
    {
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();   
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    string username = Session["name"].ToString();
                    oLabel.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void LnkBtnAddCal_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddCalender.aspx");
        }

        protected void lnkBtnVwCal_Click(object sender, EventArgs e)
        {
            try
            {
                PnlVwCal.Visible = true;
                GrdPlacemnt.Visible = true;
                ApplicationLibrary oApplicationLib = new ApplicationLibrary();
                GrdPlacemnt.DataSource = oApplicationLib.GetPlacementCalender();
                GrdPlacemnt.DataBind();
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void LnkBtnBakHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin.aspx");
        }

      
    }
}