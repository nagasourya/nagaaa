﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class AdmissionApproval : System.Web.UI.Page
    {
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();   
        protected void Page_Load(object sender, EventArgs e)
        {
            load();            
            if (!IsPostBack)
            {

                //Label oLabel = new Label();
                //Label oLabel1 = new Label();
                //oLabel = (Label)Master.FindControl("lblWelcomeName");
                //oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                //string username = Session["name"].ToString();
                //oLabel.Text = username;
                //string lastdate = Session["LastLogIn"].ToString();
                //oLabel1.Text = lastdate;
                DropDownList2.DataSource = oApplicationLib.GetDeptList();
                DropDownList2.DataBind();
            }
        }
        void load_appln()
        {
            try
            {
                GridView2.Columns[5].Visible = true;
                GridView2.Columns[4].Visible = true;
                string dept = DropDownList2.SelectedItem.Text;
                GridView2.DataSource = oApplicationLib.GetUserform(dept);
                GridView2.DataBind();
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                ///oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }
        void load()
        {
            try
            {
                List<DepartmentModel> oDeptMod = new List<DepartmentModel>();
                oDeptMod = oApplicationLib.GetDepartment();
                GridView1.DataSource = oDeptMod;
                GridView1.DataBind();

            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                //oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }
    

        protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                string dept = DropDownList2.SelectedItem.Text;
                string j = "";
                int id;
                if (e.CommandName == "SAVE")
                {
                    string apid = e.CommandArgument.ToString();
                    GridViewRowCollection rows = GridView2.Rows;
                    foreach (GridViewRow row in rows)
                    {
                        if (((Label)row.Cells[0].FindControl("lbl_appid")).Text.Equals(apid))
                        {
                            j = ((DropDownList)row.Cells[1].FindControl("DropDownList1")).SelectedValue;

                            break;
                        }
                    }
                    id = int.Parse(apid);

                    oApplicationLib.UpdateStatus(id, j);
                    oApplicationLib.UpdateVacancy(dept, j);
                    load();
                    load_appln();
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                //oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                string status = DropDownList3.SelectedItem.Text;
                if (status == "Pending")
                {
                    // LblShowStatus .Text = "pending list";
                    GridView2.Columns[4].Visible = false;
                    GridView2.Columns[5].Visible = false;


                    GridView2.DataSource = oApplicationLib.GetUserformOnStatus(status);
                    GridView2.DataBind();
                }
                else if (status == "accepted")
                {
                    //GridView2.SelectedRow.Cells[4].Enabled = false;
                    // LblShowStatus.Text = "accepted list";
                    GridView2.Columns[5].Visible = false;
                    GridView2.Columns[4].Visible = false;

                    GridView2.DataSource = oApplicationLib.GetUserformOnStatus(status);
                    GridView2.DataBind();

                }
                else
                {
                    // LblShowStatus.Text = "rejected list";
                    GridView2.Columns[5].Visible = false;
                    GridView2.Columns[4].Visible = false;

                    GridView2.DataSource = oApplicationLib.GetUserformOnStatus(status);
                    GridView2.DataBind();
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                //oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            load_appln();
            DropDownList3.Visible = false;
            Label2.Visible = false;
        }

        protected void LnkBtnBakHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin.aspx");
        }

        protected void LnkBtnChkStatus_Click(object sender, EventArgs e)
        {
            availadmission.Visible = false;
            Label2.Visible = true;
            DropDownList3.Visible = true;
           // PnlAvailAdmission.Visible = false;
            ImgBtnClose.Visible = true;
        }

        protected void ImgBtnClose_Click(object sender, ImageClickEventArgs e)
        {
            availadmission.Visible = true;
            Label2.Visible = false;
            DropDownList3.Visible = false;
            ImgBtnClose.Visible = false;
            //PnlAvailAdmission.Visible = true;
        }
    }
}