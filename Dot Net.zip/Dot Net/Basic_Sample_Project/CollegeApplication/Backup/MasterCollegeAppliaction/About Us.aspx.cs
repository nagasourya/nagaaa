﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MasterCollegeAppliaction
{
    public partial class About_Us : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var olabel2 = (Label)Master.FindControl("lblWelcome");
                olabel2.Visible = false;
                var olabel3 = (Label)Master.FindControl("lblLastLogInTime");
                olabel3.Visible = false;

                var oLabel = (Label)Master.FindControl("lblWelcomeName");
                oLabel.Visible = false;
                var oLabel1 = (Label)Master.FindControl("lblLastLogIn");
                oLabel1.Visible = false;
                var oImgButton = (ImageButton)Master.FindControl("imgbtnLogout");
                oImgButton.Visible = false;
            }

        }
    }
}