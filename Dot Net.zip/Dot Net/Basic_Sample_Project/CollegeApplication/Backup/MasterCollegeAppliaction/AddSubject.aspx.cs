﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class AddSubject : System.Web.UI.Page
    {
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    var oLabel = (Label)Master.FindControl("lblWelcomeName");
                    var oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    var username = Session["name"].ToString();
                    oLabel.Text = username;
                    var lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                    DropDownList1.DataSource = oApplicationLib.GetDeptList();
                    DropDownList1.DataBind();
                    DropDownList2.DataSource = oApplicationLib.GetSemester();
                    DropDownList2.DataBind();
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);                  
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void ImgBtnSave_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                var code = int.Parse(txtsubcode.Text);

                var dept = DropDownList1.SelectedItem.Text;
                var dpt = oApplicationLib.ConvertingDeptId(dept);
                var osubjectmodel = new SubjectModel();
                osubjectmodel.Department = dpt;
                osubjectmodel.Semester = DropDownList2.SelectedItem.Text;
                osubjectmodel.Subject = txtsubname.Text;
                osubjectmodel.Code = int.Parse(txtsubcode.Text);
                //  osubjectmodel.Year = int.Parse(DropDownList3.SelectedItem.Text);

                var value = oApplicationLib.Addsubject(osubjectmodel, code);
                if (value != true)
                {
                    ErrMsgBox.AddMessage("Subject already entered..",
                                         ErrorForm.enmMessageType.Attention);
                }
                else
                {
                    ErrMsgBox.AddMessage("Subject Entered..", ErrorForm.enmMessageType.Success);
                }
                txtsubcode.Text = "";
                txtsubname.Text = "";
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
               
            }
        }

        protected void ImgBtnCancel_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                txtsubcode.Text = "";
                txtsubname.Text = "";
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");               
            }
        }

        protected void LnkBtnbck_Click(object sender, EventArgs e)
        {

            Response.Redirect("Admin.aspx");

        }
    }
}