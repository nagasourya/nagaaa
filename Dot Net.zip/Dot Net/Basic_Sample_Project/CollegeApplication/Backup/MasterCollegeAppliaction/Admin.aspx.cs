﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class Admin : System.Web.UI.Page
    {
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();   
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Label oLabel = new Label();
                Label oLabel1 = new Label();
                oLabel = (Label)Master.FindControl("lblWelcomeName");
                oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                string username = Session["name"].ToString().ToLowerInvariant();
                oLabel.Text = username;
                string lastdate = Session["LastLogIn"].ToString();
                oLabel1.Text = lastdate;
            }
        }
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();      

        protected void ImgBtnAddEvents_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("AddEventForm.aspx");
        }

        protected void ImgBtnViewEvents_Click(object sender, ImageClickEventArgs e)
        {
            //PnlVwEvt.Visible = true;
        }

       
        protected void lnkbtnOnlineExam_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin_OnlineExam.aspx");
        }

        protected void lnkbtnClassSchedule_Click(object sender, EventArgs e)
        {
            Response.Redirect("ClassSchedule.aspx");
        }

        protected void lnkbtnExaminationSchedule_Click(object sender, EventArgs e)
        {
            Response.Redirect("ExamSchedule.aspx");
        }

        protected void lnkbtnResults_Click(object sender, EventArgs e)
        {
            Response.Redirect("StudentResult.aspx");
        }

        protected void lnkbtnPlacementDetails_Click(object sender, EventArgs e)
        {
            Response.Redirect("PlacementCalendar.aspx");
        }

        protected void lnkbtnAlumniDetails_Click(object sender, EventArgs e)
        {
            try
            {
                int dt = int.Parse(DateTime.Now.Year.ToString());
                PnlViewAlumini.Visible = true;
                for (int i = 0; i < 9; i++)
                {
                    ListItem ilist = new ListItem();
                    ilist.Value = (dt - i).ToString();
                    drpdwnyop.Items.Add(ilist);

                }
                ApplicationLibrary oApplicationLib = new ApplicationLibrary();
                var getalumini = oApplicationLib.viewAlumini();
                GrdVwAlumini.DataSource = getalumini;
                GrdVwAlumini.DataBind();
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void lnkbtnAssignments_Click(object sender, EventArgs e)
        {
            Response.Redirect("OnlinExamChoose.aspx");
        }

        protected void ImgBtnClose_Click(object sender, ImageClickEventArgs e)
        {
            PnlViewAlumini.Visible = false;
        }

        protected void ImgBtnSearchSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                ApplicationLibrary oApplicationLib = new ApplicationLibrary();
                string yop = "SELECT";
                string s = txtsearch.Text;
                yop = drpdwnyop.SelectedItem.Text;
                if (s.Equals("") && (yop.Equals("SELECT")))
                {
                    ErrMsgBox.AddMessage("Please Enter Name or Choose Year Of passed Out to Search..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Attention);
                }
                else if (!(s.Equals("")) && !(yop.Equals("SELECT")))
                {
                    //yop = int.Parse(drpdwnyop.SelectedItem.Value.ToString());
                    var getalumini = oApplicationLib.viewAlumini(s, int.Parse(yop));
                    GrdVwAlumini.DataSource = getalumini;
                    GrdVwAlumini.DataBind();
                }
                else if ((s.Equals("")) && !(yop.Equals("SELECT")))
                {
                    //yop = int.Parse(drpdwnyop.SelectedItem.Value.ToString());
                    var getalumini = oApplicationLib.viewAlumini(int.Parse(yop));
                    GrdVwAlumini.DataSource = getalumini;
                    GrdVwAlumini.DataBind();
                }
                else if (!(s.Equals("")) && (yop.Equals("SELECT")))
                {
                    var getalumini = oApplicationLib.viewAlumini(s);
                    GrdVwAlumini.DataSource = getalumini;
                    GrdVwAlumini.DataBind();
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }       

        protected void lnkbtnAdmAppr_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdmissionApproval.aspx");
        }

        protected void LnkBtnStudent_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin_Student.aspx");
        }

        protected void LnkBtnFaculty_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin_Faculty.aspx");
        }

      
        protected void LnkBtnAddSub_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddSubject.aspx");
        }

        protected void LnkBtnChngPwd_Click(object sender, EventArgs e)
        {
            Response.Redirect("ChangePassword.aspx");
        }

        protected void LnkBtnEvents_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddEventForm.aspx");
        }

        protected void lnkbtnClassSchedule_Click1(object sender, EventArgs e)
        {
            Response.Redirect("ClassSchedule.aspx");
        }

        protected void LnkBtnAddDept_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddDepartment.aspx");
        }
    }
}