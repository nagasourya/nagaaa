﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;



namespace MasterCollegeAppliaction
{

    public partial class AddQuestions : System.Web.UI.Page
    {
        ApplicationLibrary oApplicationLibrary = new ApplicationLibrary();

        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();
        protected void Page_Load(object sender, EventArgs e)
        {
             if (!IsPostBack)
                {
                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    string username = Session["name"].ToString();
                    oLabel.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                    GridView1.DataSource = oApplicationLibrary.GetTestName();
                    GridView1.DataBind();
                }
          
        }
        
        

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
          

                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    DropDownList ddl = (DropDownList)e.Row.FindControl("drpdwnTest");
                    ddl.DataSource = oApplicationLibrary.GetTestName();
                    ddl.DataBind();

                }
           
        }

      
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                List<QuestionModel> oList = new List<QuestionModel>();
                GridViewRowCollection rows = GridView1.Rows;
                foreach (GridViewRow row in rows)
                {
                    if ((((((TextBox)row.FindControl("txtQuestion"))).Text) != string.Empty) && (((((TextBox)row.FindControl("txtOption1"))).Text) != string.Empty) && (((((TextBox)row.FindControl("txtOption2"))).Text) != string.Empty) && (((((TextBox)row.FindControl("txtOption3"))).Text) != string.Empty) && (((((TextBox)row.FindControl("txtOption4"))).Text) != string.Empty))
                    {
                        oList.Add(new QuestionModel
                        {
                            TestName1 = (((DropDownList)row.FindControl("drpdwnTest")).Text),
                            QuestionData1 = ((((TextBox)row.FindControl("txtQuestion"))).Text),
                            Option11 = ((((TextBox)row.FindControl("txtOption1"))).Text),
                            Option21 = (((TextBox)row.FindControl("txtOption2")).Text),
                            Option31 = (((TextBox)row.FindControl("txtOption3")).Text),
                            Option41 = (((TextBox)row.FindControl("txtOption4")).Text),
                            CorrectData1 = int.Parse(((DropDownList)row.FindControl("CorrectOption")).Text)
                        });
                        ApplicationLibrary oapplicationlib = new ApplicationLibrary();
                        oapplicationlib.StoreQuestion(oList);
                        GridView1.Enabled = false;
                        ImgBtnAddQuest.Visible = true;
                    }

                } ErrMsgBox.AddMessage("Questions Added Successfully..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Success);
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx"); 
              
            }
           
        }

        protected void LnkBtnBack_Click(object sender, EventArgs e)
        {
           
                Response.Redirect("Admin_OnlineExam.aspx");
          
        }

        protected void ImgBtnAddQuest_Click(object sender, ImageClickEventArgs e)
        {
            ImgBtnAddQuest.Visible = false;
            GridView1.Enabled = true;
            GridView1.DataSource = oApplicationLibrary.GetTestName();
            GridView1.DataBind();
        }
    }
}