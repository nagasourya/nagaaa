﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
     partial class ExamSchedule : System.Web.UI.Page
    {
        ApplicationLibrary oApplicationLibrary = new ApplicationLibrary();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    string username = Session["name"].ToString();
                    oLabel.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                    int dt = (System.DateTime.Now.Year) + 4;
                    for (int i = 0; i <=8; i++)
                    {
                        ListItem ilist = new ListItem();
                        ilist.Value = (dt - i).ToString();
                        drp_year.Items.Add(ilist);

                    }
                }
            }
            catch (Exception)
            {
                Response.Redirect("EmptyPage");
            }
        }      
              

        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            Response.Redirect("RescheduleExam.aspx");
        }
      

        protected void LnkBtnVwSchedule_Click(object sender, EventArgs e)
        {
            PnlVwSchedule.Visible = true;
            drp_dept.DataSource = oApplicationLibrary.GetDeptList();
            drp_dept.DataBind();
            drp_semester.DataSource = oApplicationLibrary.GetSemester();
            drp_semester.DataBind();
        }

        protected void LnkBtnAddExSchedule_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddExamSchedule.aspx");
        }

        protected void ImgBtnSched_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
               
                int year = int.Parse(drp_year.SelectedItem.Text);
                int dept = oApplicationLibrary.ConvertingDeptId(drp_dept.SelectedItem.Text);
                string sem = drp_semester.SelectedItem.Text;

                GrdVwSched.DataSource = oApplicationLibrary.ViewSchedule(year, dept, sem);
                GrdVwSched.DataBind();
                if (GrdVwSched.Rows.Count == 0)
                {
                    lblerrormsg.Text = "Exam is not Scheduled";
                    lblerrormsg.Visible = true;
                    GrdVwSched.Visible = false;
                }
                else
                {
                    lblerrormsg.Visible = false;
                    GrdVwSched.Visible = true;
                }
            }
            catch (Exception)
            {
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void LnkBtnReschedEx_Click(object sender, EventArgs e)
        {
            Response.Redirect("RescheduleExam.aspx");
        }


      
    }
}