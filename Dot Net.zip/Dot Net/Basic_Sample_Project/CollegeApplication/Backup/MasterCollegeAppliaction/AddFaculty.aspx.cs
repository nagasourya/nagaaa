﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class AddFaculty : System.Web.UI.Page
    {
        ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
        ErrorLoggingModel  oerrorlogging=new ErrorLoggingModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Label oLabel = new Label();
                Label oLabel1 = new Label();
                oLabel = (Label)Master.FindControl("lblWelcomeName");
                oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                string username = Session["name"].ToString();
                oLabel.Text = username;
                string lastdate = Session["LastLogIn"].ToString();
                oLabel1.Text = lastdate;
                drp_deptname.DataSource = oapplicationlibrary.GetDeptList();
                drp_deptname.DataBind();
            }
        }
        int deptid = 0;
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                FacultyModel ofacultymodel = new FacultyModel();
                deptid = oapplicationlibrary.ConvertingDeptId(drp_deptname.SelectedValue);
                ofacultymodel.Department = deptid;
                ofacultymodel.Subjectcode = oapplicationlibrary.GetSubjectCode(drp_subject.SelectedValue);
                ofacultymodel.Name = txt_name.Text;
                ofacultymodel.Email = txtEmail.Text;
                ofacultymodel.Gender = dr_gender.SelectedItem.Text;
                ofacultymodel.Doj = int.Parse(txtdate.Text);
                ofacultymodel.Contactno = long.Parse(Txt_contactno.Text);
                ofacultymodel.Address = Txt_Adress.Text;
                ofacultymodel.Lastmodified = System.DateTime.Now;

                int val = oapplicationlibrary.AddFaculty(ofacultymodel);
                if (val == 1)
                {
                    ErrMsgBox.AddMessage("Added Faculty..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Success);

                }
                else
                {
                    ErrMsgBox.AddMessage("Error in Adding  Faculty..Pls Check the Details..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Error);
                }

            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx"); 
            }
           
        }

        protected void drp_deptname_SelectedIndexChanged(object sender, EventArgs e)
        {
            //StudentLib ostudentlib = new StudentLib();
            ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
            deptid = oapplicationlibrary.ConvertingDeptId(drp_deptname.SelectedItem.Text);

            drp_subject.DataSource = oapplicationlibrary.GetSubjectOnDept(deptid);
            drp_subject.DataBind();
        }

        protected void LnkBtnBak_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin_Faculty.aspx");
        }

        protected void ImgBtnClear_Click(object sender, ImageClickEventArgs e)
        {
            txt_name.Text = "";
            txtdate.Text = "";
            Txt_contactno.Text = "";
            Txt_Adress.Text = "";
            txtEmail.Text = "";
        }

      
    }
}