﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class StudentsAndFaculties : System.Web.UI.Page
    {
        int userid = 0;       
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                Label oLabel = new Label();
                Label oLabel1 = new Label();
                oLabel = (Label)Master.FindControl("lblWelcomeName");
                oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                string username = Session["name"].ToString();
                oLabel.Text = username;
                string lastdate = Session["LastLogIn"].ToString();
                oLabel1.Text = lastdate;
                studentview.Visible = true;

                userid = int.Parse(Session["ID"].ToString());
                ApplicationLibrary oapplication = new ApplicationLibrary();
                studentview.DataSource = oapplication.ViewProfileStudent(userid);
                studentview.DataBind();
            }
        }

        public void GetSessionList()
        {
            Label oLabel = new Label();
            Label oLabel1 = new Label();
            oLabel = (Label)Master.FindControl("lblWelcomeName");
            oLabel1 = (Label)Master.FindControl("lblLastLogIn");

            string username = Session["name"].ToString();
            oLabel.Text = username;
            string lastdate = Session["LastLogIn"].ToString();
            oLabel1.Text = lastdate;
            userid = int.Parse(Session["ID"].ToString());
        }
        StudentModel ostudentmod = new StudentModel();
        ResultLibrary oapplicationlibrary = new ResultLibrary();

        protected void lnkbtnChangePassword_Click(object sender, EventArgs e)
        {
            Response.Redirect("ChangePassword.aspx");
        }

        protected void lnkbtnPlacementDetails_Click(object sender, EventArgs e)
        {
            try
            {
                PnlPlacement.Visible = true;
                PnlVwClassSched.Visible = false;
                PnlVwResult.Visible = false;
                PnlVwSched.Visible = false;
                ApplicationLibrary oApplicationLib = new ApplicationLibrary();
                GetSessionList();
                GrdPlacemnt.DataSource = oApplicationLib.GetPlacementCalender();
                GrdPlacemnt.DataBind();
                if (GrdPlacemnt.Rows.Count == 0)
                {
                    LblPlacemntErr.Visible = true;
                    GrdPlacemnt.Visible = false;
                }
                else
                {
                    LblPlacemntErr.Visible = false;
                    GrdPlacemnt.Visible = true;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
              
            }
        }

        protected void lnkbtnExaminationSchedule_Click(object sender, EventArgs e)
        {
            try
            {
                PnlPlacement.Visible = false;
                PnlVwClassSched.Visible = false;
                PnlVwResult.Visible = false;
                PnlVwSched.Visible = true;
                ApplicationLibrary oapplicationlib = new ApplicationLibrary();
                GetSessionList();
                ostudentmod.Departmentname = oapplicationlibrary.getIdandYear(userid).Departmentname;
                ostudentmod.Yoj = oapplicationlibrary.getIdandYear(userid).Yoj;
                int year = ostudentmod.Yoj;
                int dept = oapplicationlib.ConvertingDeptId(ostudentmod.Departmentname);
                int sem = findsemester();
                int semno = sem + 1;
                int year1 = DateTime.Now.Year;
                string semester = FindSemFormat(semno);
             
                GrdVwSched.DataSource = oApplicationLib.ViewSchedule(year1, dept, semester);
                GrdVwSched.DataBind();
                if (GrdVwSched.Rows.Count == 0)
                {
                    LblVwSchedErr.Visible = true;
                    GrdVwSched.Visible = false;
                }
                else
                {
                    LblVwSchedErr.Visible = false;
                    GrdVwSched.Visible = true;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

        }
        public int findsemester()
        {
            ostudentmod.Yoj = oapplicationlibrary.getIdandYear(userid).Yoj;
            int year = ostudentmod.Yoj;
            DateTime now = DateTime.Now;
            int mon = now.Month;
            int curyear = now.Year;
            int semmonth = 0;
            if (mon <= 6)
            {
                semmonth = 1;
            }
            else
            {
                semmonth = 2;
            }
            int sem = 0;
            int difyear = curyear - year;
            if (difyear == 0)
            {
                sem = difyear + semmonth - 1;
            }
            else if (difyear == 1)
            {
                sem = difyear + semmonth - 1;
            }
            else if (difyear == 2)
            {
                sem = semmonth - 1 + 3;
            }
            else if (difyear == 3)
            {
                sem = semmonth - 1 + 5;
            }
            else
            {
                sem = 8;
            }
            return sem;

        }
        public string FindSemFormat(int semno)
        {
            string sem="";
              if (semno == 1)
              {
                 sem="SEM1";         
              }
              else if (semno == 2)
              {
                  sem="SEM2";
              }
              else if (semno == 3)
              {
                  sem="SEM3";
              }
              else if (semno == 4)
              {
                  sem="SEM4";
              }
              else if (semno == 5)
              {
                  sem="SEM5";
              }
              else if (semno == 6)
              {
                  sem="SEM6";
              }
              else if (semno == 7)
              {
                  sem="SEM7";
              }
              else if (semno == 8)
              {
                  sem="SEM8";
              }
            return sem;
        }

        protected void lnkbtnResults_Click(object sender, EventArgs e)
        {
            try
            {
                PnlPlacement.Visible = false;
                PnlVwClassSched.Visible = false;
                PnlVwResult.Visible = true;
                PnlVwSched.Visible = false;
                ApplicationLibrary oapplicationlib = new ApplicationLibrary();
                GetSessionList();
                StudentModel ostudentmod = new StudentModel();
                ResultLibrary oapplicationlibrary = new ResultLibrary();
                ostudentmod.Departmentname = oapplicationlibrary.getIdandYear(userid).Departmentname;
                ostudentmod.Yoj = oapplicationlibrary.getIdandYear(userid).Yoj;
                int year = ostudentmod.Yoj;
                int dept = oapplicationlib.ConvertingDeptId(ostudentmod.Departmentname);
                int semno = findsemester();
                int year1 = DateTime.Now.Year;
                string sem = FindSemFormat(semno);
                //int id=int.Parse(userid);
                ApplicationLibrary oApplicationLib = new ApplicationLibrary();
                GrdVwResult.DataSource = oApplicationLib.GetResultForStudents(userid, dept);
                GrdVwResult.DataBind();
                if (GrdVwResult.Rows.Count == 0)
                {
                    LblVwResultErr.Visible = true;
                    GrdVwResult.Visible = false;
                }
                else
                {
                    LblVwResultErr.Visible = false;
                    GrdVwResult.Visible = true;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");          
            }

        }

        protected void lnkbtnClassSchedule_Click(object sender, EventArgs e)
        {
            try
            {
                PnlPlacement.Visible = false;
                PnlVwClassSched.Visible = true;
                PnlVwResult.Visible = false;
                PnlVwSched.Visible = false;
                ApplicationLibrary oapplicationlib = new ApplicationLibrary();
                GetSessionList();
                StudentModel ostudentmod = new StudentModel();
                ResultLibrary oapplicationlibrary = new ResultLibrary();
                ostudentmod.Departmentname = oapplicationlibrary.getIdandYear(userid).Departmentname;
                ostudentmod.Yoj = oapplicationlibrary.getIdandYear(userid).Yoj;
                int year = ostudentmod.Yoj;
                int dept = oapplicationlib.ConvertingDeptId(ostudentmod.Departmentname);
                int semno = findsemester();
                int semesterno = semno + 1;
                int year1 = DateTime.Now.Year;
                string sem = FindSemFormat(semesterno);
                // ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
                // string sem = ddl_semester.SelectedItem.Text;
                //  int dept = oapplicationlibrary.ConvertingDeptId(ddl_department.SelectedItem.Text);
                GrdVwclassSchedule.DataSource = oapplicationlib.GetClassSchedule(sem, dept,year1);
                GrdVwclassSchedule.DataBind();
                if (GrdVwclassSchedule.Rows.Count == 0)
                {
                    LblVwClassSchedErr.Visible = true;
                    GrdVwclassSchedule.Visible = false;
                }
                else
                {
                    LblVwClassSchedErr.Visible = false;
                    GrdVwclassSchedule.Visible = true; ;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");            
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {

        }

       
        protected void lnkbtnOnlineExam_Click(object sender, EventArgs e)
        {
            Response.Redirect("OnlineExamChoose.aspx");
        }

        protected void lnkbtnviewonlineresult_Click(object sender, EventArgs e)
        {

        }
        protected void lnkbtnAssignments_Click(object sender, EventArgs e)
        {
            Response.Redirect("Assignments.aspx");
        }

        protected void lnkvwprofile_Click(object sender, EventArgs e)
        {
            //PnlPlacement.Visible = false;
            //PnlVwClassSched.Visible = false;
            //PnlVwResult.Visible = false;
            //PnlVwSched.Visible = false;
          
        }
       
                      
    }
}