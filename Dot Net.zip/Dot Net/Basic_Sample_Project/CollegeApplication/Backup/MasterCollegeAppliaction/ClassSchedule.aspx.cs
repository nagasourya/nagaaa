﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class ClassSchedule : System.Web.UI.Page
    {
        ApplicationLibrary oapplicationlib = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();   
        int dept = 0;
        string sem = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!IsPostBack)
            {
                ddldepartment.DataSource = oapplicationlib.GetDeptList();
                ddldepartment.DataBind();
                ddl_semester.DataSource = oapplicationlib.GetSemester();
                ddl_semester.DataBind();
                Label oLabel = new Label();
                Label oLabel1 = new Label();
                oLabel = (Label)Master.FindControl("lblWelcomeName");
                oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                string username = Session["name"].ToString();
                oLabel.Text = username;
                string lastdate = Session["LastLogIn"].ToString();
                oLabel1.Text = lastdate;
            }
            
        }

        protected void LnkBtnAddClassSchedule_Click(object sender, EventArgs e)
        {
            try
            {
                lbl_department.Visible = true;
                lbl_semester.Visible = true;
                ddldepartment.Visible = true;
                ddl_semester.Visible = true;
                ImageButton1.Visible = true;
                GridView2.Visible = false;
                ImageButton2.Visible = false;
                // ImageButton3.Visible = false;
                // Panel3.Visible = true;
                Lbladdtitle.Visible = true;
                lbltitle.Visible = false;
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void lnkbtnviewSchedule_Click(object sender, EventArgs e)
        {
            try
            {
                GridView1.Visible = false;
                lbl_department.Visible = true;
                lbl_semester.Visible = true;
                ddldepartment.Visible = true;
                ddl_semester.Visible = true;
                ImageButton1.Visible = false;
                ImageButton2.Visible = true;
                ImageButton3.Visible = false;
                Lbladdtitle.Visible = false;
                lbltitle.Visible = true;
                //  ImageButton3.Visible = true;
                //Panel3.Visible = true;
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
                int dept = oapplicationlibrary.ConvertingDeptId(ddldepartment.SelectedItem.Text);
                string sem = ddl_semester.SelectedItem.Text;

                GridView1.DataSource = oapplicationlibrary.GetSubject(sem, dept);
                GridView1.DataBind();
                GridView1.Visible = true;
                ImageButton2.Visible = false;
                ImageButton3.Visible = true;
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            try
            {
                ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
                dept = oapplicationlibrary.ConvertingDeptId(ddldepartment.SelectedItem.Text);
                sem = ddl_semester.SelectedItem.Text;
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    DropDownList dd1 = (DropDownList)e.Row.FindControl("dddayorder1");
                    dd1.DataSource = oapplicationlibrary.GetSubjectOnDeptandSemester(dept, sem);
                    dd1.DataBind();
                    DropDownList dd2 = (DropDownList)e.Row.FindControl("dddayorder2");
                    dd2.DataSource = oapplicationlibrary.GetSubjectOnDeptandSemester(dept, sem);
                    dd2.DataBind();
                    DropDownList dd3 = (DropDownList)e.Row.FindControl("dddayorder3");
                    dd3.DataSource = oapplicationlibrary.GetSubjectOnDeptandSemester(dept, sem);
                    dd3.DataBind();
                    DropDownList dd4 = (DropDownList)e.Row.FindControl("dddayorder4");
                    dd4.DataSource = oapplicationlibrary.GetSubjectOnDeptandSemester(dept, sem);
                    dd4.DataBind();
                    DropDownList dd5 = (DropDownList)e.Row.FindControl("dddayorder5");
                    dd5.DataSource = oapplicationlibrary.GetSubjectOnDeptandSemester(dept, sem);
                    dd5.DataBind();
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                GridView2.Visible = true;
                ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
                string sem = ddl_semester.SelectedItem.Text;
                int years = System.DateTime.Now.Year;
                int dept = oapplicationlibrary.ConvertingDeptId(ddldepartment.SelectedItem.Text);
                GridView2.DataSource = oapplicationlibrary.GetClassSchedule(sem, dept,years);
                GridView2.DataBind();
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                bool value = false;
                ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
                int years = System.DateTime.Now.Year;

                List<ClassScheduleS> classlist = new List<ClassScheduleS>();
                GridViewRowCollection rows = GridView1.Rows;
                sem = ddl_semester.SelectedItem.Text;
                dept = oapplicationlibrary.ConvertingDeptId(ddldepartment.SelectedItem.Text);

                foreach (GridViewRow row in rows)
                {
                    classlist.Add(new ClassScheduleS {Year=years,Time = ((DropDownList)row.FindControl("DropDownList1")).Text, Semester = ddl_semester.SelectedItem.Text, DeptId = oapplicationlibrary.ConvertingDeptId(ddldepartment.SelectedItem.Text), Day1 = ((DropDownList)row.FindControl("dddayorder1")).Text, Day2 = ((DropDownList)row.FindControl("dddayorder2")).Text, Day3 = ((DropDownList)row.FindControl("dddayorder3")).Text, Day4 = ((DropDownList)row.FindControl("dddayorder4")).Text, Day5 = ((DropDownList)row.FindControl("dddayorder5")).Text });
                }
                value = oapplicationlibrary.Inserttable(classlist, sem, dept,years);
                if (value == true)
                {                  

                    ErrMsgBox.AddMessage("Schedule Saved", MasterCollegeAppliaction.ErrorForm.enmMessageType.Success);
                }
                else
                {
                   
                    ErrMsgBox.AddMessage("Schedule not Saved", MasterCollegeAppliaction.ErrorForm.enmMessageType.Error);
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

        }

        protected void LnkBtnHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin.aspx");
        }
    }
}