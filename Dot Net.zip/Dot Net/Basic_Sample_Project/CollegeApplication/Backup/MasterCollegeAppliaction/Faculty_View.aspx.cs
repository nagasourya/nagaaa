﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class Faculty_View : System.Web.UI.Page
    {
        int userid=0;
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel(); 
        ApplicationLibrary oapplication = new ApplicationLibrary();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");
                    string username = Session["name"].ToString();
                    oLabel.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                    dvFacultyView.Visible = true;

                    userid = int.Parse(Session["ID"].ToString());
                    ApplicationLibrary oapplication = new ApplicationLibrary();
                    dvFacultyView.DataSource = oapplication.ViewProfilefaculty(userid);
                    dvFacultyView.DataBind();
                    if (dvFacultyView.Rows.Count == 0)
                    {
                        dvFacultyView.EmptyDataText = "No Data Available!!!";
                    }
                    int dt1 = int.Parse(DateTime.Now.Year.ToString());
                    for (int i = 0; i < 9; i++)
                    {
                        ListItem ilist = new ListItem();
                        ilist.Value = (dt1 - i).ToString();
                        drpdwnyop.Items.Add(ilist);

                    }
                    int dt = (System.DateTime.Now.Year) + 4;
                    for (int i = 0; i <= 8; i++)
                    {
                        ListItem ilist = new ListItem();
                        ilist.Value = (dt - i).ToString();
                        drp_year.Items.Add(ilist);

                    }
              
                    

                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplication.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
                
            }
        }

        protected void lnkbtnstaffmeeting_Click(object sender, EventArgs e)
        {
            try
            {
                PnlVwMeeting.Visible = true;
                PnlVwResult.Visible = false;
                PnlClassSchedule.Visible = false;
                PnlPlacement.Visible = false;
                PnlViewAlumini.Visible = false;
                PnlViewExamSchedule.Visible = false;
                pnlOnlineResult.Visible = false;

                GrdVwEvt.DataSource = oapplication.ViewEventsFaculty();
                GrdVwEvt.DataBind();
                if (GrdVwEvt.Rows.Count == 0)
                {
                    LblMeetingErr.Visible = true;
                    GrdVwEvt.Visible = false;
                }
                else
                {
                    LblMeetingErr.Visible = false;
                    GrdVwEvt.Visible = true; 
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplication.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

        }

        protected void lnkbtnexamschedule_Click(object sender, EventArgs e)
        {
            try
            {
                PnlVwMeeting.Visible = false;
                PnlVwResult.Visible = false;
                PnlClassSchedule.Visible = false;
                PnlPlacement.Visible = false;
                PnlViewAlumini.Visible = false;
                PnlViewExamSchedule.Visible = true;
                pnlOnlineResult.Visible = false;
                drp_dept.DataSource = oapplication.GetDeptList();
                drp_dept.DataBind();
                drp_semester.DataSource = oapplication.GetSemester();
                drp_semester.DataBind();
              
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplication.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
           
          
        }

        protected void lnkbtnclassschedule_Click(object sender, EventArgs e)
        {
            try
            {
                PnlClassSchedule.Visible = true;
                PnlVwMeeting.Visible = false;
                PnlVwResult.Visible = false;
                PnlPlacement.Visible = false;
                PnlViewAlumini.Visible = false;
                pnlOnlineResult.Visible = false;
                PnlViewExamSchedule.Visible = false;
                ddl_department.DataSource = oapplication.GetDeptList();
                ddl_department.DataBind();
                ddl_semester.DataSource = oapplication.GetSemester();
                ddl_semester.DataBind();
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplication.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void lnknbtnAluminisearch_Click(object sender, EventArgs e)
        {

            try
            {
                PnlVwMeeting.Visible = false;
                PnlVwResult.Visible = false;
                PnlClassSchedule.Visible = false;
                PnlPlacement.Visible = false;
                PnlViewAlumini.Visible = true;
                PnlViewExamSchedule.Visible = false;
                pnlOnlineResult.Visible = false;
                
                PnlViewAlumini.Visible = true;
                
                ApplicationLibrary oApplicationLib = new ApplicationLibrary();
                var getalumini = oApplicationLib.viewAlumini();
                GrdVwAlumini.DataSource = getalumini;
                GrdVwAlumini.DataBind();
                if (GrdVwAlumini.Rows.Count == 0)
                {
                    LblAlErr.Visible = true;
                    GrdVwAlumini.Visible = false;
                }
                else
                {
                    LblAlErr.Visible = false;
                    GrdVwAlumini.Visible = true;
                }
                
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplication.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void Assignments_Click(object sender, EventArgs e)
        {

            Response.Redirect("Assignments.aspx");
        }

        protected void lnkbtnplacement_Click(object sender, EventArgs e)
        {
            try
            {
                PnlVwMeeting.Visible = false;
                PnlVwResult.Visible = false;
                PnlClassSchedule.Visible = false;
                PnlPlacement.Visible = true;
                PnlViewAlumini.Visible = false;
                PnlViewExamSchedule.Visible = false;
                pnlOnlineResult.Visible = false;

                ApplicationLibrary oApplicationLib = new ApplicationLibrary();
                GrdPlacemnt.DataSource = oApplicationLib.GetPlacementCalender();
                GrdPlacemnt.DataBind();
                if (GrdPlacemnt.Rows.Count == 0)
                {
                    LblPlacementErr.Visible = true;
                    GrdPlacemnt.Visible = false;
                }
                else
                {
                    LblPlacementErr.Visible = false; ;
                    GrdPlacemnt.Visible = true;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplication.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

        }

        protected void lnkbtnchangepassword_Click(object sender, EventArgs e)
        {
            Response.Redirect("Changepassword.aspx");

        }

        protected void ImgBtnSearchSubmit_Click(object sender, ImageClickEventArgs e)
        {

            try
            {
                ApplicationLibrary oApplicationLib = new ApplicationLibrary();
                string yop = "SELECT";
                string s = txtsearch.Text;
                yop = drpdwnyop.SelectedItem.Value;
                if (s.Equals("") && (yop.Equals("SELECT")))
                {
                    ErrMsgBox.AddMessage("Please Enter Name or Choose Year Of passed Out to Search..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Attention);
                    //LblAlErr.Visible = true;
                    //LblAlErr.Text = "Please Enter Name or Choose Year Of passed Out to Search..";
                }
                else if (!(s.Equals("")) && !(yop.Equals("SELECT")))
                {
                    //yop = int.Parse(drpdwnyop.SelectedItem.Value.ToString());
                    var getalumini = oApplicationLib.viewAlumini(s, int.Parse(yop));
                    GrdVwAlumini.DataSource = getalumini;
                    GrdVwAlumini.DataBind();
                    if (GrdVwAlumini.Rows.Count == 0)
                    {
                        LblAlErr.Visible = true;
                        GrdVwAlumini.Visible = false;
                    }
                    else
                    {
                        LblAlErr.Visible = false;
                        GrdVwAlumini.Visible = true; ;
                    }
                }
                else if ((s.Equals("")) && !(yop.Equals("SELECT")))
                {
                    //yop = int.Parse(drpdwnyop.SelectedItem.Value.ToString());
                    var getalumini = oApplicationLib.viewAlumini(int.Parse(yop));
                    GrdVwAlumini.DataSource = getalumini;
                    GrdVwAlumini.DataBind();
                    if (GrdVwAlumini.Rows.Count == 0)
                    {
                        LblAlErr.Visible = true;
                        GrdVwAlumini.Visible = false;
                    }
                    else
                    {
                        LblAlErr.Visible = false;
                        GrdVwAlumini.Visible = true; ;
                    }
                }
                else if (!(s.Equals("")) && (yop.Equals("SELECT")))
                {
                    var getalumini = oApplicationLib.viewAlumini(s);
                    GrdVwAlumini.DataSource = getalumini;
                    GrdVwAlumini.DataBind();
                    if (GrdVwAlumini.Rows.Count == 0)
                    {
                        LblAlErr.Visible = true;
                        GrdVwAlumini.Visible = false;
                    }
                    else
                    {
                        LblAlErr.Visible = false;
                        GrdVwAlumini.Visible = true; ;
                    }
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplication.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }
   
        protected void ImgBtnClose_Click(object sender, ImageClickEventArgs e)
        {
            PnlViewAlumini.Visible = false;
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                GrdClassSchedule.Visible = true;
                ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
               
                string sem = ddl_semester.SelectedItem.Text;
                int years=System.DateTime.Now.Year;
                int dept = oapplicationlibrary.ConvertingDeptId(ddl_department.SelectedItem.Text);
                GrdClassSchedule.DataSource = oapplicationlibrary.GetClassSchedule(sem, dept,years);
                GrdClassSchedule.DataBind();
                if (GrdClassSchedule.Rows.Count == 0)
                {
                    LblClassErr.Visible = true;
                    GrdClassSchedule.Visible = false;

                }
                else
                {
                    LblClassErr.Visible = false;
                    GrdClassSchedule.Visible = true;
                }
            }

            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplication.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void ImgBtnSched_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                ApplicationLibrary oApplicationLibrary = new ApplicationLibrary();
                int year = int.Parse(drp_year.SelectedItem.Text);
                int dept = oApplicationLibrary.ConvertingDeptId(drp_dept.SelectedItem.Text);
               
                string sem = drp_semester.SelectedItem.Text;

                GrdVwSched.DataSource = oApplicationLibrary.ViewSchedule(year, dept, sem);
                GrdVwSched.DataBind();
                if (GrdVwSched.Rows.Count == 0)
                {
                    lblExamErr.Visible = true;
                    GrdVwSched.Visible = false;
                }
                else
                {
                    lblExamErr.Visible = false;
                    GrdVwSched.Visible = true;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplication.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

    
        protected void lnkbtnresults_Click(object sender, EventArgs e)
        {
            try
            {

                PnlVwMeeting.Visible = false;
                PnlVwResult.Visible = true;
                PnlClassSchedule.Visible = false;
                PnlPlacement.Visible = false;
                PnlViewAlumini.Visible = false;
                PnlViewExamSchedule.Visible = false;
                pnlOnlineResult.Visible = false;
                DrpvwDept.DataSource = oapplication.GetDeptList();
                DrpvwDept.DataBind();
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplication.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

            
        }

        protected void lnkbtnonlineexam_Click(object sender, EventArgs e)
        {
            try
            {
                PnlVwMeeting.Visible = false;
                PnlVwResult.Visible = false;
                PnlClassSchedule.Visible = false;
                PnlPlacement.Visible = false;
                PnlViewAlumini.Visible = false;
                PnlViewExamSchedule.Visible = false;
                pnlOnlineResult.Visible = true;
                ResultLibrary oApplication = new ResultLibrary();
                grdOnlinResult.DataSource = oApplication.GetOnlineResult();
                grdOnlinResult.DataBind();
                if (grdOnlinResult.Rows.Count == 0)
                {
                    LblOnlineResultErr.Visible = true;
                    grdOnlinResult.Visible = false;
                }
                else
                {
                    LblOnlineResultErr.Visible = false;
                    grdOnlinResult.Visible = true;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplication.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void ImgBtnSearchResult_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //ResultModel oresultmodel = new ResultModel();
                //oresultmodel.Department = DrpvwDept.SelectedValue;
                int dept = oapplication.ConvertingDeptId(DrpvwDept.SelectedValue);
                GrdVwResult.DataSource = oapplication.GetResult(dept);
                GrdVwResult.DataBind();
                if (GrdVwResult.Rows.Count == 0)
                {
                    LblVwResultErr.Visible = true;
                    GrdVwResult.Visible = false;
                }
                else
                {
                    LblVwResultErr.Visible = false;
                    GrdVwResult.Visible = true;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplication.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }
    }
}