﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class StudentResult : System.Web.UI.Page
    {
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();   
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                //LnkBtnAddResult.Visible = true;
                //LnkBtnViwResult.Visible = true;
                if (!IsPostBack)
                {
                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    string username = Session["name"].ToString();
                    oLabel.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                    int dt = (System.DateTime.Now.Year) + 4;
                    for (int i = 0; i <=8; i++)
                    {
                        ListItem ilist = new ListItem();
                        ilist.Value = (dt - i).ToString();
                        DropDownList2.Items.Add(ilist);

                    }

                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }
        public int findsemester()
        {

            int year = int.Parse(DropDownList2.SelectedItem.Text);
            DateTime now = DateTime.Now;
            int mon = now.Month;
            int curyear = now.Year;
            int semmonth = 0;
            if (mon <= 6)
            {
                semmonth = 1;
            }
            else
            {
                semmonth = 2;
            }
            int sem = 0;
            int difyear = curyear - year;
            if (difyear == 0)
            {
                sem = difyear + semmonth - 1;
            }
            else if (difyear == 1)
            {
                sem = difyear + semmonth - 1;
            }
            else if (difyear == 2)
            {
                sem = semmonth - 1 + 3;
            }
            else if (difyear == 3)
            {
                sem = semmonth - 1 + 5;
            }
            else
            {
                sem = 8;
            }
            return sem;

        }

        protected void EditResult_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                string mark =string.Empty;
                string studentname=string.Empty;
                int semno = findsemester();
                string studentid = string.Empty;
                int dept = oApplicationLib.ConvertingDeptId(DropDownList1.SelectedItem.Text);
                int year = int.Parse(DropDownList2.SelectedItem.Text);
                if (e.CommandName == "Save")
                {
                    studentid = e.CommandArgument.ToString();
                   
                    GridViewRowCollection rows = GrdVwEditResult.Rows;
                    foreach (GridViewRow row in rows)
                    {
                        if (((Label)row.Cells[1].FindControl("lblRegistrationNo")).Text.Equals(studentid))
                        {
                            mark = ((TextBox)row.Cells[2].FindControl("txtPercentage")).Text;
                           studentname = ((Label)row.Cells[0].FindControl("lblName")).Text;                          
                            break;
                        }
                    }
                    int id = int.Parse(studentid);
                    decimal percentage = System.Convert.ToDecimal(mark);
                    if ((percentage >= 0) && (percentage <= 100))
                    {

                        bool value = oApplicationLib.InsertTable(studentname, id, semno, percentage, dept);

                        if (value == true)
                        {
                            //Response.Write("<script language='javascript'>alert('Value Entered');</script>");
                            ErrMsgBox.AddMessage("Value Entered.", MasterCollegeAppliaction.ErrorForm.enmMessageType.Success);

                        }
                        else
                        {
                            // Response.Write("<script language='javascript'>alert('Already  Entered');</script>");
                            ErrMsgBox.AddMessage("Already Entered.", MasterCollegeAppliaction.ErrorForm.enmMessageType.Error);
                        }
                    }
                    else
                    {
                        ErrMsgBox.AddMessage("Enter Valid Percentage", MasterCollegeAppliaction.ErrorForm.enmMessageType.Attention);
                    }

                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void LnkBtnViewResult_Click(object sender, EventArgs e)
        {
            try
            {
                PnlStudResult.Visible = false;
                PnlVwResult.Visible = true;
                int dept = oApplicationLib.ConvertingDeptId(DropDownList1.SelectedItem.Text);
                GrdVwResult.Visible = true;
                GrdVwResult.DataSource = oApplicationLib.GetResult(dept);
                GrdVwResult.DataBind();
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

        }

        protected void ImgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                int dept = oApplicationLib.ConvertingDeptId(DropDownList1.SelectedItem.Text);
                int year = int.Parse(DropDownList2.SelectedItem.Text);

                GrdVwEditResult.DataSource = oApplicationLib.GetTable(dept, year);
                GrdVwEditResult.DataBind();
                if (GrdVwEditResult.Rows.Count == 0)
                {
                    LblErr.Text = "No Data Found..";
                    GrdVwEditResult.Visible = false;
                    LblErr.Visible = true;
                }
                else
                {
                    GrdVwEditResult.Visible = true;                   
                    LblErr.Visible = false;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

        }

       

        protected void LnkBtnAddResult_Click1(object sender, EventArgs e)
        {
            try
            {
                PnlStudResult.Visible = true;
                PnlVwResult.Visible = false;
                DropDownList1.DataSource = oApplicationLib.GetDeptList();
                DropDownList1.DataBind();
               
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void LnkBtnViwResult_Click(object sender, EventArgs e)
        {
            try
            {
               DrpvwDept.DataSource = oApplicationLib.GetDeptList();
                DrpvwDept.DataBind();
                PnlStudResult.Visible = false;
                PnlVwResult.Visible = true;                
                GrdVwResult.Visible = true;
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void LnkBtnBakHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin.aspx");
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                int dept = oApplicationLib.ConvertingDeptId(DrpvwDept.SelectedItem.Text);             
                GrdVwResult.DataSource = oApplicationLib.GetResult(dept);
                GrdVwResult.DataBind();
                if (GrdVwResult.Rows.Count == 0)
                {
                    LblErrVw.Visible = true;
                    LblErrVw.Text = "No Data Found..";
                    GrdVwResult.Visible = false;

                }
                else
                {
                    GrdVwResult.Visible = true;
                    LblErrVw.Visible = false;
                 
                  
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

        }


    }
}