﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;


namespace MasterCollegeAppliaction
{
    public partial class UserApplicationForm : System.Web.UI.Page
    {
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();   
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();
        protected void Page_Load(object sender, EventArgs e)
        {
            Label oLabel = new Label();
            Label oLabel1 = new Label();

            Label olabel2 = new Label();
            Label olabel3 = new Label();
            olabel2 = (Label)Master.FindControl("lblWelcome");
            olabel2.Visible = false;
            olabel3 = (Label)Master.FindControl("lblLastLogInTime");
            olabel3.Visible = false;

            oLabel = (Label)Master.FindControl("lblWelcomeName");
            oLabel.Visible = false;
            oLabel1 = (Label)Master.FindControl("lblLastLogIn");
            oLabel1.Visible = false;
            ImageButton oImgButton = new ImageButton();
            oImgButton = (ImageButton)Master.FindControl("imgbtnLogout");
            oImgButton.Visible = false;
            DDwnLstDept.DataSource = oApplicationLib.GetDeptList();
            DDwnLstDept.DataBind();
        }
     
     
        protected void ImgBtnClose_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("Homepage.aspx");
        }

        protected void ImgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
           
            UserAppModel oUserMod = new UserAppModel();          
                oUserMod.Name = txt_name.Text;
                oUserMod.Gender = RBtnListGender.SelectedValue;
                oUserMod.Department = DDwnLstDept.SelectedItem.Text;
                oUserMod.Avgmark = decimal.Parse(txt_avgmarks.Text);
                oUserMod.Address = txt_location.Text;
                oUserMod.Email = txt_email.Text;
                oUserMod.Contactno = long.Parse(txt_contactno.Text);
                oUserMod.Dob = txtdate.Text;
                int x = oApplicationLib.SubmitForm(oUserMod);

                pnleligible.Visible = false;
                Pnlchkstatus.Visible = true;
                PnlAppForm.Enabled = false;              
                lblappid.Text = x.ToString();
                  
        }

        protected void ImgBtnCancel_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                txt_avgmarks.Text = "";
                txt_contactno.Text = "";
                txt_email.Text = "";
                txt_location.Text = "";
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

       
        }

        protected void btncutoff_Click(object sender, ImageClickEventArgs e)
        {
           
        }
        public bool CheckMarks(int maths,int chemistry,int physics)
        {
            if ((maths < 200) && (chemistry < 200) && (physics < 200))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        protected void txtchemistry_TextChanged(object sender, EventArgs e)
        {
            bool IsCorrect = true;
            IsCorrect=CheckMarks(int.Parse(txtmaths.Text), int.Parse(txtchemistry.Text), int.Parse(txtphysics.Text));
            if (IsCorrect==true)
            {
                if ((txtmaths.Text == string.Empty) || (txtphysics.Text == string.Empty) || (txtchemistry.Text == string.Empty))
                {
                    txtchemistry.Text = "0";
                    txtphysics.Text = "0";
                    txtmaths.Text = "0";
                }
                else
                {
                    double maths = double.Parse(txtmaths.Text) / 2;
                    double physics = double.Parse(txtphysics.Text) / 4;
                    double chemistry = double.Parse(txtchemistry.Text) / 4;
                    double cutoff = maths + physics + chemistry;
                    txt_avgmarks.Text = cutoff.ToString();
                } lblErr.Visible = false;
            }
            else
            {
               lblErr .Visible = true;
               lblErr.Text = "Please Enter Valid Marks.";
            }
        }

        protected void txtmaths_TextChanged(object sender, EventArgs e)
        {
             bool IsCorrect = true;
            IsCorrect=CheckMarks(int.Parse(txtmaths.Text), int.Parse(txtchemistry.Text), int.Parse(txtphysics.Text));
            if (IsCorrect==true)
            {
                if ((txtmaths.Text == string.Empty) || (txtphysics.Text == string.Empty) || (txtchemistry.Text == string.Empty))
                {
                    txtchemistry.Text = "0";
                    txtphysics.Text = "0";
                    txtmaths.Text = "0";
                }
                else
                {
                    double maths = double.Parse(txtmaths.Text) / 2;
                    double physics = double.Parse(txtphysics.Text) / 4;
                    double chemistry = double.Parse(txtchemistry.Text) / 4;
                    double cutoff = maths + physics + chemistry;
                    txt_avgmarks.Text = cutoff.ToString();
                }
                lblErr.Visible = false;
            }
            else
            {
                lblErr.Visible = true;
                lblErr.Text = "Please Enter Valid Marks.";
            }

        }

        protected void txtphysics_TextChanged(object sender, EventArgs e)
        {
            bool IsCorrect = true;
            IsCorrect = CheckMarks(int.Parse(txtmaths.Text), int.Parse(txtchemistry.Text), int.Parse(txtphysics.Text));
            if (IsCorrect==true)
            {
                if ((txtmaths.Text == string.Empty) || (txtphysics.Text == string.Empty) || (txtchemistry.Text == string.Empty))
                {
                    txtchemistry.Text = "0";
                    txtphysics.Text = "0";
                    txtmaths.Text = "0";
                }
                else
                {
                    double maths = double.Parse(txtmaths.Text) / 2;
                    double physics = double.Parse(txtphysics.Text) / 4;
                    double chemistry = double.Parse(txtchemistry.Text) / 4;
                    double cutoff = maths + physics + chemistry;
                    txt_avgmarks.Text = cutoff.ToString();

                } lblErr.Visible = false;
            }
            else
            {
                lblErr.Visible = true;
                lblErr.Text = "Please Enter Valid Marks.";
            }
        }

      


       
    }
}