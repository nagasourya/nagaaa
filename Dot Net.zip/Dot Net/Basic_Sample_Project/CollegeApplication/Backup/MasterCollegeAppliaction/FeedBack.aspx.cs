﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class FeedBack : System.Web.UI.Page
    {
        FeedBackModel oFbMod = new FeedBackModel();
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel(); 
        protected void Page_Load(object sender, EventArgs e)
        {
          
                if (!IsPostBack)
                {
                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    LoadFeedBack();
                    Label olabel2 = new Label();
                    Label olabel3 = new Label();
                    olabel2 = (Label)Master.FindControl("lblWelcome");
                    olabel2.Visible = false;
                    olabel3 = (Label)Master.FindControl("lblLastLogInTime");
                    olabel3.Visible = false;

                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel.Visible = false;
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");
                    oLabel1.Visible = false;
                    ImageButton oImgButton = new ImageButton();
                    oImgButton = (ImageButton)Master.FindControl("imgbtnLogout");
                    oImgButton.Visible = false;
                }

              
        }
        public void LoadFeedBack()
        {
            try
            {
                List<FeedBackModel> oFbModList = new List<FeedBackModel>();

                oFbModList = oApplicationLib.FeedBackLoad();

                foreach (var temp in oFbModList)
                {
                    txtFeedback.Text += "\n\n\n";
                    txtFeedback.Text += temp.Name + ":\t";
                    txtFeedback.Text += temp.Comments + "\n";
                    txtFeedback.Text += (DateTime)temp.Createddate + "\n";
                    txtFeedback.Text += "...........................................................";
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
                
            }
        }
        protected void ImgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                oFbMod.Name = TxtName.Text;
                oFbMod.Comments = TxtComments.Text;
                oFbMod.Email = TxtEmail.Text;
                oFbMod.Createddate = DateTime.Now;

                oApplicationLib.FeedBackUpdate(oFbMod);
                //oFbLib.FeedBackLoad();
                txtFeedback.Text = "";
                LoadFeedBack();
                TxtComments.Text = " ";
                TxtEmail.Text = " ";
                TxtName.Text = " ";
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void ImgBtnClear_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                TxtComments.Text = " ";
                TxtEmail.Text = " ";
                TxtName.Text = " ";
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }


    }
}