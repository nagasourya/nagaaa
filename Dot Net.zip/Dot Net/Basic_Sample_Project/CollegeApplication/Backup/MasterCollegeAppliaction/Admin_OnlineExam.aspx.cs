﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class Admin_OnlineExam : System.Web.UI.Page
    {
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();
        ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                lnkbtnaddtestname.Visible = true;
                lnkbtnviewtestname.Visible = true;
                Panel2.Visible = false;
               
                if (!IsPostBack)
                {

                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    string username = Session["name"].ToString();
                    oLabel.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
               
            }
        }



        protected void lnkbtnaddtestname_Click(object sender, EventArgs e)
        {
            try
            {
                Panel2.Visible = true;
                Panel3.Visible = false;
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
               
            }
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                TestModel otestmodel = new TestModel();
                otestmodel.Testname = txttestname.Text;
                otestmodel.Duration = int.Parse(txtdurationinmin.Text);
                ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
                oapplicationlibrary.inserttestname(otestmodel);
                ErrMsgBox.AddMessage("Test Added Successfully..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Success);
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
               
            }
           
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                txtdurationinmin.Text = "";
                txttestname.Text = "";
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
               
            }

        }

        protected void lnkbtnviewtestname_Click(object sender, EventArgs e)
        {
            try
            {
                Panel3.Visible = true;
                ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
                GridView1.DataSource = oapplicationlibrary.GetTestAdmin();
                GridView1.DataBind();
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
              
            }

        }



        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                bool value = false;
                string id = string.Empty;

                if (e.CommandName == "SAVE")
                {
                    id = e.CommandArgument.ToString();

                    GridViewRowCollection rows = GridView1.Rows;
                    foreach (GridViewRow row in rows)
                    {
                        if (((Label)row.Cells[0].FindControl("lbltestid")).Text.Equals(id))
                        {

                            value = ((CheckBox)row.Cells[1].FindControl("CheckBox1")).Checked;


                            break;
                        }

                    }
                    int id1 = int.Parse(id);
                    ApplicationLibrary oapplicationlib = new ApplicationLibrary();
                    oapplicationlib.UpdateTestStatus(value, id1);

                    ErrMsgBox.AddMessage("Test status has been changed.", MasterCollegeAppliaction.ErrorForm.enmMessageType.Info);
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
              
            }


        }

    
        protected void lnkbtnaddquestions_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddQuestions.aspx");
        }

        protected void LnkBtnHome_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin.aspx");
        }
    }
}