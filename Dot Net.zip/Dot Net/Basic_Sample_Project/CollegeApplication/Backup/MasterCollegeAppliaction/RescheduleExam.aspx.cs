﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class RescheduleExam : System.Web.UI.Page
    {
        ApplicationLibrary oapplicationLibrary = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();  
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    string username = Session["name"].ToString();
                    oLabel.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                    drp_dept.DataSource = oapplicationLibrary.GetDeptList();
                    drp_dept.DataBind();
                    drp_sem.DataSource = oapplicationLibrary.GetSemester();
                    drp_sem.DataBind();
                    int dt = (System.DateTime.Now.Year) + 4;
                    for (int i = 0; i < 8; i++)
                    {
                        ListItem ilist = new ListItem();
                        ilist.Value = (dt - i).ToString();
                        drp_year.Items.Add(ilist);

                    }
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationLibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }


        protected void grd_reschedulr_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                lblinfo.Visible = true;
                bool value = false;
                int year = int.Parse(drp_year.SelectedItem.Text);
                string tocode = "";
                DateTime dats = DateTime.MinValue;
                if (e.CommandName == "SAVE")
                {

                    tocode = e.CommandArgument.ToString();
                    GridViewRowCollection rows = grd_resch.Rows;
                    foreach (GridViewRow row in rows)
                    {


                        if (DateTime.Parse(((TextBox)row.FindControl("Txt_date")).Text) > System.DateTime.Now)
                        {

                            int tcode = int.Parse(((Label)row.Cells[1].FindControl("lbl_code")).Text);

                            if (((Label)row.Cells[0].FindControl("lbl_code")).Text.Equals(tocode))
                            {
                                dats = DateTime.Parse(((TextBox)row.Cells[0].FindControl("Txt_date")).Text);                               
                                int code = int.Parse(tocode);
                                ApplicationLibrary oapplicationLibrary = new ApplicationLibrary();
                                value = oapplicationLibrary.RescheduleDate(code, dats, year);
                                break;

                            }
                        }

                        else
                        {

                            // Response.Write("<script>alert('Give date greater than present date')</script>");
                            // ErrMsgBox.AddMessage("Schedule Not Changed..Pls Insert Properly", MasterCollegeAppliaction.ErrorForm.enmMessageType.Attention);
                            lblinfo.Text = "Schedule Not Changed..Pls Insert Properly";
                            break;
                        }

                    }
                    if (value == true)
                    {
                        // Response.Write("<script>alert('Date Updated')</script>");
                        // ErrMsgBox.AddMessage("Schedule Changed Succesfully..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Success);
                        lblinfo.Text = "Schedule Changed..";
                    }
                    else
                    {
                        //Response.Write("<script>alert('Date not Updated')</script>");
                        //ErrMsgBox.AddMessage("Not Inserted..Pls Insert Properly", MasterCollegeAppliaction.ErrorForm.enmMessageType.Error);
                        lblinfo.Text = "Not Inserted..Pls Insert Properly";
                    }

                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationLibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void ImgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //StudentLib ostudentlib = new StudentLib();
               
                int year = int.Parse(drp_year.SelectedItem.Text);
                string _dep = drp_dept.SelectedItem.Text;
                string sem = drp_sem.SelectedItem.Text;
                int dept = oapplicationLibrary.ConvertingDeptId(_dep);
                grd_resch.DataSource = oapplicationLibrary.GetForReschedule(year, sem, dept);
                grd_resch.DataBind();
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationLibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void LnkBtnBckExm_Click(object sender, EventArgs e)
        {
            Response.Redirect("ExamSchedule.aspx");
        }
    }




}
