﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;
using System.Text;

namespace MasterCollegeAppliaction
{
    public partial class AddCalender : System.Web.UI.Page
    {
        readonly ErrorLoggingModel _oerrorlogging = new ErrorLoggingModel();
        readonly ApplicationLibrary _oApplicationLib = new ApplicationLibrary();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    LoadCompany();
                    var oLabel = (Label)Master.FindControl("lblWelcomeName");
                    var oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    var username = Session["name"].ToString();
                    oLabel.Text = username;
                    var lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                }
            }
            catch (Exception ex)
            {
                _oerrorlogging.Error = ex.Message;
                _oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                _oApplicationLib.logException(_oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }


        }
        public void LoadCompany()
        {
            try
            {
                DropDownList1.DataSource = _oApplicationLib.GetCompanynames();
                DropDownList1.DataBind();
            }
            catch (Exception ex)
            {
                _oerrorlogging.Error = ex.Message;
                _oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                _oApplicationLib.logException(_oerrorlogging);
                //Response.Redirect("EmptyPage");
            }

        }
        public string Getdepartment()
        {
            var selectedItem = "";
            if (ListBox1.Items.Count > 0)
            {
                for (var i = 0; i < ListBox1.Items.Count; i++)
                {
                    if (ListBox1.Items[i].Selected)
                    {
                        if (selectedItem == "")
                            selectedItem = ListBox1.Items[i].Text;
                        else
                            selectedItem += "," + ListBox1.Items[i].Text;
                    }
                }
            }

            return selectedItem;

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                var ocompanymodel = new CompanyModel { CompanyName = TextBox1.Text, Location = TextBox2.Text };

                var x = _oApplicationLib.AddCompany(ocompanymodel);
                if (x == 0)
                {
                    ErrMsgBox.AddMessage("Not Inserted..Pls Insert Properly", ErrorForm.enmMessageType.Attention);
                }
                else
                {
                    LoadCompany();
                    ErrMsgBox.AddMessage("Company Inserted..", ErrorForm.enmMessageType.Success);
                }
            }

            catch (Exception)
            {
                ErrMsgBox.AddMessage("Company already Inserted..", ErrorForm.enmMessageType.Info);
            }

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //getdepartment();
                var oplacementmodel = new PlacementModel();
                try
                {

                    var dt = DateTime.Parse(txtdate.Text);
                    var eligiblemark = int.Parse(TextBox4.Text);
                    if (dt > DateTime.Now)
                    {
                        var comp = DropDownList1.SelectedItem.Text;
                        var departments = Getdepartment();
                        oplacementmodel.Departmentname = departments;

                        oplacementmodel.Companyname = DropDownList1.SelectedItem.Text;
                        oplacementmodel.Date = dt;
                        if ((eligiblemark >= 0) && (eligiblemark <= 100))
                        {
                            oplacementmodel.Eligiblity = int.Parse(TextBox4.Text);
                            var value = _oApplicationLib.AddPlacement(oplacementmodel, dt, comp);
                            if (value == true)
                                ErrMsgBox.AddMessage("Value Inserted.", ErrorForm.enmMessageType.Success);
                            else
                                ErrMsgBox.AddMessage("Value not Inserted.", ErrorForm.enmMessageType.Error);
                        }
                        else
                            ErrMsgBox.AddMessage("Enter Valid Mark.", ErrorForm.enmMessageType.Attention);
                    }
                    else
                        ErrMsgBox.AddMessage("Give Schedule Greater than present Date",
                                             ErrorForm.enmMessageType.Attention);
                }
                catch (Exception ex)
                {

                    _oerrorlogging.Error = ex.Message;
                    _oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                    _oApplicationLib.logException(_oerrorlogging);
                    ErrMsgBox.AddMessage("Insert properly.", MasterCollegeAppliaction.ErrorForm.enmMessageType.Attention);
                    Response.Redirect("EmptyPage.aspx");
                }

            }



            catch (Exception ex)
            {
                _oerrorlogging.Error = ex.Message;
                _oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                _oApplicationLib.logException(_oerrorlogging);
                Response.Redirect("EmptyPage");
            }

        }




        protected void LnkBtnAddCmpny_Click1(object sender, EventArgs e)
        {
            try
            {
                PnlAddCmpny.Visible = true;
                PnlAddCal.Visible = false;
            }
            catch (Exception ex)
            {
                _oerrorlogging.Error = ex.Message;
                _oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                _oApplicationLib.logException(_oerrorlogging);
                Response.Redirect("EmptyPage");
            }
        }

        protected void lnkbtnClassSchedule_Click(object sender, EventArgs e)
        {
            try
            {
                PnlAddCal.Visible = true;
                PnlAddCmpny.Visible = false;
                ListBox1.DataSource = _oApplicationLib.GetDeptList();
                ListBox1.DataBind();
            }
            catch (Exception ex)
            {
                _oerrorlogging.Error = ex.Message;
                _oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                _oApplicationLib.logException(_oerrorlogging);
                Response.Redirect("EmptyPage");
            }
        }

        protected void ImgBtnClear_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                TextBox1.Text = "";
                TextBox2.Text = "";
            }
            catch (Exception ex)
            {
                _oerrorlogging.Error = ex.Message;
                _oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                _oApplicationLib.logException(_oerrorlogging);
                Response.Redirect("EmptyPage");
            }
        }

        protected void ImgBtnClearCal_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                txtdate.Text = "";
                TextBox4.Text = "";
            }
            catch (Exception ex)
            {
                _oerrorlogging.Error = ex.Message;
                _oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                _oApplicationLib.logException(_oerrorlogging);
                Response.Redirect("EmptyPage");
            }
        }



        protected void LnkBtnBak_Click(object sender, EventArgs e)
        {

            Response.Redirect("PlacementCalendar.aspx");

        }


    }
}