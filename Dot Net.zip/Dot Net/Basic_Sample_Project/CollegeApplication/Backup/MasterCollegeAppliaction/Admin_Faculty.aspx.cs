﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class Admin_Faculty : System.Web.UI.Page
    {
        ApplicationLibrary oApplicationlibrary = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    string username = Session["name"].ToString();
                    oLabel.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                    drp_dept.DataSource = oApplicationlibrary.GetDeptList();
                    drp_dept.DataBind();
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
              }
        }

        protected void LnkbtnAddFaculty_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddFaculty.aspx");
        }

        protected void lnkbtnviewfaculty_Click(object sender, EventArgs e)
        {
            LblDelete.Visible = false;
            PnlAddCmpny.Visible = true;          
            LblVwFac.Visible = true;
            grdviewFaculty.Columns[5].Visible = false;
         
          
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
               
                int dept = oApplicationlibrary.ConvertingDeptId(drp_dept.SelectedValue);
             
                grdviewFaculty.DataSource = oApplicationlibrary.GetFaculty(dept);
                grdviewFaculty.DataBind();
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

        protected void LnkBtnBak_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin.aspx");
        }

        protected void LnkBtnBak_Click1(object sender, EventArgs e)
        {
            Response.Redirect("Admin.aspx");
        }

        protected void grdviewFaculty_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string id = string.Empty;
            int dept = oApplicationlibrary.ConvertingDeptId(drp_dept.SelectedValue);
            if (e.CommandName == "DELETE")
            {
                id = e.CommandArgument.ToString();
             
            }
            int facultyid = int.Parse(id);
            oApplicationlibrary.DeletingFaculty(facultyid);
            grdviewFaculty.DataSource = oApplicationlibrary.GetFaculty(dept);

            grdviewFaculty.DataBind();
           
        }

       
        protected void grdviewFaculty_RowDeleting1(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void lnkbtndeletefaculty_Click(object sender, EventArgs e)
        {
            PnlAddCmpny.Visible = true;      
            LblDelete.Visible = true;
            LblVwFac.Visible = false;
            pnlview.Visible = true;
            grdviewFaculty.Columns[5].Visible = true;
        }
    }
}