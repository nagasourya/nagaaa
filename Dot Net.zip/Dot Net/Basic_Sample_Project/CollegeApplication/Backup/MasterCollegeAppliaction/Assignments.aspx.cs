﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;
using MasterDataAccess;
using System.IO;

namespace MasterCollegeAppliaction
{
    public partial class Assignments : System.Web.UI.Page
    {
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();
        protected void Page_Load(object sender, EventArgs e)
        {
           
            if (!IsPostBack)
            {
                //Label oLabel = new Label();
                //Label oLabel1 = new Label();
                //oLabel = (Label)Master.FindControl("lblWelcomeName");
                //oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                //string username = Session["name"].ToString();
                //oLabel.Text = username;
                //string lastdate = Session["LastLogIn"].ToString();
                //oLabel1.Text = lastdate;               
                bindgrid();
            }
        }

        public void bindgrid()
        {
            string loguser = Session["LoggedUser"].ToString();
            int id =int.Parse(Session["ID"].ToString());           
            gvDetails.Visible = true;
            gvDetails.DataSource = oApplicationLib.getdata(loguser,id);
            gvDetails.DataBind();
            if (gvDetails.Rows.Count == 0)
            {
                LblErr.Visible = true;
                gvDetails.Visible = false;
            }
            else
            {
                LblErr.Visible = false;
                gvDetails.Visible = true;
            }
        }
       

        protected void gvDetails_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string paths = "";
            if (e.CommandName == "Download")
            {
                paths = e.CommandArgument.ToString();
                Response.AddHeader("Content-Disposition", "attachment;filename=\"" + paths + "\"");
            }
        }

        protected void LnkBtnBack_Click(object sender, EventArgs e)
        {
            if (Session["LoggedUser"].Equals("Student"))
            {
                Response.Redirect("Students_View.aspx");
            }
            else if (Session["LoggedUser"].Equals("Faculty"))
            {
                Response.Redirect("Faculty_View.aspx");
            }
        }

        protected void btnUpload_Click1(object sender, EventArgs e)
        {
            try
            {
                string filename = Path.GetFileName(fileUpload1.PostedFile.FileName);
                string loguser = Session["LoggedUser"].ToString();
                int id = int.Parse(Session["ID"].ToString());
                AssignmentModel oassignmod = new AssignmentModel();
                oassignmod.Personid = id;
                if (loguser.Equals("Student"))
                {
                    oassignmod = oApplicationLib.getstudent(oassignmod);

                    if (oassignmod.Deptname.Equals("EEE"))
                    {
                        fileUpload1.SaveAs(Server.MapPath(@"~/Student/EEE/" + filename));
                        oassignmod.Filename = filename;
                        oassignmod.Filepath = @"~/Student/EEE/" + filename;
                        oassignmod.Filedate = System.DateTime.Now;
                        oApplicationLib.insertgrid(oassignmod);
                        bindgrid();
                        LblInfo.Visible = true;
                        LblInfo.Text = "File Uploaded Successfully..";
                    }
                    else if (oassignmod.Deptname.Equals("ECE"))
                    {
                        fileUpload1.SaveAs(Server.MapPath(@"~/Student/ECE/" + filename));
                        oassignmod.Filename = filename;
                        oassignmod.Filepath = @"~/Student/ECE/" + filename;
                        oassignmod.Deptname = oassignmod.Deptname;
                        oassignmod.Filedate = System.DateTime.Now;
                        oApplicationLib.insertgrid(oassignmod);
                        bindgrid();
                        LblInfo.Visible = true;
                        LblInfo.Text = "File Uploaded Successfully..";
                    }
                    else if (oassignmod.Deptname.Equals("CSE"))
                    {
                        fileUpload1.SaveAs(Server.MapPath(@"~/Student/CSE/" + filename));
                        oassignmod.Filename = filename;
                        oassignmod.Filepath = @"~/Student/CSE/" + filename;
                        oassignmod.Deptname = oassignmod.Deptname;
                        oassignmod.Filedate = System.DateTime.Now;
                        oApplicationLib.insertgrid(oassignmod);
                        bindgrid();
                        LblInfo.Visible = true;
                        LblInfo.Text = "File Uploaded Successfully..";
                    }
                }
                else if (loguser.Equals("Faculty"))
                {
                    oassignmod = oApplicationLib.getfaculty(oassignmod);
                    if (oassignmod.Deptname.Equals("EEE"))
                    {
                        fileUpload1.SaveAs(Server.MapPath(@"~/Faculty/EEE/" + filename));
                        oassignmod.Filename = filename;
                        oassignmod.Filepath = @"~/Faculty/EEE/" + filename;
                        oassignmod.Filedate = System.DateTime.Now;
                        oApplicationLib.insertgrid(oassignmod);
                        bindgrid();
                        LblInfo.Visible = true;
                        LblInfo.Text = "File Uploaded Successfully..";
                    }
                    else if (oassignmod.Deptname.Equals("ECE"))
                    {
                        fileUpload1.SaveAs(Server.MapPath(@"~/Faculty/ECE/" + filename));
                        Response.Write(filename);
                        oassignmod.Filename = filename;
                        oassignmod.Filepath = @"~/Faculty/ECE/" + filename;
                        oassignmod.Filedate = System.DateTime.Now;
                        oApplicationLib.insertgrid(oassignmod);
                        bindgrid();
                        LblInfo.Visible = true;
                        LblInfo.Text = "File Uploaded Successfully..";
                    }
                    else if (oassignmod.Deptname.Equals("CSE"))
                    {
                        fileUpload1.SaveAs(Server.MapPath(@"~/Faculty/CSE/" + filename));
                        oassignmod.Filename = filename;
                        oassignmod.Filepath = @"~/Faculty/CSE/" + filename;
                        oassignmod.Filedate = System.DateTime.Now;
                        oApplicationLib.insertgrid(oassignmod);
                        bindgrid();
                        LblInfo.Visible = true;
                        LblInfo.Text = "File Uploaded Successfully..";
                    }
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }

        }
    }
}

