﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class Admin_Student : System.Web.UI.Page
    {
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();   
        ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
        protected void Page_Load(object sender, EventArgs e)
        {
            
            try
            {
                if (!IsPostBack)
                {
                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    string username = Session["name"].ToString();
                    oLabel.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
               
            }
        }

        protected void LnkbtnAddStudents_Click1(object sender, EventArgs e)
        {
            Response.Redirect("AddStudent.aspx");
        }

        protected void lnkbtnViewStudents_Click(object sender, EventArgs e)
        {
            pnlviewstudents.Visible = true;
            drp_dept.DataSource = oapplicationlibrary.GetDeptList();
            drp_dept.DataBind();
        }

        protected void ImgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                
                int dept = oapplicationlibrary.ConvertingDeptId(drp_dept.SelectedItem.Text);
                //StudentLib ostudentlib = new StudentLib();
                grd_viewstudents.DataSource = oapplicationlibrary.GetStudent(dept);
                grd_viewstudents.DataBind();
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oapplicationlibrary.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
                
            }

        }   

      
    }
}