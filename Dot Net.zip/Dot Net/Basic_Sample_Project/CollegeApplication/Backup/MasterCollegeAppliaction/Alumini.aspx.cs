﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class Alumini : System.Web.UI.Page
    {

        StudentModel ost = new StudentModel();
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();  
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                HiddenField1.Value =Session["ID"].ToString();
                if (!IsPostBack)
                {
                    Label oLabel = new Label();
                    Label oLabel1 = new Label();
                    oLabel = (Label)Master.FindControl("lblWelcomeName");
                    oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                    string username = Session["name"].ToString();
                    oLabel.Text = username;
                    string lastdate = Session["LastLogIn"].ToString();
                    oLabel1.Text = lastdate;
                    int userid = int.Parse(Session["ID"].ToString());
                    ApplicationLibrary oapplication = new ApplicationLibrary();
                    studentview.DataSource = oapplication.ViewProfileStudent(userid);
                    studentview.DataBind();
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
           
            }
        }


        protected void LnkBtnAddEvents_Click(object sender, EventArgs e)
        {
            PnlEditProfile.Visible = true;
            // Pnlbdyleft.Visible = false;
        }

        protected void ImgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {

            try
            {
                int id = int.Parse(HiddenField1.Value);
                long contactnumber = long.Parse(txt_contact.Text);
                string address = txt_address.Text;
                string designation = txt_designation.Text;
                string company = txt_company.Text;

                int x = oApplicationLib.updatealumini(id, contactnumber, address, designation, company);
                if (x == 1)
                {
                    ErrMsgBox.AddMessage("Profile Updated..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Success);
                    txt_contact.Text = "";
                    txt_address.Text = "";
                    txt_company.Text = "";
                    txt_designation.Text = "";
                    PnlEditProfile.Visible = false;
                    // Pnlbdyleft.Visible = true;
                }
                else
                {
                    ErrMsgBox.AddMessage("Sorry!!!Profile Not Updated..Pls Check the Details..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Success);
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
                
            }
        }
        protected void ImgBtnCancel_Click(object sender, ImageClickEventArgs e)
        {
            PnlEditProfile.Visible = false;
            //Pnlbdyleft.Visible = true;
        }



        protected void ImgBtnClose_Click(object sender, ImageClickEventArgs e)
        {
            //Pnlbdyleft.Visible = true;
            PnlViewAlumini.Visible = false;
        }

        protected void ImgBtnSearchSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                string yop = "SELECT";
                string s = txtsearch.Text;
                yop = drpdwnyop.SelectedItem.Value;
                if (s.Equals("") && (yop.Equals("SELECT")))
                {
                    ErrMsgBox.AddMessage("Please Enter Name or Choose Year Of passed Out to Search..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Attention);
                }
                else if (!(s.Equals("")) && !(yop.Equals("SELECT")))
                {
                    //yop = int.Parse(drpdwnyop.SelectedItem.Value.ToString());
                    var getalumini = oApplicationLib.viewAlumini(s, int.Parse(yop));
                    GrdVwAlumini.DataSource = getalumini;
                    GrdVwAlumini.DataBind();
                    if (GrdVwAlumini.Rows.Count == 0)
                    {
                        LblAlError.Visible = true;
                        GrdVwAlumini.Visible = false;
                    }
                    else
                    {
                        LblAlError.Visible = false;                        
                        GrdVwAlumini.Visible = true;
                    }
                }
                else if ((s.Equals("")) && !(yop.Equals("SELECT")))
                {
                    //yop = int.Parse(drpdwnyop.SelectedItem.Value.ToString());
                    var getalumini = oApplicationLib.viewAlumini(int.Parse(yop));
                    GrdVwAlumini.DataSource = getalumini;
                    GrdVwAlumini.DataBind();
                    if (GrdVwAlumini.Rows.Count == 0)
                    {
                        LblAlError.Visible = true;
                        GrdVwAlumini.Visible = false;
                    }
                    else
                    {
                        LblAlError.Visible = false;
                        GrdVwAlumini.Visible = true;
                    }
                }
                else if (!(s.Equals("")) && (yop.Equals("SELECT")))
                {
                    var getalumini = oApplicationLib.viewAlumini(s);
                    GrdVwAlumini.DataSource = getalumini;
                    GrdVwAlumini.DataBind();
                    if (GrdVwAlumini.Rows.Count == 0)
                    {
                        LblAlError.Visible = true;
                        GrdVwAlumini.Visible = false;
                    }
                    else
                    {
                        LblAlError.Visible = false;
                        GrdVwAlumini.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
               
            }
        }




        protected void LnkBtnEditProf_Click(object sender, EventArgs e)
        {
            PnlEditProfile.Visible = true;
            PnlViewAlumini.Visible = false;
        }

        protected void lnkbtnViewAlumini_Click(object sender, EventArgs e)
        {
            try
            {
                PnlViewAlumini.Visible = true;
                PnlEditProfile.Visible = false;
                int dt = int.Parse(DateTime.Now.Year.ToString());

                for (int i = 0; i < 9; i++)
                {
                    ListItem ilist = new ListItem();
                    ilist.Value = (dt - i).ToString();
                    drpdwnyop.Items.Add(ilist);

                }

                var getalumini = oApplicationLib.viewAlumini();
                GrdVwAlumini.DataSource = getalumini;
                GrdVwAlumini.DataBind();
                if (GrdVwAlumini.Rows.Count == 0)
                {
                    LblAlError.Visible = true;
                    GrdVwAlumini.Visible = false;
                }
                else
                {
                    LblAlError.Visible = false;
                    GrdVwAlumini.Visible = true;
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }


    }
}