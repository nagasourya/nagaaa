﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class UserApplicationStatus : System.Web.UI.Page
    {
        ErrorLoggingModel oerrorlogging = new ErrorLoggingModel();   
        protected void Page_Load(object sender, EventArgs e)
        {
            
            Label oLabel = new Label();
            Label oLabel1 = new Label();
        
            Label olabel2 = new Label();
            Label olabel3 = new Label();
            olabel2 = (Label)Master.FindControl("lblWelcome");
            olabel2.Visible = false;
            olabel3 = (Label)Master.FindControl("lblLastLogInTime");
            olabel3.Visible = false;

            oLabel = (Label)Master.FindControl("lblWelcomeName");
            oLabel.Visible = false;
            oLabel1 = (Label)Master.FindControl("lblLastLogIn");
            oLabel1.Visible = false;
            ImageButton oImgButton = new ImageButton();
            oImgButton = (ImageButton)Master.FindControl("imgbtnLogout");
            oImgButton.Visible = false;

        }
        ApplicationLibrary oApplicationLib = new ApplicationLibrary();

        protected void ImgBtnSubmit_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                UserStatusModel oUserStatusMod = new UserStatusModel();
                oUserStatusMod.Id = int.Parse(txtappid.Text);


                oUserStatusMod = oApplicationLib.CheckStatus(oUserStatusMod);

                if (oUserStatusMod.Name == null)
                {
                    ScriptManager.RegisterClientScriptBlock(this,this.GetType(),"key","alert('Sorry..Application ID Not Found!!!..')",true);
                }
                else
                {
                    CheckStatusPanel.Visible = false;
                    ShowStatusPanel.Visible = true;
                    Label1.Text = oUserStatusMod.Name;
                    Label2.Text = oUserStatusMod.Gender;
                    Label3.Text = oUserStatusMod.Department;
                    Label4.Text = oUserStatusMod.Avgmark.ToString();
                    Label5.Text = oUserStatusMod.Address;
                    Label6.Text = oUserStatusMod.Contactno.ToString();
                    Label7.Text = oUserStatusMod.Email;
                    Label8.Text = oUserStatusMod.Id.ToString();
                    LblCurrentStatus.Text = oApplicationLib.GetStatus(oUserStatusMod.Statusid);
                }
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
           
        }

        protected void ImgBtnClose_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                CheckStatusPanel.Visible = true;
                ShowStatusPanel.Visible = false;
            }
            catch (Exception ex)
            {
                oerrorlogging.Error = ex.Message;
                oerrorlogging.Loggeduser = Session["LoggedUser"].ToString();
                oApplicationLib.logException(oerrorlogging);
                Response.Redirect("EmptyPage.aspx");
            }
        }

      

        protected void ImgBtnClear_Click1(object sender, ImageClickEventArgs e)
        {
            txtappid.Text = "";
        }

       
    }
}