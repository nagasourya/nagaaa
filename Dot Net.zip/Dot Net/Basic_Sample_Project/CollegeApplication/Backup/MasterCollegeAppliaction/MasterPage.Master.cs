﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace MasterCollegeAppliaction
{
    public partial class MasterPage : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void imgbtnLogout_Click(object sender, ImageClickEventArgs e)
        {
            Session["ID"] = null;
            Session["LoggedUser"] = null;
            Response.Redirect("HomePage.aspx");
            Session.Abandon();
            FormsAuthentication.SignOut();
            FormsAuthentication.RedirectToLoginPage();
        }

        protected void lnkHome_Click(object sender, EventArgs e)
        {

            if (Session["LoggedUser"] == null)
            {
                Response.Redirect("HomePage.aspx");
            }
            else
            {
                string s = Session["LoggedUser"].ToString();

                switch (s)
                {
                    case "Student":
                        Response.Redirect("Students_view.aspx");
                        break;
                    case "Faculty":
                        Response.Redirect("Faculty_View.aspx");
                        break;
                    case "Admin":
                        Response.Redirect("Admin.aspx");

                        break;
                    case "Alumni":
                        Response.Redirect("Alumini.aspx");
                        break;
                }

            }
        }
        protected void LnkCourses_Click(object sender, EventArgs e)
        {
            Response.Redirect("Courses.aspx");
        }

        protected void Menu1_MenuItemClick(object sender, MenuEventArgs e)
        {
            Menu gtmenu = (Menu)sender;

            if (gtmenu.SelectedValue.Equals("Home"))
            {
                string s = null;
                if (Session["LoggedUser"] != null)
                {
                    s = Session["LoggedUser"].ToString();
                }
                if (s == null)
                {
                    Response.Redirect("Homepage.aspx");
                }
                switch (s)
                {
                    case "Student":
                        Response.Redirect("Students_view.aspx");
                        break;
                    case "Faculty":
                        Response.Redirect("Faculty_View.aspx");
                        break;
                    case "Admin":
                        Response.Redirect("Admin.aspx");

                        break;
                    case "Alumni":
                        Response.Redirect("Alumini.aspx");
                        break;
                    case "":
                        Response.Redirect("Homepage.aspx");
                        break;
                }
            }
        }
    }
}