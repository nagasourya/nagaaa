﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterDataAccess
{
    public class ApplicationDataAccess1
    {
        CollegeApplicationEntities ocollegeapplicationentities = new CollegeApplicationEntities();
        public int gttestid()
        {
            int res = (from r in ocollegeapplicationentities.Tests select r.TestId).Max();
            return res;
        }
        public void inserttestname(Test otest)
        {
           
            ocollegeapplicationentities.Tests.AddObject(otest);
            ocollegeapplicationentities.SaveChanges();
        }
        public IEnumerable<Test> GetTest()
        {
            var result = from table in ocollegeapplicationentities.Tests
                         where table.IsActive==true
                         select table;
            return result;
        }
        public IEnumerable<Test> GetTestAdmin()
        {
            var result = from table in ocollegeapplicationentities.Tests  select table;
            return result;
        }
        public void UpdateTestStatus(bool value,int id)
        {
            var result = from table in ocollegeapplicationentities.Tests
                         where table.TestId == id
                         select table;
            foreach (Test exam in result)
            {
                exam.IsActive = value;
            }
            ocollegeapplicationentities.SaveChanges();
                        
        }
    }
}
