﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterDataAccess
{
    public class ApplicationDataAccess
    {
        readonly CollegeApplicationEntities oCollegeApplicationEntities = new CollegeApplicationEntities();
        //viewing All events of the college query
        public List<string> ShowDepartment()
        {
            var gtdeptlist = from res in oCollegeApplicationEntities.Departments select res.Name;
            return gtdeptlist.ToList();
        }
        public IEnumerable<CollegeEvent> ViewEvents()
        {

            return from res in oCollegeApplicationEntities.CollegeEvents select res;

        }
        //viewing class meeting for faculty only
        public IEnumerable<CollegeEvent> ViewEventsFaculty()
        {
            return from res in oCollegeApplicationEntities.CollegeEvents where res.EventsName == "Meetings" select res;
        }
        //Adding Events to Events Table
        public int SubmitEvent(CollegeEvent oCollEvt)
        {
            oCollegeApplicationEntities.CollegeEvents.AddObject(oCollEvt);
            return oCollegeApplicationEntities.SaveChanges(); ;
        }
        //Showing events based on Date

        public List<CollegeEvent> ShowEvent(List<DateTime> oListDate)
        {
            DateTime d = DateTime.Now, dd = DateTime.Now;
            foreach (var i in oListDate)
            {
                d = oListDate.FirstOrDefault();
                dd = oListDate.LastOrDefault();
            }

            var gtevent = from evt in oCollegeApplicationEntities.CollegeEvents where evt.EventDate >= d && evt.EventDate <= dd select evt;

            return gtevent.ToList();
        }


        //---login---


        //updating students last login column
        public void UpdateStudentLastLogIn(int id, string password)
        {
            var update = from tblstudent in oCollegeApplicationEntities.Students
                         where tblstudent.Id == id
                         select tblstudent;
            foreach (var s in update.Where(s => s.Id == id))
            {
                s.LastModifiedDate = DateTime.Now;
            }
            oCollegeApplicationEntities.SaveChanges();
        }
        //Updating faculty lastloginin column
        public void UpdateFacultyLastLogIn(int id, string password)
        {
            var update = from tblfaculty in oCollegeApplicationEntities.Faculties
                         where tblfaculty.Id == id
                         select tblfaculty;
            foreach (Faculty f in update.Where(f => f.Id == id))
            {
                f.LastModifiedDate = DateTime.Now;
            }
            oCollegeApplicationEntities.SaveChanges();
        }
        //updating Admin lastlogin column
        public void UpdateAdminLastLogIn(int id, string password)
        {

            var update = from tbladmin in oCollegeApplicationEntities.Admins
                         where tbladmin.Id == id
                         select tbladmin;
            foreach (var ad in update.Where(ad => ad.Id == id))
            {
                ad.LastModifiedDate = DateTime.Now;
            }
            oCollegeApplicationEntities.SaveChanges();
        }
        //geting the faculty table
        public IEnumerable<Faculty> FacultyDataBase()
        {
            return from tblfac in oCollegeApplicationEntities.Faculties
                   select tblfac;
        }
        //getting the whole student table
        public IEnumerable<Student> StudentDataBase()
        {

            var stu = from tblstu in oCollegeApplicationEntities.Students
                      select tblstu;
            return stu;
        }
        //getting the whole admin table
        public IEnumerable<Admin> AdminDataBase()
        {
            return from tbladm in oCollegeApplicationEntities.Admins
                   select tbladm;
        }
        //Saving password for faculty
        public void SaveFacultyPassword(string password, int newuserid)
        {
            var save = from tblfac in oCollegeApplicationEntities.Faculties
                       where tblfac.Id == newuserid
                       select tblfac;
            foreach (var f in save.Where(f => f.Id == newuserid))
            {
                f.Password = password;
            }
            oCollegeApplicationEntities.SaveChanges();
        }
        //Saving password for Student
        public void SaveStudentPassword(string password, int newuserid)
        {
            var save = from tblstu in oCollegeApplicationEntities.Students
                       where tblstu.Id == newuserid
                       select tblstu;
            foreach (var s in save.Where(s => s.Id == newuserid))
            {
                s.Password = password;
            }
            oCollegeApplicationEntities.SaveChanges();
        }
        //Saving Faculty password
        public void SaveAdminPassword(string password, int newuserid)
        {
            var save = from tbladm in oCollegeApplicationEntities.Admins
                       where tbladm.Id == newuserid
                       select tbladm;
            foreach (var ad in save)
            {
                if (ad.Id == newuserid)
                {
                    ad.Password = password;
                }
            }

            oCollegeApplicationEntities.SaveChanges();
        }

        //Changing the password of student

        public void ChangeStudentPassword(string password, int id)
        {
            var save = from tblstu in oCollegeApplicationEntities.Students
                       where tblstu.Id == id
                       select tblstu;
            foreach (var s in save.Where(s => s.Id == id))
            {
                s.Password = password;
            }
            oCollegeApplicationEntities.SaveChanges();
        }
        //changa password for faculty
        public void ChangeFacultyPassword(string password, int id)
        {
            var _save = from tblfac in oCollegeApplicationEntities.Faculties
                        where tblfac.Id == id
                        select tblfac;
            foreach (Faculty f in _save)
            {
                if (f.Id == id)
                {
                    f.Password = password;
                }
            }
            oCollegeApplicationEntities.SaveChanges();
        }
        //Change password for Admin
        public void ChangeAdminPassword(string password, int id)
        {
            var _save = from tbladm in oCollegeApplicationEntities.Admins
                        where tbladm.Id == id
                        select tbladm;
            foreach (Admin ad in _save)
            {
                if (ad.Id == id)
                {
                    ad.Password = password;
                }
            }
            oCollegeApplicationEntities.SaveChanges();
        }

        //-------------SUBJECTS,EXAM SCHEDULE------------------------
        //Get Subject for sem and department
        public IEnumerable<Subject> GetSubjects(string sem, int dept)
        {

            var result = from subject in oCollegeApplicationEntities.Subjects
                         where subject.Semester == sem && subject.DepartmentId == dept
                         select subject;
            return result;
        }
        //Storing values in Examschedule
        public bool InserData(List<ExamSchedule> examlist, int year, string sem, int dept)
        {
            var value = false;

            var result = (from schedule in oCollegeApplicationEntities.ExamSchedules
                          where schedule.Year == year && schedule.Semester == sem && schedule.DepartmentId == dept
                          select schedule.DepartmentId).FirstOrDefault();
            if (result == null)
            {
                foreach (var s1 in examlist)
                {
                    oCollegeApplicationEntities.ExamSchedules.AddObject(s1);
                    oCollegeApplicationEntities.SaveChanges();
                    value = true;
                }
            }
            else
            {
                value = false;
            }
            return value;
        }
        //Adding Subjcts to Subject table
        public bool Addsubject(Subject osubject, int code)
        {
            var value = false;

            var result = (from id in oCollegeApplicationEntities.Subjects
                          where id.Code == code
                          select id.SubjectName).SingleOrDefault();
            if (result == null)
            {
                oCollegeApplicationEntities.Subjects.AddObject(osubject);
                oCollegeApplicationEntities.SaveChanges();
                value = true;
            }
            else
            {
                value = false;
            }
            return value;
        }
        //Getting data from Exam Schedule for rescheduling it
        public IEnumerable<ExamSchedule> GetForReschedule(int year, string sem, int dept)
        {

            var result = from schedule in oCollegeApplicationEntities.ExamSchedules
                         where schedule.DepartmentId == dept && schedule.Semester == sem && schedule.Year == year
                         select schedule;
            return result;
        }


        //updating by reschdule data 
        public bool RescheduleDate(int code, DateTime dt, int year)
        {
            bool value = false;

            try
            {
                var result = from schedule in oCollegeApplicationEntities.ExamSchedules
                             where schedule.Code == code && schedule.Year == year
                             select schedule;
                foreach (var exam in result)
                {
                    exam.OnDate = dt;
                }
                oCollegeApplicationEntities.SaveChanges();
                value = true;
            }
            catch
            {
                value = false;
            }
            return value;
        }
        //Query for viewing exam Schedule
        public IEnumerable<ExamSchedule> ViewSchedule(int year, int dept, string sem)
        {

            var result = from schedule in oCollegeApplicationEntities.ExamSchedules
                         where schedule.Year == year && schedule.DepartmentId == dept && schedule.Semester == sem
                         select schedule;
            return result;
        }
        //Query for getting Subject code
        public int GetSubjectCode(string subjectname)
        {

            int result = (from subid in oCollegeApplicationEntities.Subjects
                          where subid.SubjectName == subjectname
                          select subid.Code).Single();
            return result;
        }
        public string GetSubjectName(int code)
        {
            string result = (from subid in oCollegeApplicationEntities.Subjects
                             where subid.Code == code
                             select subid.SubjectName).Single();
            return result;
        }
        //Querying Get Subject for Dept
        public List<string> GetSubjectOnDept(int dept)
        {

            var result = (from paper in oCollegeApplicationEntities.Subjects
                          where paper.DepartmentId == dept
                          select paper.SubjectName).ToList();
            return result;
        }
        public List<string> GetSubjectOnDeptandSemester(int dept, string sem)
        {

            var result = (from paper in oCollegeApplicationEntities.Subjects
                          where paper.DepartmentId == dept && paper.Semester == sem
                          select paper.SubjectName).ToList();
            return result;
        }
        //public IEnumerable<ClassSchedule> GetClassSchedule()
        //{
        //    CollegeApplicationEntities ocollegeapplicationentities = new CollegeApplicationEntities();
        //    var result = (from table in ocollegeapplicationentities.ClassSchedules
        //                  select table);
        //    return result;
        //}


        //------------------student,faculty insert,appl approval,place cal-------
        //converting deptid on deptname
        public int ConvertingDeptID(string dept)
        {
            return (from id in oCollegeApplicationEntities.Departments where id.Name == dept select id.Id).SingleOrDefault();
        }
        //insert data for student
        public int InsertData(Student ostudent)
        {

            oCollegeApplicationEntities.Students.AddObject(ostudent);
            return oCollegeApplicationEntities.SaveChanges();

        }
        //Insert data for faculty
        public int InsertData(Faculty ofaculty)
        {

            oCollegeApplicationEntities.Faculties.AddObject(ofaculty);
            return oCollegeApplicationEntities.SaveChanges(); ;

        }
        // Insert Data for Company
        public int InsertData(Company ocompany)
        {

            oCollegeApplicationEntities.Companies.AddObject(ocompany);
            return oCollegeApplicationEntities.SaveChanges();
        }
        //Insert Data for Placement Calender
        public bool InsertData(PlacementCalendar oplacementcalender, DateTime date, string companyname)
        {

            var val = false;
            try
            {
                var place = (from verify in oCollegeApplicationEntities.PlacementCalendars
                             where verify.Company == companyname && verify.OnDate == date
                             select verify.Company).SingleOrDefault();
                if (place == null)
                {
                    oCollegeApplicationEntities.PlacementCalendars.AddObject(oplacementcalender);
                    oCollegeApplicationEntities.SaveChanges();
                    val = true;
                }
            }
            catch (Exception)
            {
                val = false;
            }
            return val;
        }
        //To view Faculty
        public IEnumerable<Faculty> GetFacuty(int dpt)
        {
            var oCollegeApplicationEntities1 = new CollegeApplicationEntities();
            var facultys = from facul in oCollegeApplicationEntities1.Faculties
                           where facul.DepartmentId == dpt && facul.IsActive == true
                           select facul;
            return facultys;
        }
        //To view Placement Calender
        public IEnumerable<PlacementCalendar> GetPlacementCalender()
        {

            var calender = from dates in oCollegeApplicationEntities.PlacementCalendars
                           orderby dates.OnDate descending
                           select dates;
            return calender;
        }
        //To get company added
        public List<string> GetCompany()
        {

            var _com = (from comp in oCollegeApplicationEntities.Companies
                        select comp.CompanyName).ToList();

            return _com;
        }
        //To view Students
        public IEnumerable<Student> GetStudent(int dpt)
        {

            var Studentt = from studen in oCollegeApplicationEntities.Students
                           where studen.DepartmentId == dpt
                           select studen;
            return Studentt;
        }
        //To get Departments
        public IEnumerable<Department> GetDepartment()
        {

            var depttable = from dept in oCollegeApplicationEntities.Departments
                            select dept;
            return depttable;


        }
        //To get UserForm
        public IEnumerable<UserForm> GetUserForm(string dept)
        {

            var userform = from form in oCollegeApplicationEntities.UserForms
                           where form.Department == dept && form.Statusid == 1
                           select form;
            return userform;
        }
        //Updating Status of the User
        public void Updatestatus(int id, string userstatus)
        {

            //query to change the status is the user form table
            var appId = from userid in oCollegeApplicationEntities.UserForms
                        where userid.Id == id
                        select userid;
            //to find the status id for corresponding status
            var statusid = from sta in oCollegeApplicationEntities.UserStatus
                           where sta.Status == userstatus
                           select sta.Id;
            var _userstatus = statusid.Single();

            foreach (var uf in appId)
            {
                uf.Statusid = _userstatus;
            }
            oCollegeApplicationEntities.SaveChanges();
        }
        //To update Vacancy in Admission Approval
        public void Updatevacancy(string dept, string status)
        {

            var vacancy1 = from vacancy in oCollegeApplicationEntities.Departments
                           where vacancy.Name == dept
                           select vacancy;

            foreach (var odepartment in vacancy1.Where(odepartment => status == "Accepted"))
            {
                odepartment.Vacancy = odepartment.Vacancy - 1;
                if (odepartment.Vacancy == -1)
                {
                    odepartment.Vacancy = odepartment.Vacancy + 1;
                }
            }
            oCollegeApplicationEntities.SaveChanges();
        }
        //Viewing  the applicant on Status
        public IEnumerable<UserForm> ViewOnStatus(string status)
        {

            var _state =
                oCollegeApplicationEntities.UserStatus.Where(stat => stat.Status == status).Select(stat => stat.Id);
            var state = _state.Single();
            var userform = from form in oCollegeApplicationEntities.UserForms
                           where form.Statusid == state
                           select form;
            return userform;
        }
        //Get Department On DeptId
        public string GetDeptOnDeptId(string[] dept)
        {
            // int deptID = (from ls in ocollegeapplicationentities.Departments where ls.Name.Equals(dept) select ls.Id).SingleOrDefault();
            return dept.Select(word => (from ls in oCollegeApplicationEntities.Departments
                                        where ls.Name == word
                                        select ls.Id).Single()).Aggregate("", (current, depid) => current + depid.ToString());
        }
        //To view Class Schedule
        public IEnumerable<ClassSchedule> GetClassSchedule()
        {

            return from table in oCollegeApplicationEntities.ClassSchedules
                   select table;
        }
        //Inserting Class Schedule
        public bool InserData(List<ClassSchedule> classlist, string sem, int dept, int years)
        {
            var value = false;

            var result = (from schedule in oCollegeApplicationEntities.ClassSchedules
                          where schedule.semester == sem && schedule.dept == dept && schedule.Year == years
                          select schedule.Department).FirstOrDefault();
            if (result == null)
            {
                foreach (var s1 in classlist)
                {
                    oCollegeApplicationEntities.ClassSchedules.AddObject(s1);
                    oCollegeApplicationEntities.SaveChanges();
                    value = true;
                }
            }
            else
            {
                return false;
            }
            return value;
        }
        //Viewing Class Schedule
        public IEnumerable<ClassSchedule> GetClassSchedule(string sem, int dept, int years)
        {
            return oCollegeApplicationEntities.ClassSchedules.Where(
                    schedule => schedule.semester == sem && schedule.dept == dept && schedule.Year == years);
        }



        //--------------FeebBack ---------------
        //Getting the Feedback
        public IEnumerable<Feedback> FeedBackLoad()
        {

            return from ls in oCollegeApplicationEntities.Feedbacks
                   orderby ls.CreatedDate descending
                   select ls;
        }
        //Updating feedback table
        public void FeedBackUpdate(Feedback oFb)
        {

            oCollegeApplicationEntities.Feedbacks.AddObject(oFb);
            oCollegeApplicationEntities.SaveChanges();
        }

        //Submitting User Application Form

        public int SubmitForm(UserForm oUserForm)
        {

            oCollegeApplicationEntities.UserForms.AddObject(oUserForm);
            oCollegeApplicationEntities.SaveChanges();
            var appid = (from app in oCollegeApplicationEntities.UserForms
                         select app.Id).Max();

            return appid;
        }

        //------USER STATUS DATA ACCESS-------

        public List<UserForm> CheckStatus(UserForm oUserForm)
        {
            var appid = from lb in oCollegeApplicationEntities.UserForms where lb.Id == oUserForm.Id select lb;

           // var getstatusid = from uf in oCollegeApplicationEntities.UserForms where uf.Id == oUserForm.Statusid select uf.Statusid;

            return appid.ToList();

        }
        //Geting the Status fir status Id
        public string GetStatus(int statusid)
        {

            var getstatus = from us in oCollegeApplicationEntities.UserStatus where us.Id == statusid select us.Status;
            return getstatus.Single();
        }
        //------RESULT-----------------


        //Get Student for giving students
        public IEnumerable<Student> GetStudent(int dept, int year)
        {

            var result = from ls in oCollegeApplicationEntities.Students
                         where ls.DepartmentId == dept && ls.YearOfJoining == year
                         select ls;
            return result;
        }
        //To view Result
        public IEnumerable<Result> GetResult(int department)
        {

            var result = (from ls in oCollegeApplicationEntities.Results
                          where ls.Department == department
                          select ls).ToList();
            return result;
        }
        //Inserting result
        public bool InsertResult(string name, int id, int sem, decimal marks, int dept)
        {

            var studres = from stud in oCollegeApplicationEntities.Students
                          select stud;

            var isResultUpdated = false;

            var result = (from verify in oCollegeApplicationEntities.Results
                          where verify.RegisterNo == id
                          select verify.RegisterNo).SingleOrDefault();
            if (result == 0)
            {
                //CollegeApplicationEntities oce = new CollegeApplicationEntities();
                var res = new Result {Name = name, RegisterNo = id, Department = dept};
                switch (sem)
                {
                    case 1:
                        res.FirstSem = marks;
                        break;
                    case 2:
                        res.SecondSem = marks;
                        break;
                    case 3:
                        res.ThirdSem = marks;
                        break;
                    case 4:
                        res.FourthSem = marks;
                        break;
                    case 5:
                        res.FifthSem = marks;
                        break;
                    case 6:
                        res.SixthSem = marks;
                        break;
                    case 7:
                        res.SeventhSem = marks;
                        break;
                    case 8:
                        res.EigthSem = marks;
                        break;
                }


                oCollegeApplicationEntities.Results.AddObject(res);
                oCollegeApplicationEntities.SaveChanges();
                isResultUpdated = true;
            }
            else
            {
                var output = from verify in oCollegeApplicationEntities.Results
                             where verify.RegisterNo == id
                             select verify;
                foreach (var res in output)
                {
                    switch (sem)
                    {
                        case 1:
                            res.FirstSem = marks;
                            break;
                        case 2:
                            res.SecondSem = marks;
                            break;
                        case 3:
                            res.ThirdSem = marks;
                            break;
                        case 4:
                            res.FourthSem = marks;
                            break;
                        case 5:
                            res.FifthSem = marks;
                            break;
                        case 6:
                            res.SixthSem = marks;
                            break;
                        case 7:
                            res.SeventhSem = marks;
                            break;
                        case 8:
                            res.EigthSem = marks;
                            foreach (Student ss in studres)
                            {
                                ss.IsActive = false;
                            }
                            break;
                    }

                    isResultUpdated = true;
                }
                oCollegeApplicationEntities.SaveChanges();

            }

            return isResultUpdated;
        }

        //-----Alumini--EditProfile--------
        public int updatealumini(int id, long no, string address, string designation, string company)
        {
            var result = from rs in oCollegeApplicationEntities.Students
                         where rs.Id == id
                         select rs;

            foreach (var s in result)
            {
                s.ContactNo = no;
                s.Address = address;
                s.Designation = designation;
                s.CompanyName = company;


            }
            int x = oCollegeApplicationEntities.SaveChanges();
            return x;
        }

        //------------------View Alumini-------------------------
        public List<Student> ShowAlumini()
        {
            var yop = from rs in oCollegeApplicationEntities.Students where rs.PassedOutYear <= System.DateTime.Now.Year select rs;
            return yop.ToList();
        }
        //------------View Alumini By search---------

        public List<Student> ShowAlumini(string s, int yop)
        {
            var gtfulldata = from rs in oCollegeApplicationEntities.Students where rs.PassedOutYear == yop && rs.Name == s select rs;
            return gtfulldata.ToList();
        }
        //to view Alumini Based on yop
        public List<Student> ShowAlumini(int yop)
        {
            var gtdata = (from rs in oCollegeApplicationEntities.Students where rs.PassedOutYear == yop select rs);
            return gtdata.ToList();
        }
        //Show Alumini
        public List<Student> ShowAlumini(string s)
        {
            var gtdetails = from rs in oCollegeApplicationEntities.Students where rs.Name == s select rs;
            return gtdetails.ToList();

        }

        //-------------admin-addexamname-------------------//

        //public void InsertTestName(Test otest)
        //{
        //    CollegeApplicationEntities ocollegeapplicationentities = new CollegeApplicationEntities();
        //    ocollegeapplicationentities.Tests.AddObject(otest);
        //    ocollegeapplicationentities.SaveChanges();

        //}


        ////in student page for examschedule query/////
        //
        public List<QuestionDetail> GetQuestion(string testname)
        {
            var result = from table in oCollegeApplicationEntities.QuestionDetails
                         where table.TestName == testname
                         select table;

            return result.ToList();

        }
        //give score on Id
        public int GiveScore(int id)
        {
            var result = (from table in oCollegeApplicationEntities.QuestionDetails
                          where table.QuestionId == id
                          select table.CorrectOption).SingleOrDefault();
            var answer = int.Parse(result.ToString());
            return answer;
        }
        //Store questions for exams
        public void StoreQuestion(List<QuestionDetail> Question)
        {
            foreach (var data in Question)
            {
                oCollegeApplicationEntities.QuestionDetails.AddObject(data);
                oCollegeApplicationEntities.SaveChanges();
                // value = true;
            }
        }
        //Get Test name for adding exam
        public List<string> GetTestName()
        {
            var result = (from table in oCollegeApplicationEntities.Tests
                          select table.TestName).ToList();
            return result;

        }

        //-------------------FILE UPLOAD AND DOWNLOAD----------------
        //CollegeApplicationEntities oEntity = new CollegeApplicationEntities();
        //AssignmentModel am = new AssignmentModel();
        public int gtdept(string loguser, int id)
        {
            var result = 0;

            if (loguser.Equals("Student"))
            {
                var gtdeptid = from res in oCollegeApplicationEntities.Students where res.Id == id select res.DepartmentId;
                result = (int)gtdeptid.SingleOrDefault();
            }
            else if (loguser.Equals("Faculty"))
            {
                var gtdeptid = from res in oCollegeApplicationEntities.Faculties where res.Id == id select res.DepartmentId;
                result = (int)gtdeptid.SingleOrDefault();
            }
            return result;

        }
        //Get full uploaded data
        public IEnumerable<Assignment> getgrid(string deptname)
        {
            var result = from res in oCollegeApplicationEntities.Assignments
                         where res.DepartmentName == deptname
                         select res;
            return result;

        }
        //converting dept id
        public string convertdeptid(int id)
        {
            var getdept = (from res in oCollegeApplicationEntities.Departments where res.Id == id select res.Name).Single();
            return getdept;
        }
        //Get Student Uploads
        //public string getdept(int id)
        //{
        //    //    string s = id.ToString();
        //    //    string[] words = s.Split(' ');
        //    string dep = "";
        //    //    foreach (string i in words)
        //    //    {
        //    if (id.Equals(101))
        //    {
        //        dep = "EEE";
        //    }
        //    else if (id.Equals(201))
        //    {
        //        dep = "ECE";
        //    }
        //    else if (id.Equals(301))
        //    {
        //        dep = "CSE";
        //    }
        //    else if (id.Equals(101201))
        //    {
        //        dep = "EEE,ECE";

        //    }
        //    else if (id.Equals(101301))
        //    {
        //        dep = "EEE,CSE";
        //    }
        //    else if (id.Equals(201301))
        //    {
        //        dep = "ECE,CSE";

        //    }
        //    else if (id.Equals(101201301))
        //    {
        //        dep = "EEE,ECE,CSE";
        //    }
        //    //}
        //    return dep;
        //}

        public Assignment GetStudentDb(Assignment a)
        {
            var oCollegeApplicationEntities1 = new CollegeApplicationEntities();
            var getdepid = from res in oCollegeApplicationEntities1.Students
                           where res.Id == a.PersonId
                           select res;

            foreach (var s in getdepid)
            {
                a.PersonId = s.Id;
                a.PersonName = s.Name;
                a.DepartmentName = convertdeptid((int)s.DepartmentId);

            }

            //string deptname = convertdeptid(int.Parse(am.Personid.ToString()));

            return a;
        }
        // upload data in grid
        public void InsertData(Assignment ofiletable)
        {
            oCollegeApplicationEntities.Assignments.AddObject(ofiletable);
            oCollegeApplicationEntities.SaveChanges();


        }
        //Get faculty
        public Assignment GetFacultyDb(Assignment a)
        {
            var oCollegeApplicationEntities1 = new CollegeApplicationEntities();
            var getdepid = from res in oCollegeApplicationEntities1.Faculties
                           where res.Id == a.PersonId
                           select res;
            foreach (var f in getdepid)
            {
                a.PersonId = f.Id;
                a.PersonName = f.Name;
                a.DepartmentName = GetDept((int)f.DepartmentId);
                //a.DepartmentName = getdept((int)f.DepartmentId);

            }
            //var deptname = convertdeptid(int.Parse(getdepid.ToString()));

            return a;
        }
        public int AddDepartment(Department odepartment)
        {
            var save = 0;
            oCollegeApplicationEntities.Departments.AddObject(odepartment);
            save = oCollegeApplicationEntities.SaveChanges();
            return save;

        }
        //----Getting Year of Student------
        public string GetDept(int department)
        {
            var oCollegeApplicationEntities1 = new CollegeApplicationEntities();
            string result = (from table in oCollegeApplicationEntities1.Departments
                             where table.Id == department
                             select table.Name).Single();
            return result;
        }
        //Deleteing Faculty
        public void DeletingFaculty(int id)
        {
            var result = from table in oCollegeApplicationEntities.Faculties
                         where table.Id == id
                         select table;
            foreach (Faculty delete in result)
            {
                delete.IsActive = false;
            }
            oCollegeApplicationEntities.SaveChanges();
        }
        //------Error Logging----
        public void InsertException(ExceptionTable oException)
        {
            oCollegeApplicationEntities.ExceptionTables.AddObject(oException);
            oCollegeApplicationEntities.SaveChanges();
        }
    }
}
