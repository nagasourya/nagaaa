﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MasterDataAccess
{
     public class ApplicationDataAccess2
    {
         CollegeApplicationEntities oce = new CollegeApplicationEntities();
            
         public Student getIdandYear(int id)
         {
          
             Student result = (from info in oce.Students
                               where info.Id == id
                               select info).SingleOrDefault();
             return result;


         }
         public IEnumerable<Result> GetResultForStudents(int id, int dept)
         {
             var result = from resul in oce.Results
                          where resul.RegisterNo == id && resul.Department==dept
                          select resul;
             return result;
         }
         public void InsertOnlineResult(OnlineExamResult onlineresult)
         {
             oce.OnlineExamResults.AddObject(onlineresult);
             oce.SaveChanges();
         }
         public IEnumerable<OnlineExamResult> GetOnlineResult()
         {
             var result = from table in oce.OnlineExamResults
                          select table;
             return result;
         }
         //VIEW PROFILE STUDENTS AND ALUMINI
         public IEnumerable<Student> ViewProfileStudent(int id)
         {
             var result = from table in oce.Students
                          where table.Id==id
                          select table;
             return result;
         }
         //VIEW FACULTY PROFILE
         public IEnumerable<Faculty> ViewProfileFaculty(int id)
         {
             var result = from table in oce.Faculties
                          where table.Id == id
                          select table;
             return result;
         }
         
        
         
        
         



    }
}
