-- phpMyAdmin SQL Dump
-- version 2.11.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 11, 2008 at 02:41 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `asp`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('god', 'god'),
('student', 'student');

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `Serial` int(11) NOT NULL auto_increment,
  `question` varchar(75) NOT NULL,
  `choice1` varchar(50) NOT NULL,
  `choice2` varchar(50) NOT NULL,
  `choice3` varchar(50) NOT NULL,
  `choice4` varchar(50) NOT NULL,
  `correct` int(1) NOT NULL,
  PRIMARY KEY  (`Serial`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`Serial`, `question`, `choice1`, `choice2`, `choice3`, `choice4`, `correct`) VALUES
(1, 'Which of these is a primary color?', 'Red', 'Pink', 'Beige', 'Magenta', 1),
(2, 'Which is the most popular search engine in the world?', 'MSN', 'Google', 'Altavista', 'Yahoo', 2),
(3, 'Which city is the capital of India?', 'New Delhi', 'Mumbai', 'Bangalore', 'Kolkata', 1),
(4, 'Where were the Summer Olympics held in 2004?', 'Madrid', 'Beijing', 'Toronto', 'Athens', 4),
(5, 'What is the currency of USA?', 'Yen', 'Pound', 'Dollar', 'Rupee', 3),
(6, 'Who coined the Thoery of Relativity?', 'Edison', 'Davidson', 'Darwin', 'Einstein', 4),
(7, 'How many days in a week?', '9', '3', '7', '5', 3),
(8, 'How many hours in a day?', '12', '24', '36', '48', 2),
(9, 'How many seconds in a minute?', '60', '78', '77', '12', 1),
(10, 'Who won Wimbledon Men''s Singles Title in 2008?', 'Nadal', 'Federer', 'Roddick', 'Ferrero', 1);
