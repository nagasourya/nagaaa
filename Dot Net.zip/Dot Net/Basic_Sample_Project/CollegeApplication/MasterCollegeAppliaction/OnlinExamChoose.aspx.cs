﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class OnlinExamChoose : System.Web.UI.Page
    {
        string Testname = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
            GridView1.DataSource = oapplicationlibrary.GetTest();
            GridView1.DataBind();
            Label oLabel = new Label();
            Label oLabel1 = new Label();
            oLabel = (Label)Master.FindControl("lblWelcomeName");
            oLabel1 = (Label)Master.FindControl("lblLastLogIn");

            string username = Session["name"].ToString();
            oLabel.Text = username;
            string lastdate = Session["LastLogIn"].ToString();
            oLabel1.Text = lastdate;
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "SAVE")
            {
                Testname = e.CommandArgument.ToString();
              
            }
            Response.Redirect("StudentOnlineExam.aspx?test=" + Testname);

        }
    }
}