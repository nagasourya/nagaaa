﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MasterCollegeAppliaction
{
    public partial class ApplicationForm : System.Web.UI.Page
    {
        //protected void Page_Load(object sender, EventArgs e)
        //{

        //}

        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    if (HfConfirm.Value.Equals("true"))
        //    {

                
        //        masterEntities me = new masterEntities();
        //        var status = from id in me.USER_STATUS
        //                     where id.STATUS_ID == 1
        //                     select id.STATUS;

        //        USER_FORM uf = new USER_FORM()
        //        {
        //            NAME = txt_name.Text,
        //            USR_GENDER = RadioButtonList1.SelectedItem.Text,
        //            USR_DEPARTMENT = DropDownList1.SelectedItem.Text,
        //            USR_AVERAGEMARKS = int.Parse(txt_avgmarks.Text),
        //            USR_ADDRESS = txt_location.Text,
        //            USR_CONTACTNO = int.Parse(txt_contactno.Text),
        //            USR_EMAIL = txt_email.Text,
        //            USR_STATUSID = 1,



        //        };
        //        me.USER_FORM.AddObject(uf);
        //        me.SaveChanges();

        //        var appid = (from app in me.USER_FORM
        //                     select app.USR_APPID).Max();
        //        Label11.Visible = true;
        //        lblappid.Visible = true;
        //        lblappid.Text = appid.ToString();
        //        Panel1.Enabled = false;
        //        BtnClose.Visible = true;

        //    }
        //    else
        //    {
        //        if (!IsPostBack)
        //        {
        //            Response.Redirect("UserApplication.aspx");
        //        }
        //    }
        //}


        //protected void BtnClose_Click1(object sender, EventArgs e)
        //{
        //    Response.Redirect("Frontpage.aspx");
        //}

     
    }
}
  