﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MasterCollegeLibrary;

namespace MasterCollegeAppliaction
{
    public partial class StudentsAndFaculties : System.Web.UI.Page
    {
        int userid = 0;
        //int year = 0;
        //int dept = 0;
        //string sem = "";
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Label oLabel = new Label();
                Label oLabel1 = new Label();
                oLabel = (Label)Master.FindControl("lblWelcomeName");
                oLabel1 = (Label)Master.FindControl("lblLastLogIn");

                string username = Session["name"].ToString();
                oLabel.Text = username;
                string lastdate = Session["LastLogIn"].ToString();
                oLabel1.Text = lastdate;
            }
            


        }
      

        StudentModel ostudentmod = new StudentModel();
        ApplicationLibrary2 oapplicationlibrary = new ApplicationLibrary2();

        protected void lnkbtnChangePassword_Click(object sender, EventArgs e)
        {
            Response.Redirect("ChangePassword.aspx");
        }

        protected void lnkbtnPlacementDetails_Click(object sender, EventArgs e)
        {
            GrdPlacemnt.Visible = true;
            ApplicationLibrary oApplicationLib = new ApplicationLibrary();
            GrdPlacemnt.DataSource = oApplicationLib.GetPlacementCalender();
            GrdPlacemnt.DataBind();
        }

        protected void lnkbtnExaminationSchedule_Click(object sender, EventArgs e)
        {

            GrdVwSched.Visible = true;
            ApplicationLibrary oapplicationlib = new ApplicationLibrary();
            Label oLabel = new Label();
            Label oLabel1 = new Label();
            oLabel = (Label)Master.FindControl("lblWelcomeName");
            oLabel1 = (Label)Master.FindControl("lblLastLogIn");

            string username = Session["name"].ToString();
            oLabel.Text = username;
            string lastdate = Session["LastLogIn"].ToString();
            oLabel1.Text = lastdate;
            userid = int.Parse(Session["ID"].ToString());
         
            ostudentmod.Departmentname = oapplicationlibrary.getIdandYear(userid).Departmentname;
            ostudentmod.Yoj = oapplicationlibrary.getIdandYear(userid).Yoj;
            int year = ostudentmod.Yoj;
            int dept = oapplicationlib.ConvertingDeptId(ostudentmod.Departmentname);
            int semno = findsemester();
            int year1 = DateTime.Now.Year;
            string sem = FindSemFormat(semno);
            ApplicationLibrary oApplicationLib = new ApplicationLibrary();
            GrdVwSched.DataSource = oApplicationLib.ViewSchedule(year1,dept,sem);
            GrdVwSched.DataBind();

        }
        public int findsemester()
        {
            ostudentmod.Yoj = oapplicationlibrary.getIdandYear(userid).Yoj;
            int year = ostudentmod.Yoj;
            DateTime now = DateTime.Now;
            int mon = now.Month;
            int curyear = now.Year;
            int semmonth = 0;
            if (mon <= 6)
            {
                semmonth = 1;
            }
            else
            {
                semmonth = 2;
            }
            int sem = 0;
            int difyear = curyear - year;
            if (difyear == 0)
            {
                sem = difyear + semmonth - 1;
            }
            else if (difyear == 1)
            {
                sem = difyear + semmonth - 1;
            }
            else if (difyear == 2)
            {
                sem = semmonth - 1 + 3;
            }
            else if (difyear == 3)
            {
                sem = semmonth - 1 + 5;
            }
            else
            {
                sem = 8;
            }
            return sem;

        }
        public string FindSemFormat(int semno)
        {
            string sem="";
              if (semno == 1)
              {
                 sem="SEM 1";         
              }
              else if (semno == 2)
              {
                  sem="SEM 2";
              }
              else if (semno == 3)
              {
                  sem="SEM 3";
              }
              else if (semno == 4)
              {
                  sem="SEM 4";
              }
              else if (semno == 5)
              {
                  sem="SEM 5";
              }
              else if (semno == 6)
              {
                  sem="SEM 6";
              }
              else if (semno == 7)
              {
                  sem="SEM 7";
              }
              else if (semno == 8)
              {
                  sem="SEM 8";
              }
            return sem;
        }

        protected void lnkbtnResults_Click(object sender, EventArgs e)
        {
            GrdVwResult.Visible = true;
            ApplicationLibrary oapplicationlib = new ApplicationLibrary();
            Label oLabel = new Label();
            Label oLabel1 = new Label();
            oLabel = (Label)Master.FindControl("lblWelcomeName");
            oLabel1 = (Label)Master.FindControl("lblLastLogIn");

            string username = Session["name"].ToString();
            oLabel.Text = username;
            string lastdate = Session["LastLogIn"].ToString();
            oLabel1.Text = lastdate;
            userid = int.Parse(Session["ID"].ToString());
            StudentModel ostudentmod = new StudentModel();
            ApplicationLibrary2 oapplicationlibrary = new ApplicationLibrary2();
            ostudentmod.Departmentname = oapplicationlibrary.getIdandYear(userid).Departmentname;
            ostudentmod.Yoj = oapplicationlibrary.getIdandYear(userid).Yoj;
            int year = ostudentmod.Yoj;
            int dept = oapplicationlib.ConvertingDeptId(ostudentmod.Departmentname);
            int semno = findsemester();
            int year1 = DateTime.Now.Year;
            string sem = FindSemFormat(semno);
            //int id=int.Parse(userid);
            ApplicationLibrary2 oApplicationLib = new ApplicationLibrary2();
            GrdVwResult.DataSource = oApplicationLib.GetResultForStudents(userid, dept);
            GrdVwResult.DataBind();

        }

        protected void lnkbtnClassSchedule_Click(object sender, EventArgs e)
        {
            GrdVwclassSchedule.Visible = true;
            ApplicationLibrary oapplicationlib = new ApplicationLibrary();
            Label oLabel = new Label();
            Label oLabel1 = new Label();
            oLabel = (Label)Master.FindControl("lblWelcomeName");
            oLabel1 = (Label)Master.FindControl("lblLastLogIn");

            string username = Session["name"].ToString();
            oLabel.Text = username;
            string lastdate = Session["LastLogIn"].ToString();
            oLabel1.Text = lastdate;
            userid = int.Parse(Session["ID"].ToString());
            StudentModel ostudentmod = new StudentModel();
            ApplicationLibrary2 oapplicationlibrary = new ApplicationLibrary2();
            ostudentmod.Departmentname = oapplicationlibrary.getIdandYear(userid).Departmentname;
            ostudentmod.Yoj = oapplicationlibrary.getIdandYear(userid).Yoj;
            int year = ostudentmod.Yoj;
            int dept = oapplicationlib.ConvertingDeptId(ostudentmod.Departmentname);
            int semno = findsemester();
            int semesterno = semno + 1;
            int year1 = DateTime.Now.Year;
            string sem = FindSemFormat(semesterno);
           // ApplicationLibrary oapplicationlibrary = new ApplicationLibrary();
           // string sem = ddl_semester.SelectedItem.Text;
          //  int dept = oapplicationlibrary.ConvertingDeptId(ddl_department.SelectedItem.Text);
            GrdVwclassSchedule.DataSource = oapplicationlib.GetClassSchedule(sem, dept);
            GrdVwclassSchedule.DataBind();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {

        }

        protected void lnkbtnAlumniDetails_Click(object sender, EventArgs e)
        {
            int dt = int.Parse(DateTime.Now.Year.ToString());
            PnlViewAlumini.Visible = true;
            for (int i = 0; i < 9; i++)
            {
                ListItem ilist = new ListItem();
                ilist.Value = (dt - i).ToString();
                drpdwnyop.Items.Add(ilist);

            }
            ApplicationLibrary oApplicationLib = new ApplicationLibrary();
            var getalumini = oApplicationLib.viewAlumini();
            GrdVwAlumini.DataSource = getalumini;
            GrdVwAlumini.DataBind();
        }

        protected void ImgBtnSearchSubmit_Click(object sender, ImageClickEventArgs e)
        {
            ApplicationLibrary oApplicationLib = new ApplicationLibrary();
            string yop = "SELECT";
            string s = txtsearch.Text;
            yop = drpdwnyop.SelectedItem.Value;
            if (s.Equals("") && !(yop.Equals("SELECT")))
            {
                ErrMsgBox.AddMessage("Please Enter Name or Choose Year Of passed Out to Search..", MasterCollegeAppliaction.ErrorForm.enmMessageType.Attention);
            }
            else if (!(s.Equals("")) && !(yop.Equals("SELECT")))
            {
                //yop = int.Parse(drpdwnyop.SelectedItem.Value.ToString());
                var getalumini = oApplicationLib.viewAlumini(s, int.Parse(yop));
                GrdVwAlumini.DataSource = getalumini;
                GrdVwAlumini.DataBind();
            }
            else if ((s.Equals("")) && !(yop.Equals("SELECT")))
            {
                //yop = int.Parse(drpdwnyop.SelectedItem.Value.ToString());
                var getalumini = oApplicationLib.viewAlumini(int.Parse(yop));
                GrdVwAlumini.DataSource = getalumini;
                GrdVwAlumini.DataBind();
            }
            else if (!(s.Equals("")) && (yop.Equals("SELECT")))
            {
                var getalumini = oApplicationLib.viewAlumini(s);
                GrdVwAlumini.DataSource = getalumini;
                GrdVwAlumini.DataBind();
            }
        }

        protected void ImgBtnClose_Click(object sender, ImageClickEventArgs e)
        {
            PnlViewAlumini.Visible = false;
        }
       
                      
    }
}