$(document).ready(function(){
  //global vars
  var userName = $("#username"); //user name field
  var userPass = $("#password"); //password field
  
   //function to check name and comment field 
  function checkCommentsForm(){
    if(userName.attr("value") && userPass.attr("value"))
      return true;
    else
      return false;
  }

  //When form submitted
  $("#formL").submit(function(){
	  if(checkCommentsForm()){
      $.ajax({
        type: "post"
       , url: "loginValidation.jsp"
       ,data: "username="+userName.val()+"&password="+userPass.val(),
       success: function(msg) {$('#targetDiv').hide();
       $("#targetDiv").html ("<h3>" + msg + "</h3>").fadeIn("slow");}
        });
        }
    else alert("Please fill UserName & Password!");
    return false;
  });
});