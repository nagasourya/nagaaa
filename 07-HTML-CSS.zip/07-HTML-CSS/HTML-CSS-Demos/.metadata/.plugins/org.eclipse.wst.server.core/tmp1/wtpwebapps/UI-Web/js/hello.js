


var userName=prompt("What's your Name","Type here");
alert("Hello "+userName+", Welcome to JavaScript World!");

var stay=confirm("Would you like to stay on this page");
if (stay){
	alert("Thank you for being here");
}
else{
	window.close();
}