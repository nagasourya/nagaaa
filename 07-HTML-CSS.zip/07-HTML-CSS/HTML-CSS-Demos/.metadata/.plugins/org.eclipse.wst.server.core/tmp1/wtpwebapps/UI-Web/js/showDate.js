


function showDate(){
var date=new Date();
var day=date.getDate();
var month=date.getMonth()+1;
var year=date.getFullYear();
document.write("Today is :"+day+"/"+month+"/"+year);
}