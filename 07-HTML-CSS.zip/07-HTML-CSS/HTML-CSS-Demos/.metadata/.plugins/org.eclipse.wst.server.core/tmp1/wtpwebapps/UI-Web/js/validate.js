function validateUser(){
	if (document.userForm.uname.value == ""){
		alert("Please provide your Name");
		document.userForm.uname.focus();
		return false;
	}
	if(document.userForm.email.value == ""){
		alert("Please provide your Email");
		document.userForm.email.focus();
		return false;
	}
	if(document.userForm.email.value!="")
		{
		 return validateEmail();
		}
	if(document.userForm.phone.value == "" || isNaN(document.userForm.phone.value)|| document.userForm.phone.value.length !=10)
		{
		alert("Please provide your Phone in the format of ##########");
		document.userForm.phone.focus();
		return false;
	    }

	return true;
}
function validateEmail(){
	var emailID=document.userForm.email.value;
	var atPos=emailID.indexOf("@");
	var dotPos=emailID.lastIndexOf(".");
	if (atPos < 1 || (dotPos - atPos) < 2)
		{
		alert("Please enter a valid Email id");
		document.userForm.email.focus();
		return false;
		}
	return true;
}
