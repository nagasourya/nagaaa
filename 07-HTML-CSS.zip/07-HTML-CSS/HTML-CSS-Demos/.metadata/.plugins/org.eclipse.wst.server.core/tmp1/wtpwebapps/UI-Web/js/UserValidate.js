


function validateUser(){
	var firstName=document.userForm.fname.value;
	var lastName=document.userForm.lname.value;
	var email=document.userForm.email.value;
	
	if(firstName == "" || firstName.length < 5){
		alert("Please enter a First Name of at least 5 characters");
		document.userForm.fname.focus();
		return false;
	}
	if(lastName == "" || lastName.length < 5){
		alert("Please enter a Last Name of at least 5 characters");
		document.userForm.lname.focus();
		return false;
	}
	if (email == ""){
		alert("Please enter your email id");
		document.userForm.email.focus();
		return false;
	}
	if (email != ""){
		return validateEmail();
	}
	return true;
}
function validateEmail(){
	var emailID=document.userForm.email.value;
	var atPosition=emailID.indexOf("@");
	var dotPosition=emailID.lastIndexOf(".");
	
	if (atPosition < 1 || (dotPosition-atPosition) < 3){
		alert("Email is not Valid");
		document.userForm.email.focus();
		return false;
	}
	return true;
}
