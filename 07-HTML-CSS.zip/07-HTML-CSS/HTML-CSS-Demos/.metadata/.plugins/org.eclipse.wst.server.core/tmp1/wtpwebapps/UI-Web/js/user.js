


function showUser(user,age){
	//alert("Hello "+user+" and you are "+age+" year(s) old");
	
	if(user == ""){
		document.getElementById("error1").style.visibility="visible";
		//document.getElementById("un").innerHTML="User name is required";
	}
	else if(age == ""){
		document.getElementById("error2").style.visibility="visible";
		//document.getElementById("ua").innerHTML="Age is required";
	}
	else{
	var userData="Hello "+user+" and you are "+age+" year(s) old";
	document.getElementById("output").innerHTML=userData;
	}
		
}