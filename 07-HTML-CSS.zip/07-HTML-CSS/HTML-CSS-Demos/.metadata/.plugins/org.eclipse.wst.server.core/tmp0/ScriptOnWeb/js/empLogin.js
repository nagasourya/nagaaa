function move(){
	var selected = document.getElementsByName("login");
	
	for (var i=0;i<selected.length;i++){
		var value=selected[i].value;
		if (selected[i].checked){
		  if (value == 'employee'){
			  window.location.href = 'employeePage.html';
		}
		
		else {
			window.location.href='adminPage.html';
		}
		}	
		
	}
	
}