function navigate() {
    var selected = 
    	document.getElementsByName('querytype');

    for(var i=0; i<selected.length; i++) {
    var value = selected[i].value;
    if (selected[i].checked) {
        if (value == 'apple') {
        window.location.href = 'apple-page.html';
        } else if(value == 'orange'){
        window.location.href = 'orange-page.html';
        }
    } 
    }
}