function navigator(){
	var selected = document.getElementsByName("op");
	//for (var i=0;i<selected.length;i++){
		var value=selected[0].value;
		alert(value);
		if(value == 'ADD')
			{
				window.location.href="AddEmp.html";
			}
			else if(value == 'MODIFY'){
				window.location.href="UpdateEmp.html";
			}
			else if(value == 'DELETE'){
				window.location.href="DeleteEmp.html";
			}
			else if(value == 'LIST'){
				window.location.href="ListEmp.html";
			}
			
		
	//}
}