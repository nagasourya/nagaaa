function checkName(text) {
if(isNaN(text)){ return 1;}
else{alert("Please enter a valid name. The only charachters accepted are A - Z and a - z");return 0;}
}
function checkAddress(text) {
if(isNaN(text)){ return 1;}
else{alert("Please enter a valid address. The only charachters accepted are A - Z and a - z");return 0;}
}
function validate(){
    if (document.form.name.value == ""){
        alert ( "Please enter name." );
        document.form.name.focus();
        return false;
    }
    if (checkName(document.form.name.value)==false){
      name.value="";
      name.focus();
      return false;
      }
  if (document.form.address.value == ""){
        alert ( "Please enter address." );
        document.form.address.focus();
        return false;
    }
    if (checkAddress(document.form.address.value)==false){
      address.value="";
      address.focus();
      return false;
      }
    if ( ( document.form.radio[0].checked == false ) && ( document.form.radio[1].checked == false ) ){
        alert ( "Please choose Gender: M or F" );
        document.form.radio[0].focus();
        return false;
    }
    if ( document.form.qua.selectedIndex == 0 ){
        alert ( "Please select Qualification." );
        document.form.qua.focus();
        return false;
    }
    if(!multiselectvalidate(document.getElementById('specialization'))){
    alert ( "Please select Specialization." );
     return false;  
    }
    if ((document.form.lang1.checked == false) &&(document.form.lang2.checked == false) &&(document.form.lang3.checked == false)&&(document.form.lang4.checked == false))
        {
        alert ('You didn\'t choose any of the checkboxes!');
        return false;
        }
        var n=document.form.name.value;
        var add=document.form.address.value;
        document.writeln("Name= "+n);
        document.writeln("");
        document.writeln("Address= "+add);
     var oRadio = document.forms[0].elements[radio].value;
document.write(oRadio);
    return true;
}
    function multiselectvalidate(select) {  
        var valid = false;  
        for(var i = 0; i < select.length; i++) {  
            if(select.options[i].selected) {  
                valid = true;  
                break;  
            }  
        }  
     return valid;  
   }  