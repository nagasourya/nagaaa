function showUser(){
	var username=document.
	getElementById("username").value;
	var password=document.
	getElementById("password").value;
	
	/*display the User details */
	if (username == ""){
		userLogin.username.focus();
		alert("enter username");
		return false;
	}
	if (password == ""){
		userLogin.password.focus();
		alert("enter password");
		return false;
	}
	return true;
}
